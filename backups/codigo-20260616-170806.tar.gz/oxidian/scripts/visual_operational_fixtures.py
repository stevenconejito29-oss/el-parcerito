"""Fixtures temporales para capturar preparación y reparto con un canje visible."""
from __future__ import annotations

import json
import sys
from datetime import datetime
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import text

from app import create_app
from extensions import db
from models import Order, OrderItem, Product, User, ZonaEntrega, metadata_item_pedido, utcnow


QA_EMAIL = "qa-visual-operations@oxidian.local"
PREFIX = "QA-VIS-"
STATE_FILE = Path("/app/bot-data/visual-operations-state.json")


def cleanup() -> int:
    order_ids = [
        row[0]
        for row in db.session.execute(
            text("SELECT id FROM orders WHERE numero_pedido LIKE :prefix"),
            {"prefix": f"{PREFIX}%"},
        ).fetchall()
    ]
    for order_id in order_ids:
        for table in (
            "notification_outbox",
            "reviews",
            "affiliate_uses",
            "points_log",
            "caja",
            "staff_payments",
            "order_events",
            "order_items",
        ):
            db.session.execute(text(f"DELETE FROM {table} WHERE pedido_id = :id"), {"id": order_id})
        db.session.execute(text("DELETE FROM orders WHERE id = :id"), {"id": order_id})
    db.session.execute(text("DELETE FROM users WHERE email = :email"), {"email": QA_EMAIL})

    if STATE_FILE.exists():
        state = json.loads(STATE_FILE.read_text())
        for user_id, values in state.items():
            user = db.session.get(User, int(user_id))
            if user:
                user.en_linea = bool(values["en_linea"])
                user.last_seen = (
                    datetime.fromisoformat(values["last_seen"])
                    if values.get("last_seen") else None
                )
        STATE_FILE.unlink(missing_ok=True)
    db.session.commit()
    return len(order_ids)


def create() -> int:
    cleanup()
    preparador = User.query.filter_by(rol="preparacion", activo=True).first()
    repartidor = User.query.filter_by(rol="repartidor", activo=True).first()
    product = Product.query.filter_by(activo=True).first()
    reward = Product.query.filter_by(activo=True, canjeable_con_puntos=True).first()
    zone = ZonaEntrega.query.filter_by(activo=True).first()
    if not all((preparador, repartidor, product, reward, zone)):
        raise RuntimeError("Faltan datos operativos para crear las capturas")

    state = {
        str(preparador.id): {
            "en_linea": bool(preparador.en_linea),
            "last_seen": preparador.last_seen.isoformat() if preparador.last_seen else None,
        },
        str(repartidor.id): {
            "en_linea": bool(repartidor.en_linea),
            "last_seen": repartidor.last_seen.isoformat() if repartidor.last_seen else None,
        },
    }
    STATE_FILE.write_text(json.dumps(state))
    for user in (preparador, repartidor):
        user.en_linea = True
        user.last_seen = utcnow()

    customer = User(
        nombre="Cliente visual",
        email=QA_EMAIL,
        rol="cliente",
        telefono="+34699222333",
        direccion="Calle Visual 12, Carmona",
        puntos=140,
        activo=True,
    )
    customer.set_password("visual-fixture-not-for-login")
    db.session.add(customer)
    db.session.flush()

    orders = [
        Order(
            numero_pedido=f"{PREFIX}PREP",
            cliente_id=customer.id,
            preparador_id=preparador.id,
            estado="pendiente",
            origen="online",
            subtotal=Decimal("5.00"),
            descuento=Decimal("0"),
            total=Decimal("8.00"),
            puntos_usados=int(reward.puntos_para_canje or 0),
            puntos_ganados=8,
            metodo_pago="efectivo",
            direccion_entrega=customer.direccion,
            notas="Canje visual: preparar el regalo junto al pedido.",
            zona_id=zone.id,
            es_entrega_epicentro=bool(zone.es_epicentro),
        ),
        Order(
            numero_pedido=f"{PREFIX}RUTA",
            cliente_id=customer.id,
            preparador_id=preparador.id,
            repartidor_id=repartidor.id,
            estado="listo",
            origen="online",
            subtotal=Decimal("5.00"),
            descuento=Decimal("0"),
            total=Decimal("8.00"),
            puntos_usados=int(reward.puntos_para_canje or 0),
            puntos_ganados=8,
            metodo_pago="efectivo",
            direccion_entrega=customer.direccion,
            notas="Entregar también el producto gratuito de puntos.",
            zona_id=zone.id,
            es_entrega_epicentro=bool(zone.es_epicentro),
        ),
    ]
    db.session.add_all(orders)
    db.session.flush()

    for order in orders:
        db.session.add(OrderItem(
            pedido_id=order.id,
            producto_id=product.id,
            cantidad=1,
            precio_unit=product.precio_final,
            subtotal=product.precio_final,
            metadata_json=json.dumps(metadata_item_pedido(product), ensure_ascii=False),
        ))
        db.session.add(OrderItem(
            pedido_id=order.id,
            producto_id=reward.id,
            cantidad=1,
            precio_unit=0,
            subtotal=0,
            metadata_json=json.dumps(
                metadata_item_pedido(
                    reward,
                    {
                        "reward": {
                            "tipo": "producto_puntos",
                            "puntos": int(reward.puntos_para_canje or 0),
                            "cliente_id": customer.id,
                        }
                    },
                ),
                ensure_ascii=False,
            ),
        ))
    db.session.commit()
    return len(orders)


def main() -> None:
    action = (sys.argv[1] if len(sys.argv) > 1 else "").lower()
    app = create_app("production")
    with app.app_context():
        if action == "create":
            print({"created": create()})
        elif action == "cleanup":
            print({"deleted": cleanup()})
        else:
            raise SystemExit("Uso: visual_operational_fixtures.py create|cleanup")


if __name__ == "__main__":
    main()
