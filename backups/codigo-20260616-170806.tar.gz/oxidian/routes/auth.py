from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from urllib.parse import urlparse
from flask_login import login_user, logout_user, login_required, current_user
from extensions import limiter, db
from models import User

auth_bp = Blueprint("auth", __name__)

REDIRECT_POR_ROL = {
    "super_admin":  "superadmin.dashboard",
    "admin":        "admin.dashboard",
    "cocina":       "preparador.pedidos",
    "preparacion":  "preparador.pedidos",
    "repartidor":   "repartidor.ruta",
    "proveedor":    "proveedor.pedidos",
    "cliente":      "public.index",
    "staff":        "staff.pedidos",
}


@auth_bp.route("/login", methods=["GET", "POST"])
@limiter.limit("10 per minute") if limiter else (lambda f: f)
def login():
    if current_user.is_authenticated:
        return _redirect_rol(current_user.rol)

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email, activo=True).first()

        if user and user.check_password(password):
            session.permanent = True
            login_user(user, remember=False)
            next_page = request.args.get("next")
            if _next_is_safe_get(next_page):
                return redirect(next_page)
            return _redirect_rol(user.rol)

        flash("Email o contraseña incorrectos.", "danger")

    return render_template("auth/login.html")


@auth_bp.route("/registro")
def registro():
    # El registro público está deshabilitado.
    # Las cuentas las crea el superadmin desde el panel de administración.
    from flask import abort
    abort(404)


@auth_bp.route("/logout", methods=["POST"])
@login_required
def logout():
    current_user.en_linea = False
    db.session.commit()
    logout_user()
    return redirect(url_for("public.index"))


def _redirect_rol(rol):
    destino = REDIRECT_POR_ROL.get(rol, "public.index")
    return redirect(url_for(destino))


def _next_is_safe_get(next_page):
    if not next_page:
        return False
    parsed = urlparse(next_page)
    if parsed.scheme or parsed.netloc:
        return False
    path = parsed.path or next_page
    unsafe_action_fragments = (
        "/toggle", "/eliminar", "/crear", "/editar", "/pagar",
        "/confirmar", "/rechazar", "/cancelar", "/devolver",
        "/agregar", "/ajustar", "/activar-todos", "/guardar",
    )
    return not any(fragment in path for fragment in unsafe_action_fragments)
