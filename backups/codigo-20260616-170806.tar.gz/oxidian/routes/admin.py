import ipaddress
import json
import uuid
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_UP
from urllib.parse import urlparse
from flask import Blueprint, render_template, request, redirect, url_for, flash, make_response, abort
from flask_login import login_required, current_user
from functools import wraps
from datetime import datetime, date, timedelta
from flask import current_app
from sqlalchemy import or_
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import joinedload
import csv, io

from extensions import db, get_or_404
from models import (User, Product, Categoria, Stock, Order, OrderItem, Review,
                    Coupon, ComboGroup, ComboItem, Caja, PointsLog, StaffPayment,
                    AffiliateCode, AffiliateUse, MenuConfig,
                    PriceHistory, SiteConfig, AuditLog,
                    AdminFeature, NotificationOutbox, normalizar_metodo_pago, utcnow)
from combo_validators import (
    ComboLimits,
    validate_component_quantity,
    validate_selections_per_group,
    validate_group_name,
    validate_combo_structure,
    validate_component_product,
    validate_parallel_arrays,
    validate_combo_pricing
)
from routes.api_bot import notificar_bot_sync
from services import (estado_cola, registrar_egreso, registrar_ingreso,
                      resumen_caja_hoy, pagos_pendientes_staff,
                      calcular_pl, top_productos, resumen_ventas_por_categoria,
                      enviar_whatsapp_codigo_entrega, enviar_whatsapp_estado, enviar_whatsapp_pago_confirmado,
                      distribuir_repartidor, generar_comision_entrega,
                      solicitar_resena_pedido, avanzar_estado_pedido,
                      cancelar_pedido_operativo, registrar_pago_pedido,
                      registrar_ingreso_pedido, procesar_notificaciones_pendientes)
from services import reasignar_responsable_pedido
from routes.uploads import _save_image, _borrar_imagen
from phone_utils import normalizar_telefono_cliente

admin_bp = Blueprint("admin", __name__)

_ROLES_ADMIN = {"admin", "super_admin"}
_ROLES_USUARIO_BASE = ["staff", "cocina", "preparacion", "repartidor", "proveedor", "cliente"]
_ROLES_USUARIO_SUPERADMIN = _ROLES_USUARIO_BASE + ["admin", "super_admin"]

_ESTADOS_PEDIDO_VALIDOS = {"pendiente", "armando", "listo", "en_ruta", "entregado", "cancelado"}
_ORIGENES_PEDIDO_VALIDOS = {"online", "web", "presencial", "whatsapp", "pos", "telefono"}


def _normalizar_imagen_url(valor):
    """
    Guarda rutas locales en formato relativo (`productos/x.jpg`) y conserva URLs externas.
    Evita persistir `/uploads/...`, que en templates se duplicaria como `/uploads//uploads/...`.
    """
    url = (valor or "").strip()
    if not url:
        return None
    if url.startswith(("http://", "https://")):
        if len(url) > 2000:
            return None
        try:
            host = urlparse(url).hostname or ""
            # Bloquear localhost y variantes
            if host in ("localhost", "127.0.0.1", "::1", "0.0.0.0"):
                return None
            # Bloquear IPs privadas/internas
            try:
                if ipaddress.ip_address(host).is_private:
                    return None
            except ValueError:
                pass  # Es un hostname, no una IP — se permite
        except Exception:
            return None
        return url
    if url.startswith("/uploads/"):
        return url[len("/uploads/"):].lstrip("/")
    if url.startswith("uploads/"):
        return url[len("uploads/"):].lstrip("/")
    return url.lstrip("/")

# Mapeo prefijo de URL → feature requerida (solo para usuarios con rol "admin")
# super_admin siempre pasa; admin se verifica según el mapa de features.
_FEATURE_URL_MAP = {
    "/admin/caja":         "caja",
    "/admin/stock":        "stock",
    "/admin/pagos-staff":  "staff_pagos",
    "/admin/liquidacion-proveedores": "staff_pagos",
    "/admin/analytics":    "reportes",
    "/admin/notificaciones": "whatsapp",
    "/admin/productos":    "productos",
    "/admin/categorias":   "productos",
    "/admin/cupones":      "cupones",
    "/admin/afiliados":    "marketing",
    "/admin/menu-config":  "marketing",
    "/admin/resenas":      "marketing",
}


@admin_bp.before_request
def verificar_feature_acceso():
    """
    Comprueba que el admin autenticado tiene el feature habilitado para la URL.
    - super_admin: siempre pasa.
    - admin: se comprueba AdminFeature según el prefijo de la URL.
    - Sin autenticar o rol incorrecto: los decoradores de ruta ya lo gestionan.
    """
    if not current_user.is_authenticated:
        return
    if current_user.rol == "super_admin":
        return
    if current_user.rol != "admin":
        return

    path = request.path
    for prefijo, feature in _FEATURE_URL_MAP.items():
        if path.startswith(prefijo):
            if not AdminFeature.tiene_acceso(current_user.id, feature):
                flash(
                    f"No tienes acceso al módulo «{feature}». "
                    f"Pide al superadmin que lo habilite en tu cuenta.",
                    "warning",
                )
                return redirect(url_for("admin.dashboard"))
            return


def _safe_commit(msg_ok: str, redirect_to: str):
    """Intenta commit; si falla hace rollback y flashea error. Devuelve redirect."""
    try:
        db.session.commit()
        flash(msg_ok, "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al guardar: {exc}", "danger")
    return redirect(redirect_to)


def _parse_date_strict(valor: str):
    """Convierte 'YYYY-MM-DD' a date o lanza ValueError con mensaje claro."""
    try:
        return datetime.strptime(valor.strip(), "%Y-%m-%d").date()
    except (ValueError, AttributeError):
        raise ValueError(f"Fecha inválida: {valor!r}. Usa formato YYYY-MM-DD.")


def _roles_editables_usuario():
    """Roles que el usuario actual puede asignar desde el panel admin."""
    if current_user.rol == "super_admin":
        return list(_ROLES_USUARIO_SUPERADMIN)
    return list(_ROLES_USUARIO_BASE)


def admin_required(f):
    @wraps(f)
    @login_required
    def decorated(*args, **kwargs):
        if current_user.rol not in _ROLES_ADMIN:
            flash("Acceso restringido a administradores.", "danger")
            return redirect(url_for("public.index"))
        return f(*args, **kwargs)
    return decorated


def marketing_or_admin_required(f):
    """Alias de admin_required — el rol marketing fue eliminado, solo admin/super_admin."""
    return admin_required(f)


# ─── DASHBOARD ───────────────────────────────

@admin_bp.route("/dashboard")
@admin_required
def dashboard():
    ingresos_hoy, egresos_hoy = resumen_caja_hoy()
    pedidos_hoy = Order.query.filter(db.func.date(Order.creado_en) == date.today()).count()
    pendientes_count = Order.query.filter_by(estado="pendiente").count()
    alertas_stock = _count_alertas_stock()
    pagos_pend = pagos_pendientes_staff()
    cola = estado_cola()
    pagos_digitales_pendientes = Order.query.filter(
        Order.metodo_pago == "bizum",
        Order.pago_confirmado == False,
        Order.estado.notin_(["cancelado", "entregado"]),
    ).count()
    pedidos_sin_preparador = Order.query.filter(
        Order.estado.in_(["pendiente", "armando"]),
        Order.preparador_id == None,
    ).count()
    pedidos_sin_repartidor = Order.query.filter(
        Order.estado == "listo",
        Order.repartidor_id == None,
    ).count()
    pedidos_sin_asignar = pedidos_sin_preparador + pedidos_sin_repartidor

    # Cola de pedidos activos para el panel en vivo
    pedidos_pendientes = Order.query.filter_by(estado="pendiente")\
        .order_by(Order.creado_en.asc()).limit(20).all()
    pedidos_armando = Order.query.filter_by(estado="armando")\
        .order_by(Order.creado_en.asc()).limit(10).all()
    pedidos_listos = Order.query.filter_by(estado="listo")\
        .order_by(Order.creado_en.asc()).limit(10).all()
    pedidos_en_ruta = Order.query.filter_by(estado="en_ruta")\
        .order_by(Order.creado_en.asc()).limit(10).all()

    # Últimos pedidos entregados hoy
    entregados_hoy = Order.query.filter(
        Order.estado == "entregado",
        db.func.date(Order.creado_en) == date.today()
    ).order_by(Order.entregado_en.desc()).limit(5).all()

    # Preparadores y repartidores para asignación manual
    preparadores = User.query.filter(
        User.rol.in_(["cocina", "preparacion"]),
        User.activo == True
    ).all()
    repartidores = User.query.filter_by(rol="repartidor", activo=True).all()

    return render_template("admin/dashboard.html",
                           pedidos_hoy=pedidos_hoy,
                           ingresos_hoy=ingresos_hoy,
                           egresos_hoy=egresos_hoy,
                           saldo_hoy=ingresos_hoy - egresos_hoy,
                           pendientes=pendientes_count,
                           alertas_stock=alertas_stock,
                           pagos_pendientes=pagos_pend,
                           pagos_digitales_pendientes=pagos_digitales_pendientes,
                           pedidos_sin_asignar=pedidos_sin_asignar,
                           pedidos_sin_preparador=pedidos_sin_preparador,
                           pedidos_sin_repartidor=pedidos_sin_repartidor,
                           cola=cola,
                           pedidos_pendientes=pedidos_pendientes,
                           pedidos_armando=pedidos_armando,
                           pedidos_listos=pedidos_listos,
                           pedidos_en_ruta=pedidos_en_ruta,
                           entregados_hoy=entregados_hoy,
                           preparadores=preparadores,
                           repartidores=repartidores)


# ─── COLA DE TRABAJO ─────────────────────────

@admin_bp.route("/cola")
@admin_required
def cola():
    cola_data = estado_cola()
    pedidos_sin_asignar = Order.query.filter(
        Order.estado.in_(["pendiente", "armando"]),
        Order.preparador_id == None
    ).all()
    pedidos_sin_repartidor = Order.query.filter(
        Order.estado == "listo",
        Order.repartidor_id == None
    ).all()
    return render_template("admin/cola.html",
                           cola=cola_data,
                           sin_asignar=pedidos_sin_asignar,
                           sin_repartidor=pedidos_sin_repartidor)


@admin_bp.route("/cola/reasignar/<int:pedido_id>", methods=["POST"])
@admin_required
def reasignar_pedido(pedido_id):
    pedido = Order.query.filter_by(id=pedido_id).with_for_update().first_or_404()
    user_id = request.form.get("user_id", type=int)
    campo = request.form.get("campo")  # preparador_id / repartidor_id
    try:
        anterior_id, nuevo_id = reasignar_responsable_pedido(
            pedido,
            campo,
            user_id,
            actor_id=current_user.id,
            canal="admin_cola",
        )
        if anterior_id != nuevo_id:
            AuditLog.registrar(
                current_user.id,
                "reasignar_pedido",
                "order",
                pedido.id,
                detalle=f"{campo}: {anterior_id or 'sin asignar'} -> {nuevo_id or 'sin asignar'}",
                ip=request.remote_addr,
            )
        db.session.commit()
        flash("Asignación actualizada.", "success")
    except ValueError as exc:
        db.session.rollback()
        flash(str(exc), "danger")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al reasignar: {exc}", "danger")
    return redirect(url_for("admin.cola"))


# ─── PEDIDOS ─────────────────────────────────

def _registrar_reversion_caja_pedido(pedido, motivo, user_id):
    """Registra un egreso por el ingreso neto asociado a un pedido cancelado."""
    ingresos = db.session.query(db.func.coalesce(db.func.sum(Caja.monto), 0)).filter(
        Caja.pedido_id == pedido.id,
        Caja.tipo == "ingreso",
    ).scalar() or 0
    egresos = db.session.query(db.func.coalesce(db.func.sum(Caja.monto), 0)).filter(
        Caja.pedido_id == pedido.id,
        Caja.tipo == "egreso",
    ).scalar() or 0
    monto_revertir = round(float(ingresos) - float(egresos), 2)
    if monto_revertir <= 0:
        return None
    return registrar_egreso(
        monto_revertir,
        f"Reversion {pedido.numero_pedido} - {motivo}",
        categoria="devolucion",
        pedido_id=pedido.id,
        registrado_por=user_id,
    )

@admin_bp.route("/pedidos")
@admin_required
def pedidos():
    estado = request.args.get("estado")
    origen = request.args.get("origen")
    epicentro = request.args.get("epicentro")
    pedido_id = request.args.get("id", type=int)
    if estado and estado not in _ESTADOS_PEDIDO_VALIDOS:
        estado = None
    if origen and origen not in _ORIGENES_PEDIDO_VALIDOS:
        origen = None
    query = Order.query.order_by(Order.creado_en.desc())
    if pedido_id:
        query = query.filter_by(id=pedido_id)
    if estado:
        query = query.filter_by(estado=estado)
    if origen:
        query = query.filter_by(origen=origen)
    if epicentro == "1":
        query = query.filter_by(es_entrega_epicentro=True)
    elif epicentro == "0":
        query = query.filter_by(es_entrega_epicentro=False)
    todos = query.all()
    preparadores = User.query.filter(
        User.rol.in_(["cocina", "preparacion", "staff"]), User.activo == True
    ).all()
    repartidores = User.query.filter_by(rol="repartidor", activo=True).all()
    return render_template("admin/pedidos.html",
                           pedidos=todos,
                           preparadores=preparadores,
                           repartidores=repartidores)


@admin_bp.route("/pedidos/<int:pedido_id>/asignar", methods=["POST"])
@admin_required
def asignar_pedido(pedido_id):
    pedido = Order.query.filter_by(id=pedido_id).with_for_update().first_or_404()
    prep_id = request.form.get("preparador_id", type=int)
    rep_id = request.form.get("repartidor_id", type=int)
    cambios = []
    try:
        if prep_id and prep_id != pedido.preparador_id:
            cambios.append(("preparador_id", reasignar_responsable_pedido(
                pedido,
                "preparador_id",
                prep_id,
                actor_id=current_user.id,
                canal="admin_pedidos",
            )))
        if rep_id and rep_id != pedido.repartidor_id:
            cambios.append(("repartidor_id", reasignar_responsable_pedido(
                pedido,
                "repartidor_id",
                rep_id,
                actor_id=current_user.id,
                canal="admin_pedidos",
            )))
        for campo, (anterior_id, nuevo_id) in cambios:
            AuditLog.registrar(
                current_user.id,
                "reasignar_pedido",
                "order",
                pedido.id,
                detalle=f"{campo}: {anterior_id or 'sin asignar'} -> {nuevo_id or 'sin asignar'}",
                ip=request.remote_addr,
            )
        db.session.commit()
        flash("Pedido actualizado." if cambios else "La asignación no cambió.", "success")
    except ValueError as exc:
        db.session.rollback()
        flash(str(exc), "danger")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al asignar: {exc}", "danger")
    return redirect(url_for("admin.pedidos"))


@admin_bp.route("/pedidos/<int:pedido_id>/cancelar", methods=["POST"])
@admin_required
def cancelar_pedido(pedido_id):
    pedido = Order.query.filter_by(id=pedido_id).with_for_update().first_or_404()
    try:
        cancelar_pedido_operativo(
            pedido,
            actor_id=current_user.id,
            canal="admin",
            detalle="cancelacion admin",
        )
        _registrar_reversion_caja_pedido(pedido, "cancelacion admin", current_user.id)
        enviar_whatsapp_estado(pedido)
        db.session.commit()
        flash(f"Pedido {pedido.numero_pedido} cancelado.", "warning")
    except ValueError as e:
        db.session.rollback()
        flash(str(e), "danger")
        return redirect(url_for("admin.pedidos"))
    return redirect(url_for("admin.pedidos"))


@admin_bp.route("/pedidos/<int:pedido_id>/avanzar", methods=["POST"])
@admin_required
def avanzar_pedido_admin(pedido_id):
    pedido = Order.query.filter_by(id=pedido_id).with_for_update().first_or_404()
    if pedido.estado == "en_ruta":
        flash(
            "La entrega debe cerrarse desde el panel de reparto para validar código y cobro.",
            "warning",
        )
        return redirect(url_for("admin.pedidos"))
    try:
        pedir_resena = False
        avanzar_estado_pedido(
            pedido,
            actor_id=current_user.id,
            canal="admin",
            validar_operativa=True,
        )
        if pedido.estado == "listo":
            distribuir_repartidor(pedido)
        AuditLog.registrar(current_user.id, "avanzar_pedido", "order",
                           pedido.id, detalle=pedido.estado, ip=request.remote_addr)
        enviar_whatsapp_estado(pedido)
        if pedir_resena:
            solicitar_resena_pedido(pedido)
        db.session.commit()
    except ValueError as exc:
        db.session.rollback()
        flash(str(exc), "danger")
        return redirect(url_for("admin.pedidos"))
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al avanzar pedido: {exc}", "danger")
        return redirect(url_for("admin.pedidos"))

    flash(f"{pedido.numero_pedido} ahora está en estado {pedido.estado}.", "success")
    return redirect(url_for("admin.pedidos"))


# ─── CONFIRMACIÓN DE PAGO DIGITAL (M13) ──────

@admin_bp.route("/pagos-pendientes")
@admin_required
def pagos_pendientes_digital():
    """
    Panel de pedidos Bizum pendientes de verificacion manual.
    Admin puede confirmarlos antes; reparto tambien puede hacerlo al entregar.
    """
    pendientes = Order.query.filter(
        Order.metodo_pago == "bizum",
        Order.pago_confirmado == False,
        Order.estado.notin_(["cancelado", "entregado"]),
    ).order_by(Order.creado_en.desc()).all()

    confirmados_hoy = Order.query.filter(
        Order.metodo_pago == "bizum",
        Order.pago_confirmado == True,
        db.func.date(Order.pago_confirmado_en) == date.today(),
    ).count()

    return render_template("admin/pagos_pendientes.html",
                           pendientes=pendientes,
                           confirmados_hoy=confirmados_hoy,
                           bizum_tel=SiteConfig.get("TELEFONO_NEGOCIO", ""))


@admin_bp.route("/pagos-pendientes/<int:pedido_id>/confirmar", methods=["POST"])
@admin_required
def confirmar_pago_digital(pedido_id):
    pedido = Order.query.filter_by(id=pedido_id).with_for_update().first_or_404()

    if pedido.pago_confirmado:
        flash("Este pago ya estaba confirmado.", "warning")
        return redirect(url_for("admin.pagos_pendientes_digital"))
    if pedido.metodo_pago != "bizum":
        flash("Este pedido no usa Bizum.", "danger")
        return redirect(url_for("admin.pagos_pendientes_digital"))
    if pedido.estado in ("cancelado", "entregado"):
        flash("No se puede confirmar el pago de un pedido cerrado.", "danger")
        return redirect(url_for("admin.pagos_pendientes_digital"))

    registrar_pago_pedido(pedido, actor_id=current_user.id, canal="admin")
    registrar_ingreso_pedido(pedido, registrado_por=current_user.id)
    if pedido.estado == "pendiente" and not pedido.preparador_id:
        distribuir_pedido(pedido)

    AuditLog.registrar(
        current_user.id, "confirmar_pago_digital", "order", pedido.id,
        detalle=f"{pedido.numero_pedido} {pedido.metodo_pago} €{pedido.total}",
        ip=request.remote_addr,
    )
    enviar_whatsapp_pago_confirmado(pedido)
    try:
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al confirmar pago: {exc}", "danger")
        return redirect(url_for("admin.pagos_pendientes_digital"))

    flash(f"Pago de {pedido.numero_pedido} confirmado. Cliente notificado.", "success")
    return redirect(url_for("admin.pagos_pendientes_digital"))


@admin_bp.route("/pagos-pendientes/<int:pedido_id>/rechazar", methods=["POST"])
@admin_required
def rechazar_pago_digital(pedido_id):
    pedido = Order.query.filter_by(id=pedido_id).with_for_update().first_or_404()
    motivo = request.form.get("motivo", "Pago no recibido").strip()[:200]
    try:
        cancelar_pedido_operativo(
            pedido,
            actor_id=current_user.id,
            canal="admin",
            detalle=f"pago rechazado: {motivo}",
        )
    except ValueError as exc:
        db.session.rollback()
        flash(f"No se pudo rechazar el pago: {exc}", "danger")
        return redirect(url_for("admin.pagos_pendientes_digital"))
    _registrar_reversion_caja_pedido(pedido, "pago rechazado", current_user.id)
    pedido.notas = (pedido.notas or "") + f" [Pago rechazado: {motivo}]"
    AuditLog.registrar(
        current_user.id, "rechazar_pago_digital", "order", pedido.id,
        detalle=motivo, ip=request.remote_addr,
    )
    enviar_whatsapp_codigo_entrega(pedido, actor_id=current_user.id)
    try:
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al rechazar pago: {exc}", "danger")
        return redirect(url_for("admin.pagos_pendientes_digital"))
    flash(f"Pedido {pedido.numero_pedido} cancelado por pago rechazado.", "warning")
    return redirect(url_for("admin.pagos_pendientes_digital"))


@admin_bp.route("/pedidos/<int:pedido_id>/reset-codigo", methods=["POST"])
@admin_required
def reset_codigo_confirmacion(pedido_id):
    pedido = Order.query.filter_by(id=pedido_id).with_for_update().first_or_404()
    if pedido.estado not in ("en_ruta",):
        flash("Solo se puede resetear el código en pedidos 'en ruta'.", "warning")
        return redirect(url_for("admin.pedidos"))
    pedido.intentos_codigo = 0
    pedido.generar_codigo_confirmacion()
    AuditLog.registrar(
        current_user.id, "reset_codigo_confirmacion", "order", pedido.id,
        detalle=f"{pedido.numero_pedido} nuevo código generado",
        ip=request.remote_addr,
    )
    enviar_whatsapp_estado(pedido)
    try:
        db.session.commit()
        flash(f"Código de confirmación regenerado para {pedido.numero_pedido}.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al regenerar código: {exc}", "danger")
    return redirect(url_for("admin.pedidos"))


# ─── CAJA ────────────────────────────────────

@admin_bp.route("/caja")
@admin_required
def caja():
    fecha_ini = request.args.get("fecha_ini", date.today().isoformat())
    fecha_fin = request.args.get("fecha_fin", date.today().isoformat())
    categoria_f = request.args.get("categoria", "")

    try:
        fi = datetime.fromisoformat(fecha_ini)
        ff = datetime.fromisoformat(fecha_fin).replace(hour=23, minute=59, second=59)
    except (ValueError, TypeError):
        fi = datetime.combine(date.today(), datetime.min.time())
        ff = datetime.combine(date.today(), datetime.max.time())
        fecha_ini = fecha_fin = date.today().isoformat()

    query = Caja.query.filter(Caja.fecha.between(fi, ff))
    if categoria_f:
        query = query.filter_by(categoria=categoria_f)
    movimientos = query.order_by(Caja.fecha.desc()).all()

    ingresos = sum(float(m.monto) for m in movimientos if m.tipo == "ingreso")
    egresos = sum(float(m.monto) for m in movimientos if m.tipo == "egreso")

    # Desglose por categoría
    por_categoria = defaultdict(lambda: {"ingreso": 0, "egreso": 0})
    for m in movimientos:
        por_categoria[m.categoria][m.tipo] += float(m.monto)

    return render_template("admin/caja.html",
                           movimientos=movimientos,
                           ingresos=ingresos, egresos=egresos,
                           saldo=ingresos - egresos,
                           por_categoria=dict(por_categoria),
                           fecha_ini=fecha_ini, fecha_fin=fecha_fin,
                           categoria_f=categoria_f)


@admin_bp.route("/caja/movimiento", methods=["POST"])
@admin_required
def registrar_movimiento():
    tipo = request.form.get("tipo")
    concepto = request.form.get("concepto", "").strip()
    categoria = request.form.get("categoria", "general")
    try:
        monto = float(request.form.get("monto", 0) or 0)
    except (ValueError, TypeError):
        monto = 0.0

    if tipo not in ("ingreso", "egreso") or monto <= 0 or not concepto:
        flash("Datos inválidos. Verifica tipo, importe y concepto.", "danger")
        return redirect(url_for("admin.caja"))

    if tipo == "ingreso":
        registrar_ingreso(monto, concepto, categoria=categoria,
                          registrado_por=current_user.id)
    else:
        registrar_egreso(monto, concepto, categoria=categoria,
                         registrado_por=current_user.id)
    try:
        db.session.commit()
        flash(f"{tipo.capitalize()} de €{monto:.2f} registrado.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al registrar movimiento: {exc}", "danger")
    return redirect(url_for("admin.caja"))


@admin_bp.route("/caja/exportar")
@admin_required
def exportar_caja():
    fecha_ini = request.args.get("fecha_ini", date.today().isoformat())
    fecha_fin = request.args.get("fecha_fin", date.today().isoformat())
    try:
        fi = datetime.fromisoformat(fecha_ini)
        ff = datetime.fromisoformat(fecha_fin).replace(hour=23, minute=59, second=59)
    except (ValueError, TypeError):
        fi = datetime.combine(date.today(), datetime.min.time())
        ff = datetime.combine(date.today(), datetime.max.time())
        fecha_ini = fecha_fin = date.today().isoformat()
    movimientos = Caja.query.filter(Caja.fecha.between(fi, ff)).order_by(Caja.fecha).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Fecha", "Tipo", "Categoria", "Monto", "Concepto", "Pedido"])
    for m in movimientos:
        writer.writerow([
            m.fecha.strftime("%Y-%m-%d %H:%M"),
            m.tipo, m.categoria,
            float(m.monto), m.concepto,
            m.pedido_id or ""
        ])
    response = make_response(output.getvalue())
    response.headers["Content-Disposition"] = f"attachment; filename=caja_{fecha_ini}_{fecha_fin}.csv"
    response.headers["Content-type"] = "text/csv"
    return response


# ─── PAGOS AL STAFF ──────────────────────────

@admin_bp.route("/pagos-staff")
@admin_required
def pagos_staff():
    empleados = User.query.filter(
        User.rol.in_(["staff", "cocina", "preparacion", "repartidor"]),
        User.activo == True
    ).order_by(User.rol, User.nombre).all()

    user_id_f = request.args.get("user_id", type=int)
    pagado_f  = request.args.get("pagado")
    tipo_f    = request.args.get("tipo", "").strip()

    _TIPOS_STAFF_VALIDOS = {"salario", "comision", "bonus", "adelanto", "descuento", "liquidacion_proveedor"}

    query = StaffPayment.query.order_by(StaffPayment.creado_en.desc())
    if user_id_f:
        query = query.filter_by(user_id=user_id_f)
    if pagado_f == "0":
        query = query.filter_by(pagado=False)
    elif pagado_f == "1":
        query = query.filter_by(pagado=True)
    if tipo_f in _TIPOS_STAFF_VALIDOS:
        query = query.filter(StaffPayment.tipo == tipo_f)

    pagos = query.all()
    total_pendiente = sum(float(p.monto or 0) for p in pagos if not p.pagado)
    total_pagado = sum(float(p.monto or 0) for p in pagos if p.pagado)
    repartidores = [u for u in empleados if u.rol == "repartidor"]
    rep_ids = [r.id for r in repartidores]
    # Single query for all delivered orders across all repartidores
    # costo_envio is a @property so we pull the raw columns and compute in Python
    todos_entregados = (
        Order.query
        .filter(Order.repartidor_id.in_(rep_ids), Order.estado == "entregado")
        .with_entities(Order.repartidor_id, Order.total, Order.subtotal, Order.descuento, Order.metodo_pago)
        .all()
    ) if rep_ids else []
    # Single aggregation query for pending commissions
    comisiones_rows = (
        db.session.query(StaffPayment.user_id, db.func.sum(StaffPayment.monto))
        .filter(
            StaffPayment.user_id.in_(rep_ids),
            StaffPayment.tipo == "comision",
            StaffPayment.pagado == False,
        )
        .group_by(StaffPayment.user_id)
        .all()
    ) if rep_ids else []
    comisiones_map = {uid: float(s) for uid, s in comisiones_rows}

    pedidos_por_rep = defaultdict(list)
    for row in todos_entregados:
        pedidos_por_rep[row.repartidor_id].append(row)

    resumen_repartidores = []
    for rep in repartidores:
        pedidos_rep = pedidos_por_rep[rep.id]
        recaudado = sum(float(p.total or 0) for p in pedidos_rep if normalizar_metodo_pago(p.metodo_pago) == "efectivo")
        reparto_generado = sum(
            max(0.0, float(p.total or 0) - float(p.subtotal or 0) + float(p.descuento or 0))
            for p in pedidos_rep
        )
        comision_pendiente = comisiones_map.get(rep.id, 0.0)
        resumen_repartidores.append({
            "repartidor": rep,
            "entregas": len(pedidos_rep),
            "recaudado": float(recaudado),
            "reparto_generado": float(reparto_generado),
            "comision_pendiente": float(comision_pendiente),
            "saldo_a_entregar": float(recaudado) - float(comision_pendiente),
        })

    return render_template("admin/pagos_staff.html",
                           empleados=empleados,
                           pagos=pagos,
                           total_pendiente=total_pendiente,
                           total_pagado=total_pagado,
                           resumen_repartidores=resumen_repartidores,
                           user_id_f=user_id_f,
                           pagado_f=pagado_f,
                           tipo_f=tipo_f)


@admin_bp.route("/pagos-staff/crear", methods=["POST"])
@admin_required
def crear_pago_staff():
    user_id = request.form.get("user_id", type=int)
    tipo = request.form.get("tipo")
    concepto = request.form.get("concepto", "").strip()
    periodo_inicio = request.form.get("periodo_inicio")
    periodo_fin = request.form.get("periodo_fin")

    tipos_validos = ["salario", "comision", "bonus", "adelanto", "descuento"]
    try:
        monto = float(request.form.get("monto", 0) or 0)
    except (ValueError, TypeError):
        monto = 0.0
    if not user_id or tipo not in tipos_validos or monto <= 0:
        flash("Datos inválidos.", "danger")
        return redirect(url_for("admin.pagos_staff"))

    try:
        pi = _parse_date_strict(periodo_inicio) if periodo_inicio else None
        pf = _parse_date_strict(periodo_fin) if periodo_fin else None
    except ValueError as e:
        flash(str(e), "danger")
        return redirect(url_for("admin.pagos_staff"))

    pago = StaffPayment(
        user_id=user_id,
        tipo=tipo,
        monto=monto,
        concepto=concepto,
        periodo_inicio=pi,
        periodo_fin=pf,
        registrado_por=current_user.id,
    )
    db.session.add(pago)
    try:
        db.session.commit()
        flash("Registro de pago creado.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al crear pago: {exc}", "danger")
    return redirect(url_for("admin.pagos_staff"))


@admin_bp.route("/pagos-staff/<int:pago_id>/pagar", methods=["POST"])
@admin_required
def marcar_pago_pagado(pago_id):
    pago = get_or_404(StaffPayment, pago_id)
    if pago.pagado:
        flash("Este pago ya fue marcado como pagado.", "info")
        return redirect(url_for("admin.pagos_staff"))

    pago.marcar_pagado()
    if pago.tipo != "descuento":
        registrar_egreso(float(pago.monto),
                         f"Pago staff: {pago.empleado.nombre} — {pago.descripcion_completa}",
                         categoria="pago_staff",
                         staff_payment_id=pago.id,
                         registrado_por=current_user.id)
    AffiliateUse.query.filter_by(staff_payment_id=pago.id).update(
        {"comision_pagada": True}, synchronize_session=False
    )
    try:
        db.session.commit()
        flash(f"Pago a {pago.empleado.nombre} marcado como pagado.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al procesar el pago: {exc}", "danger")
    return redirect(url_for("admin.pagos_staff"))


@admin_bp.route("/pagos-staff/pagar-seleccion", methods=["POST"])
@admin_required
def pagar_seleccion():
    """Pagar múltiples registros a la vez."""
    ids = request.form.getlist("pago_ids", type=int)
    if not ids:
        flash("No seleccionaste ningún pago.", "warning")
        return redirect(url_for("admin.pagos_staff"))
    pagos = StaffPayment.query\
        .filter(StaffPayment.id.in_(ids), StaffPayment.pagado == False).all()
    procesados = 0
    for pago in pagos:
        pago.marcar_pagado()
        if pago.tipo != "descuento":
            registrar_egreso(float(pago.monto),
                             f"Pago staff: {pago.empleado.nombre} — {pago.descripcion_completa}",
                             categoria="pago_staff",
                             staff_payment_id=pago.id,
                             registrado_por=current_user.id)
        AffiliateUse.query.filter_by(staff_payment_id=pago.id).update(
            {"comision_pagada": True}, synchronize_session=False
        )
        procesados += 1
    try:
        db.session.commit()
        flash(f"{procesados} pago(s) procesados.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al procesar pagos: {exc}", "danger")
    return redirect(url_for("admin.pagos_staff"))


@admin_bp.route("/pagos-staff/generar-comisiones-repartidores", methods=["POST"])
@admin_required
def generar_comisiones_repartidores():
    """Crea una comisión individual por el envío cobrado en cada entrega."""
    periodo_inicio = request.form.get("periodo_inicio")
    periodo_fin = request.form.get("periodo_fin")
    if not periodo_inicio or not periodo_fin:
        flash("Define el período.", "danger")
        return redirect(url_for("admin.pagos_staff"))
    try:
        fi = _parse_date_strict(periodo_inicio)
        ff = _parse_date_strict(periodo_fin)
    except ValueError as e:
        flash(str(e), "danger")
        return redirect(url_for("admin.pagos_staff"))
    if fi > ff:
        flash("La fecha de inicio debe ser anterior a la fecha fin.", "danger")
        return redirect(url_for("admin.pagos_staff"))

    from sqlalchemy import func
    # Contar entregas por repartidor que aún no tengan comisión individual.
    # Si el repartidor confirmó entrega, generar_comision_entrega() ya crea StaffPayment
    # con pedido_id; este cierre periódico cubre pedidos históricos o migrados.
    pedidos_entregados = Order.query.filter(
        Order.estado == "entregado",
        Order.repartidor_id.isnot(None),
        func.date(Order.entregado_en) >= fi,
        func.date(Order.entregado_en) <= ff,
    ).all()

    creados = 0
    for pedido in pedidos_entregados:
        ya_tiene_comision = StaffPayment.query.filter_by(
            user_id=pedido.repartidor_id,
            tipo="comision",
            pedido_id=pedido.id,
        ).first()
        if not ya_tiene_comision and generar_comision_entrega(pedido):
            creados += 1
    try:
        db.session.commit()
        flash(f"Generadas {creados} comisiones de repartidores para el período.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al guardar comisiones: {exc}", "danger")
    return redirect(url_for("admin.pagos_staff"))


@admin_bp.route("/pagos-staff/generar-salarios", methods=["POST"])
@admin_required
def generar_salarios():
    """Genera un registro de salario mensual para cada empleado con salario_base > 0."""
    periodo_inicio = request.form.get("periodo_inicio")
    periodo_fin = request.form.get("periodo_fin")
    if not periodo_inicio or not periodo_fin:
        flash("Define el período.", "danger")
        return redirect(url_for("admin.pagos_staff"))
    try:
        fi = _parse_date_strict(periodo_inicio)
        ff = _parse_date_strict(periodo_fin)
    except ValueError as e:
        flash(str(e), "danger")
        return redirect(url_for("admin.pagos_staff"))
    if fi > ff:
        flash("La fecha de inicio debe ser anterior a la fecha fin.", "danger")
        return redirect(url_for("admin.pagos_staff"))

    empleados = User.query.filter(
        User.rol.in_(["staff", "cocina", "preparacion", "repartidor"]),
        User.activo == True,
        User.salario_base > 0
    ).all()

    creados = 0
    for emp in empleados:
        # Evitar duplicados del mismo período
        existe = StaffPayment.query.filter_by(
            user_id=emp.id, tipo="salario",
            periodo_inicio=fi, periodo_fin=ff
        ).first()
        if not existe:
            pago = StaffPayment(
                user_id=emp.id,
                tipo="salario",
                monto=emp.salario_base,
                concepto=f"Salario {fi.strftime('%B %Y')}",
                periodo_inicio=fi,
                periodo_fin=ff,
                registrado_por=current_user.id,
            )
            db.session.add(pago)
            creados += 1

    try:
        db.session.commit()
        flash(f"Se generaron {creados} registros de salario.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al guardar salarios: {exc}", "danger")
    return redirect(url_for("admin.pagos_staff"))


# ─── LIQUIDACIÓN DE PROVEEDORES ──────────────

@admin_bp.route("/liquidacion-proveedores", methods=["GET", "POST"])
@admin_required
def liquidacion_proveedores():
    from datetime import datetime as _dt

    fecha_inicio_str = request.values.get("fecha_inicio", "")
    fecha_fin_str    = request.values.get("fecha_fin", "")

    try:
        fecha_inicio = _dt.strptime(fecha_inicio_str, "%Y-%m-%d").date() if fecha_inicio_str else date.today().replace(day=1)
        fecha_fin    = _dt.strptime(fecha_fin_str,    "%Y-%m-%d").date() if fecha_fin_str    else date.today()
    except ValueError:
        flash("Fechas inválidas.", "danger")
        fecha_inicio = date.today().replace(day=1)
        fecha_fin    = date.today()

    if fecha_inicio > fecha_fin:
        flash("La fecha de inicio debe ser anterior o igual a la fecha fin.", "warning")
        fecha_inicio, fecha_fin = fecha_fin, fecha_inicio

    # Pedidos entregados en el período
    pedidos = Order.query.filter(
        Order.estado == "entregado",
        db.func.date(Order.entregado_en) >= fecha_inicio,
        db.func.date(Order.entregado_en) <= fecha_fin,
    ).all()

    # Agrupar por proveedor usando snapshot (proveedor_id congelado en metadata_json)
    por_proveedor = {}   # {proveedor_id: {"proveedor": User|None, "lineas": [...], "total": Decimal, "sin_costo": [...]}}
    total_ingresos = Decimal("0")
    total_costo_proveedores = Decimal("0")

    for pedido in pedidos:
        total_ingresos += Decimal(str(pedido.total or 0))
        for item in pedido.items:
            snap = item.producto_snapshot
            pid = snap.get("proveedor_id") or (item.producto.proveedor_id if item.producto else None)
            if not pid:
                continue  # producto propio (bebidas / almacén) — sin costo proveedor
            # Costo: primero del snapshot (datos congelados al crear el pedido), luego del producto actual
            costo_snap = snap.get("precio_costo")
            costo_unit = Decimal(str(costo_snap)) if costo_snap is not None else Decimal("0")
            if costo_unit <= 0 and item.producto and item.producto.precio_costo:
                costo_unit = Decimal(str(item.producto.precio_costo))
            bucket = por_proveedor.setdefault(pid, {
                "proveedor": None,
                "lineas": [],
                "sin_costo": [],
                "total": Decimal("0"),
            })
            if costo_unit <= 0:
                # Registrar como alerta en lugar de ignorar silenciosamente
                bucket["sin_costo"].append({
                    "pedido": pedido,
                    "nombre": item.display_nombre,
                    "cantidad": item.cantidad,
                })
                continue
            subtotal_costo = costo_unit * item.cantidad
            bucket["lineas"].append({
                "pedido": pedido,
                "nombre": item.display_nombre,
                "cantidad": item.cantidad,
                "costo_unit": costo_unit,
                "subtotal": subtotal_costo,
            })
            bucket["total"] += subtotal_costo
            total_costo_proveedores += subtotal_costo

    # Resolver nombres de proveedores
    if por_proveedor:
        usuarios = {u.id: u for u in User.query.filter(User.id.in_(list(por_proveedor.keys()))).all()}
        for pid, bucket in por_proveedor.items():
            bucket["proveedor"] = usuarios.get(pid)

    margen_neto = total_ingresos - total_costo_proveedores

    # Proveedores registrados (para el select de pagos rápidos)
    proveedores_activos = User.query.filter_by(rol="proveedor", activo=True).order_by(User.nombre).all()

    if request.method == "POST" and request.form.get("accion") == "registrar_liquidacion":
        prov_id = request.form.get("prov_liquidar_id", type=int)
        monto   = request.form.get("prov_liquidar_monto")
        concepto = request.form.get("prov_liquidar_concepto", "").strip() or f"Liquidación {fecha_inicio}–{fecha_fin}"
        try:
            monto_f = float(monto or 0)
        except ValueError:
            monto_f = 0.0
        if not prov_id or monto_f <= 0:
            flash("Selecciona un proveedor y un monto válido.", "danger")
        else:
            proveedor = db.session.get(User, prov_id)
            if not proveedor or proveedor.rol != "proveedor" or not proveedor.activo:
                flash("El destinatario debe ser un proveedor activo.", "danger")
                return redirect(url_for(
                    "admin.liquidacion_proveedores",
                    fecha_inicio=fecha_inicio_str,
                    fecha_fin=fecha_fin_str,
                ))
            pago = StaffPayment(
                user_id=prov_id,
                tipo="liquidacion_proveedor",
                monto=monto_f,
                concepto=concepto,
                periodo_inicio=fecha_inicio,
                periodo_fin=fecha_fin,
                registrado_por=current_user.id,
            )
            db.session.add(pago)
            try:
                db.session.commit()
                flash("Liquidación registrada correctamente.", "success")
            except Exception as exc:
                db.session.rollback()
                flash(f"Error al registrar: {exc}", "danger")
        return redirect(url_for("admin.liquidacion_proveedores",
                                fecha_inicio=fecha_inicio_str, fecha_fin=fecha_fin_str))

    return render_template(
        "admin/liquidacion_proveedores.html",
        por_proveedor=por_proveedor,
        total_ingresos=total_ingresos,
        total_costo_proveedores=total_costo_proveedores,
        margen_neto=margen_neto,
        fecha_inicio=fecha_inicio,
        fecha_fin=fecha_fin,
        proveedores_activos=proveedores_activos,
    )


# ─── STOCK ───────────────────────────────────

@admin_bp.route("/stock")
@admin_required
def stock():
    lotes = Stock.query.join(Product).order_by(Stock.fecha_caducidad.asc().nullslast()).all()
    productos = Product.query.filter_by(activo=True).order_by(Product.nombre).all()
    return render_template("admin/stock.html",
                           lotes=lotes, productos=productos,
                           alertas_dias=current_app.config["ALERTA_CADUCIDAD_DIAS"])


@admin_bp.route("/stock/agregar", methods=["POST"])
@admin_required
def agregar_stock():
    producto_id = request.form.get("producto_id", type=int)
    cantidad = request.form.get("cantidad", type=int)
    if not producto_id or not db.session.get(Product, producto_id):
        flash("Producto inválido.", "danger")
        return redirect(url_for("admin.stock"))
    if cantidad is None or cantidad <= 0:
        flash("La cantidad debe ser mayor que 0.", "danger")
        return redirect(url_for("admin.stock"))

    lote = request.form.get("lote", "").strip() or None
    fecha_cad = request.form.get("fecha_caducidad", "").strip() or None
    ubicacion = request.form.get("ubicacion", "").strip() or None
    alerta_dias = request.form.get("alerta_dias", 7, type=int) or 7

    try:
        fecha_caducidad = _parse_date_strict(fecha_cad) if fecha_cad else None
    except ValueError as e:
        flash(str(e), "danger")
        return redirect(url_for("admin.stock"))

    entrada = Stock(
        producto_id=producto_id, cantidad=cantidad, lote=lote,
        fecha_caducidad=fecha_caducidad, ubicacion=ubicacion, alerta_dias=alerta_dias,
    )
    db.session.add(entrada)
    AuditLog.registrar(current_user.id, "agregar_stock", "product",
                       producto_id, detalle=f"+{cantidad} uds — lote {lote or 'sin lote'}",
                       ip=request.remote_addr)
    try:
        db.session.commit()
        flash("Stock registrado.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al registrar stock: {exc}", "danger")
    return redirect(url_for("admin.stock"))


@admin_bp.route("/stock/<int:lote_id>/ajustar", methods=["POST"])
@admin_required
def ajustar_stock(lote_id):
    lote = get_or_404(Stock, lote_id)
    nueva = request.form.get("cantidad", type=int)
    if nueva is None or nueva < 0:
        flash("Cantidad inválida.", "danger")
        return redirect(url_for("admin.stock"))
    anterior = lote.cantidad
    lote.cantidad = nueva
    AuditLog.registrar(current_user.id, "ajustar_stock", "stock",
                       lote_id, detalle=f"{anterior}→{nueva} uds (producto {lote.producto_id})",
                       ip=request.remote_addr)
    try:
        db.session.commit()
        flash("Stock ajustado.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al ajustar stock: {exc}", "danger")
    return redirect(url_for("admin.stock"))


# ─── PRODUCTOS ───────────────────────────────

@admin_bp.route("/productos")
@admin_required
def productos():
    q = (request.args.get("q") or "").strip()
    categoria_id = request.args.get("categoria_id", type=int)
    estado = request.args.get("estado", "")
    tipo = request.args.get("tipo", "")
    query = Product.query
    if q:
        query = query.filter(or_(Product.nombre.ilike(f"%{q}%"),
                                 Product.descripcion.ilike(f"%{q}%")))
    if categoria_id:
        query = query.filter(Product.categoria_id == categoria_id)
    if estado == "activo":
        query = query.filter(Product.activo == True)
    elif estado == "inactivo":
        query = query.filter(Product.activo == False)
    if tipo == "producto":
        query = query.filter(Product.es_combo == False)
    elif tipo == "combo":
        query = query.filter(Product.es_combo == True)
    prods = query.order_by(Product.nombre).all()
    categorias = Categoria.query.filter_by(activo=True).order_by(Categoria.nombre).all()
    proveedores = User.query.filter_by(rol="proveedor", activo=True).order_by(User.nombre).all()
    resumen = {
        "total": Product.query.count(),
        "activos": Product.query.filter_by(activo=True).count(),
        "combos": Product.query.filter_by(es_combo=True).count(),
        "canjeables": Product.query.filter_by(canjeable_con_puntos=True, activo=True).count(),
    }
    return render_template("admin/productos.html", productos=prods, categorias=categorias,
                           proveedores=proveedores,
                           resumen=resumen, q=q, categoria_id=categoria_id,
                           estado=estado, tipo=tipo)


def _parsear_campos_producto(form):
    """Extrae y convierte todos los campos del formulario de producto."""
    from datetime import datetime as _dt

    def parse_time(val):
        if val and val.strip():
            try:
                return _dt.strptime(val.strip(), "%H:%M").time()
            except ValueError:
                return None
        return None

    def parse_date(val):
        if val and val.strip():
            try:
                return _dt.strptime(val.strip(), "%Y-%m-%d").date()
            except ValueError:
                return None
        return None

    # Días de la semana seleccionados (checkboxes con name="dia_semana" y values "0"-"6")
    dias = form.getlist("dias_semana")
    dias_json = json.dumps([int(d) for d in dias]) if dias else None

    attrs_raw = (form.get("atributos_json") or "").strip()
    atributos_json = None
    if attrs_raw:
        try:
            json.loads(attrs_raw)
            atributos_json = attrs_raw
        except json.JSONDecodeError:
            return None, "Atributos JSON no válidos."

    # Validaciones de negocio
    try:
        precio = float(form.get("precio") or 0)
    except (ValueError, TypeError):
        return None, "El precio debe ser un número válido."
    if precio <= 0:
        return None, "El precio debe ser mayor que 0."

    precio_costo = form.get("precio_costo", type=float)
    if precio_costo is not None and precio_costo < 0:
        return None, "El precio de costo no puede ser negativo."

    nombre = form.get("nombre", "").strip()
    if not nombre:
        return None, "El nombre del producto es obligatorio."

    categoria_id = form.get("categoria_id", type=int)
    if categoria_id and not Categoria.query.filter_by(id=categoria_id, activo=True).first():
        return None, "La categoría seleccionada no existe o está inactiva."

    _CANALES_PREP_VALIDOS = {"cocina", "almacen"}
    canal_preparacion = form.get("canal_preparacion", "cocina")
    if canal_preparacion not in _CANALES_PREP_VALIDOS:
        canal_preparacion = "cocina"

    _TIPOS_ENTREGA_VALIDOS = {"inmediato", "programado"}
    tipo_entrega = form.get("tipo_entrega", "inmediato")
    if tipo_entrega not in _TIPOS_ENTREGA_VALIDOS:
        tipo_entrega = "inmediato"
    fecha_llegada = parse_date(form.get("fecha_llegada"))
    if tipo_entrega == "programado" and not fecha_llegada:
        return None, "Indica la fecha de llegada para productos programados."
    if tipo_entrega == "programado" and fecha_llegada < date.today():
        return None, "La fecha de llegada no puede estar en el pasado."

    hora_inicio = parse_time(form.get("hora_inicio_visibilidad"))
    hora_fin = parse_time(form.get("hora_fin_visibilidad"))
    if bool(hora_inicio) != bool(hora_fin):
        return None, "Indica hora de inicio y hora de fin, o deja ambas vacías."

    canjeable = bool(form.get("canjeable_con_puntos"))
    puntos_para_canje = form.get("puntos_para_canje", type=int)
    if canjeable and (not puntos_para_canje or puntos_para_canje <= 0):
        return None, "Indica cuántos puntos se necesitan para el canje (debe ser > 0)."
    es_hipoalergenico = bool(form.get("es_hipoalergenico"))
    alergenos = [] if es_hipoalergenico else form.getlist("alergenos")

    proveedor_id = form.get("proveedor_id", type=int) or None
    if proveedor_id and not User.query.filter_by(
        id=proveedor_id,
        rol="proveedor",
        activo=True,
    ).first():
        return None, "El proveedor seleccionado no existe, está inactivo o no tiene rol de proveedor."
    if proveedor_id and canal_preparacion != "cocina":
        return None, "Un producto de proveedor debe usar el canal de preparación cocina."

    return {
        "nombre":                    nombre,
        "descripcion":               form.get("descripcion", "").strip(),
        "precio":                    precio,
        "precio_costo":              precio_costo,
        "categoria_id":              categoria_id,
        "origen_pais":               form.get("origen_pais", "").strip(),
        "tipo_producto":             (form.get("tipo_producto") or "simple").strip(),
        "canal_preparacion":         canal_preparacion,
        "proveedor_id":              proveedor_id,
        "atributos_json":            atributos_json,
        "es_combo":                  bool(form.get("es_combo")),
        "imagen_url":                _normalizar_imagen_url(form.get("imagen_url")),
        # tipo entrega
        "tipo_entrega":              tipo_entrega,
        "fecha_llegada":             fecha_llegada if tipo_entrega == "programado" else None,
        "dias_anticipacion_encargo": 1,
        # visibilidad horaria
        "hora_inicio_visibilidad":   hora_inicio,
        "hora_fin_visibilidad":      hora_fin,
        "dias_semana_json":          dias_json,
        # visualización stock
        "stock_mostrar_en_web":      bool(form.get("stock_mostrar_en_web")),
        # canje con puntos
        "canjeable_con_puntos":      canjeable,
        "puntos_para_canje":         puntos_para_canje if canjeable else None,
        # hipoalergénicos / alérgenos EU
        "es_hipoalergenico":         es_hipoalergenico,
        "alergenos_json":            json.dumps(alergenos) if alergenos else None,
        "alergenos_info":            None,
    }, None


def _guardar_imagen_producto_desde_request(files):
    f = files.get("imagen_archivo")
    if not f or not getattr(f, "filename", None):
        return None
    filename = f.filename.lower()
    if not filename.endswith((".jpg", ".jpeg", ".png", ".webp")):
        return None
    return _save_image(f, "productos", f"prod_{uuid.uuid4().hex[:12]}.jpg")


def _validar_producto_componente_combo(combo_id, producto_id):
    """
    Valida que un producto sea válido como componente usando validadores robustos.

    Returns:
        (producto_obj, error_message)
    """
    if not producto_id:
        return None, "Selecciona un producto para el componente."

    is_valid, error_msg = validate_component_product(combo_id, producto_id)
    if not is_valid:
        return None, error_msg

    producto = db.session.get(Product, producto_id)
    return producto, None


def _combo_limits_payload():
    """Devuelve los límites efectivos que usa backend y frontend para combos."""
    return {
        "max_qty": ComboLimits.max_qty_per_component(),
        "max_selections": ComboLimits.max_selections_per_group(),
        "max_components": ComboLimits.max_components(),
        "min_components": ComboLimits.min_components(),
        "max_discount_pct": ComboLimits.max_discount_percentage(),
    }


def _money(value):
    return Decimal(str(value or 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _calcular_base_precio_combo(componentes):
    total = Decimal("0.00")
    grupos = {}
    for item in componentes:
        if isinstance(item, dict):
            es_sel = bool(item.get("es_seleccionable"))
            cantidad = max(1, int(item.get("cantidad") or 1))
            precio_unit = _money(item.get("precio_unit") or 0)
            precio_extra = _money(item.get("precio_extra") or 0)
            grupo = (item.get("grupo_seleccion") or "Seleccion").strip() or "Seleccion"
            max_sel = max(1, int(item.get("max_selecciones") or 1))
            es_default = bool(item.get("es_predeterminado"))
        else:
            componente = getattr(item, "componente", None)
            if not componente:
                continue
            es_sel = bool(getattr(item, "es_seleccionable", False))
            cantidad = max(1, int(getattr(item, "cantidad", 1) or 1))
            precio_unit = _money(componente.precio_final)
            precio_extra = _money(getattr(item, "precio_extra", 0) or 0)
            grupo = (getattr(item, "grupo_seleccion", None) or "Seleccion").strip() or "Seleccion"
            max_sel = max(1, int(getattr(item, "max_selecciones", 1) or 1))
            es_default = bool(getattr(item, "es_predeterminado", False))

        subtotal = precio_unit * cantidad
        if es_sel:
            grupos.setdefault(grupo.lower(), {"max": max_sel, "opciones": []})
            grupos[grupo.lower()]["max"] = max(grupos[grupo.lower()]["max"], max_sel)
            grupos[grupo.lower()]["opciones"].append((subtotal, es_default))
        else:
            total += subtotal

    for data in grupos.values():
        defaults = [price for price, is_default in data["opciones"] if is_default][:data["max"]]
        if defaults:
            total += sum(defaults, Decimal("0.00"))
        elif data["opciones"]:
            total += min(price for price, _ in data["opciones"])
    return _money(total)


def _precio_descuento_combo(base, descuento_pct):
    pct = Decimal(str(descuento_pct or 0))
    pct = min(Decimal("100"), max(Decimal("0"), pct))
    return max(Decimal("0.01"), _money(_money(base) * (Decimal("1") - pct / Decimal("100"))))


def _aplicar_precio_combo_desde_form(combo, form, componentes, combo_limits):
    modo = (form.get("combo_precio_modo") or "fijo").strip().lower()
    if modo not in ("fijo", "descuento_porcentaje"):
        return "Modo de precio del combo inválido."

    base = _calcular_base_precio_combo(componentes)
    if modo == "fijo":
        precio = form.get("precio", type=float)
        is_valid, error_msg = validate_combo_pricing(precio if precio is not None else 0)
        if not is_valid:
            return error_msg
        combo.combo_precio_modo = "fijo"
        combo.combo_descuento_pct = 0
        combo.combo_precio_base = base
        combo.precio = _money(precio)
        return None

    descuento = form.get("combo_descuento_pct", type=float)
    is_valid, error_msg = validate_combo_pricing(1, descuento)
    if not is_valid:
        return error_msg
    if base <= 0:
        return "Añade componentes con precio antes de usar descuento porcentual."

    max_pct = float(combo_limits["max_discount_pct"])
    descuento = min(max(descuento or 0, 0), max_pct)
    precio_final = _precio_descuento_combo(base, descuento)
    is_valid, error_msg = validate_combo_pricing(float(precio_final), descuento)
    if not is_valid:
        return error_msg
    combo.combo_precio_modo = "descuento_porcentaje"
    combo.combo_descuento_pct = _money(descuento)
    combo.combo_precio_base = base
    combo.precio = precio_final
    return None


def _recalcular_precio_combo_si_descuento(combo):
    if not combo or not combo.es_combo:
        return
    if combo.combo_precio_modo_normalizado != "descuento_porcentaje":
        return
    componentes = ComboItem.query.filter_by(combo_id=combo.id).all()
    base = _calcular_base_precio_combo(componentes)
    combo.combo_precio_base = base
    if base > 0:
        combo.precio = _precio_descuento_combo(base, combo.combo_descuento_pct_float)


def _validar_campos_componente_combo(es_seleccionable, grupo_seleccion, max_selecciones, cantidad):
    """
    Valida los campos de un componente usando validadores robustos.

    Returns:
        error_message (None if valid)
    """
    try:
        cantidad_int = int(cantidad)
    except (TypeError, ValueError):
        cantidad_int = 0
    try:
        max_sel_int = int(max_selecciones)
    except (TypeError, ValueError):
        max_sel_int = 0

    is_valid, error_msg = validate_component_quantity(
        cantidad_int,
        is_selectable=es_seleccionable
    )
    if not is_valid:
        return error_msg

    # Validar selecciones si es seleccionable
    if es_seleccionable:
        is_valid, error_msg = validate_selections_per_group(
            max_sel_int
        )
        if not is_valid:
            return error_msg

        is_valid, error_msg = validate_group_name(grupo_seleccion or "", es_seleccionable)
        if not is_valid:
            return error_msg

    return None


def _combo_group_name(tipo, nombre=None):
    nombre = (nombre or "").strip()
    if nombre:
        return nombre[:80]
    return "Base incluida" if tipo == "fijo" else "Eleccion"


def _find_or_create_combo_group(combo_id, *, tipo, nombre=None, max_selecciones=1, orden=0):
    tipo = "seleccion" if tipo in ("sel", "seleccion", "choice") else "fijo"
    nombre = _combo_group_name(tipo, nombre)
    query = ComboGroup.query.filter_by(combo_id=combo_id, tipo=tipo)
    if tipo == "fijo":
        group = query.order_by(ComboGroup.orden.asc(), ComboGroup.id.asc()).first()
    else:
        group = query.filter(db.func.lower(ComboGroup.nombre) == nombre.lower()).first()
    if group:
        if tipo == "seleccion":
            group.max_selecciones = max(1, int(max_selecciones or group.max_selecciones or 1))
            group.min_selecciones = min(group.max_selecciones, max(1, int(group.min_selecciones or 1)))
        return group

    max_sel = max(1, int(max_selecciones or 1))
    group = ComboGroup(
        combo_id=combo_id,
        nombre=nombre,
        tipo=tipo,
        min_selecciones=1 if tipo == "seleccion" else 0,
        max_selecciones=max_sel if tipo == "seleccion" else 1,
        orden=int(orden or 0),
        requerido=True,
    )
    db.session.add(group)
    db.session.flush()
    return group


def _combo_groups_payload_from_form(form):
    uids = form.getlist("combo_group_uid") or []
    names = form.getlist("combo_group_name") or []
    types = form.getlist("combo_group_type") or []
    max_sels = form.getlist("combo_group_max_sel") or []
    orders = form.getlist("combo_group_order") or []
    payload = {}
    for i, uid in enumerate(uids):
        uid = (uid or "").strip()
        if not uid:
            continue
        tipo_raw = (types[i] if i < len(types) else "fijo").strip().lower()
        tipo = "seleccion" if tipo_raw in ("sel", "seleccion", "choice") else "fijo"
        try:
            max_sel = int(max_sels[i]) if i < len(max_sels) and max_sels[i] else 1
        except (TypeError, ValueError):
            max_sel = 1
        try:
            orden = int(orders[i]) if i < len(orders) and orders[i] else i
        except (TypeError, ValueError):
            orden = i
        payload[uid] = {
            "tipo": tipo,
            "nombre": _combo_group_name(tipo, names[i] if i < len(names) else ""),
            "max_selecciones": max_sel,
            "orden": orden,
        }
    return payload


@admin_bp.route("/productos/crear", methods=["POST"])
@admin_required
def crear_producto():
    campos, error = _parsear_campos_producto(request.form)
    if error:
        flash(error, "danger")
        return redirect(url_for("admin.productos"))
    ruta_subida = _guardar_imagen_producto_desde_request(request.files)
    if ruta_subida:
        campos["imagen_url"] = ruta_subida
    campos["es_combo"] = False
    campos["tipo_producto"] = "simple"
    p = Product(**campos)
    db.session.add(p)
    try:
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al crear producto: {exc}", "danger")
        return redirect(url_for("admin.productos"))
    notificar_bot_sync()
    flash(f"Producto '{p.nombre}' creado.", "success")
    return redirect(url_for("admin.productos"))


@admin_bp.route("/combos/nuevo", methods=["GET", "POST"])
@admin_required
def nuevo_combo():
    """
    Crea un nuevo combo con componentes.
    Usa validadores robustos y configuración dinámica (sin hardcoding).
    """
    categorias = Categoria.query.filter_by(activo=True).order_by(Categoria.nombre).all()
    productos_simples = (
        Product.query.filter_by(activo=True, es_combo=False)
        .order_by(Product.nombre).all()
    )
    proveedores = User.query.filter_by(rol="proveedor", activo=True).order_by(User.nombre).all()

    combo_limits = _combo_limits_payload()

    if request.method == "GET":
        return render_template(
            "admin/nuevo_combo.html",
            categorias=categorias,
            productos_simples=productos_simples,
            proveedores=proveedores,
            combo_limits=combo_limits,
        )

    # ── POST: Validar y crear combo + componentes en transacción ──

    # Parsear campos básicos del combo. En modo descuento el precio final se calcula
    # despues de validar componentes, por eso usamos un precio temporal valido.
    form_producto = request.form.copy()
    if (form_producto.get("combo_precio_modo") or "").strip().lower() == "descuento_porcentaje":
        try:
            precio_tmp = float(form_producto.get("precio") or 0)
        except (TypeError, ValueError):
            precio_tmp = 0
        if precio_tmp <= 0:
            form_producto["precio"] = "1.00"
    campos, error = _parsear_campos_producto(form_producto)
    if error:
        flash(error, "danger")
        return render_template(
            "admin/nuevo_combo.html",
            categorias=categorias,
            productos_simples=productos_simples,
            proveedores=proveedores,
            combo_limits=combo_limits,
        )

    campos["es_combo"] = True
    campos["tipo_producto"] = "combo"

    ruta_subida = _guardar_imagen_producto_desde_request(request.files)
    if ruta_subida:
        campos["imagen_url"] = ruta_subida

    # Crear objeto combo (sin commit aún)
    combo = Product(**campos)
    db.session.add(combo)
    db.session.flush()  # Para obtener ID sin commit

    # ── Obtener arrays paralelos del formulario ──
    prod_ids = request.form.getlist("comp_prod_id") or []
    cantidades = request.form.getlist("comp_cantidad") or []
    tipos = request.form.getlist("comp_tipo") or []       # "fijo" | "sel"
    grupos = request.form.getlist("comp_grupo") or []
    max_sels = request.form.getlist("comp_max_sel") or []
    extras = request.form.getlist("comp_precio_extra") or []
    defaults = request.form.getlist("comp_default") or []
    notas_prep = request.form.getlist("comp_notas_preparacion") or []
    group_uids = request.form.getlist("comp_group_uid") or []
    group_defs = _combo_groups_payload_from_form(request.form)

    # ── Validar consistencia de arrays paralelos ──
    parallel_arrays = [prod_ids, cantidades, tipos, grupos, max_sels]
    if group_uids:
        parallel_arrays.append(group_uids)
    if extras:
        parallel_arrays.append(extras)
    if defaults:
        parallel_arrays.append(defaults)
    if notas_prep:
        parallel_arrays.append(notas_prep)
    is_valid, error_msg = validate_parallel_arrays(*parallel_arrays)
    if not is_valid:
        db.session.rollback()
        flash(f"Error en validación: {error_msg}", "danger")
        return render_template(
            "admin/nuevo_combo.html",
            categorias=categorias,
            productos_simples=productos_simples,
            proveedores=proveedores,
            combo_limits=combo_limits,
        )

    # ── Procesar componentes ──
    componentes_para_agregar = []
    componentes_fijos = set()
    componentes_seleccionables = {}  # {grupo_lower: {prod_id, ...}}
    n_comp = 0

    for i, raw_id in enumerate(prod_ids):
        try:
            prod_id = int(raw_id)
        except (ValueError, TypeError):
            continue

        # Parsear valores individual del componente
        try:
            cant = int(cantidades[i]) if i < len(cantidades) and cantidades[i] else 1
        except (ValueError, TypeError):
            cant = 1

        tipo = tipos[i] if i < len(tipos) else "fijo"
        es_sel = tipo in ("sel", "1", "true", "True")
        group_uid = (group_uids[i].strip() if i < len(group_uids) and group_uids[i] else "")
        grupo = (grupos[i].strip() if i < len(grupos) and grupos[i] else "") or None
        group_def = group_defs.get(group_uid) if group_uid else None
        if group_def:
            es_sel = group_def["tipo"] == "seleccion"
            grupo = group_def["nombre"] if es_sel else None

        try:
            max_sel = int(max_sels[i]) if i < len(max_sels) and max_sels[i] else 1
        except (ValueError, TypeError):
            max_sel = 1
        if group_def:
            max_sel = int(group_def["max_selecciones"] or max_sel or 1)
        try:
            precio_extra = _money(extras[i] if i < len(extras) and extras[i] else 0)
        except Exception:
            precio_extra = Decimal("0.00")
        if precio_extra < 0:
            db.session.rollback()
            flash(f"Componente {i + 1}: el suplemento no puede ser negativo.", "danger")
            return render_template(
                "admin/nuevo_combo.html",
                categorias=categorias,
                productos_simples=productos_simples,
                proveedores=proveedores,
                combo_limits=combo_limits,
            )
        es_default = (defaults[i] if i < len(defaults) else "").strip().lower() in ("1", "true", "on", "si", "sí")
        nota_prep = (notas_prep[i].strip() if i < len(notas_prep) and notas_prep[i] else "")[:300]

        # ── Validar cantidad ──
        is_valid, error_msg = validate_component_quantity(cant, es_sel)
        if not is_valid:
            db.session.rollback()
            flash(f"Componente {i + 1}: {error_msg}", "danger")
            return render_template(
                "admin/nuevo_combo.html",
                categorias=categorias,
                productos_simples=productos_simples,
                proveedores=proveedores,
                combo_limits=combo_limits,
            )

        # ── Validar grupo y selecciones (si es seleccionable) ──
        if es_sel:
            is_valid, error_msg = validate_selections_per_group(max_sel)
            if not is_valid:
                db.session.rollback()
                flash(f"Componente {i + 1}: {error_msg}", "danger")
                return render_template(
                    "admin/nuevo_combo.html",
                    categorias=categorias,
                    productos_simples=productos_simples,
                    proveedores=proveedores,
                    combo_limits=combo_limits,
                )

            is_valid, error_msg = validate_group_name(grupo, True)
            if not is_valid:
                db.session.rollback()
                flash(f"Componente {i + 1}: {error_msg}", "danger")
                return render_template(
                    "admin/nuevo_combo.html",
                    categorias=categorias,
                    productos_simples=productos_simples,
                    proveedores=proveedores,
                    combo_limits=combo_limits,
                )

        # ── Validar producto como componente ──
        producto, comp_error = _validar_producto_componente_combo(combo.id, prod_id)
        if comp_error:
            db.session.rollback()
            flash(f"Componente {i + 1}: {comp_error}", "danger")
            return render_template(
                "admin/nuevo_combo.html",
                categorias=categorias,
                productos_simples=productos_simples,
                proveedores=proveedores,
                combo_limits=combo_limits,
            )

        # ── Detectar duplicados (fijos y seleccionables) ──
        if es_sel:
            grupo_key = (grupo or "").strip().lower()
            if grupo_key not in componentes_seleccionables:
                componentes_seleccionables[grupo_key] = set()

            if producto.id in componentes_seleccionables[grupo_key]:
                db.session.rollback()
                flash(
                    f"El producto '{producto.nombre}' está repetido dentro del grupo '{grupo}'.",
                    "danger"
                )
                return render_template(
                    "admin/nuevo_combo.html",
                    categorias=categorias,
                    productos_simples=productos_simples,
                    proveedores=proveedores,
                    combo_limits=combo_limits,
                )
            componentes_seleccionables[grupo_key].add(producto.id)
        else:
            if producto.id in componentes_fijos:
                db.session.rollback()
                flash(
                    f"El producto '{producto.nombre}' ya está como componente fijo. Ajusta la cantidad en una sola línea.",
                    "danger"
                )
                return render_template(
                    "admin/nuevo_combo.html",
                    categorias=categorias,
                    productos_simples=productos_simples,
                    proveedores=proveedores,
                    combo_limits=combo_limits,
                )
            componentes_fijos.add(producto.id)

        # ── Agregar a lista para insertar después ──
        componentes_para_agregar.append({
            'combo_id': combo.id,
            'producto_id': producto.id,
            'precio_unit': float(producto.precio_final or 0),
            'precio_extra': precio_extra,
            'cantidad': cant,
            'es_seleccionable': es_sel,
            'grupo_seleccion': grupo if es_sel else None,
            'max_selecciones': max_sel if es_sel else 1,
            'group_uid': group_uid,
            'orden': i,
            'es_predeterminado': es_default if es_sel else False,
            'notas_preparacion': nota_prep or None,
        })
        n_comp += 1

    # ── Validar cantidad mínima de componentes ──
    if n_comp < combo_limits["min_components"]:
        db.session.rollback()
        flash(
            f"Añade al menos {combo_limits['min_components']} componente para crear un combo funcional.",
            "danger"
        )
        return render_template(
            "admin/nuevo_combo.html",
            categorias=categorias,
            productos_simples=productos_simples,
            proveedores=proveedores,
            combo_limits=combo_limits,
        )

    # ── Validar máximo de componentes ──
    if n_comp > combo_limits["max_components"]:
        db.session.rollback()
        flash(
            f"No puedes añadir más de {combo_limits['max_components']} componentes.",
            "danger"
        )
        return render_template(
            "admin/nuevo_combo.html",
            categorias=categorias,
            productos_simples=productos_simples,
            proveedores=proveedores,
            combo_limits=combo_limits,
        )

    is_valid, error_msg = validate_combo_structure(componentes_para_agregar, combo.id)
    if not is_valid:
        db.session.rollback()
        flash(error_msg, "danger")
        return render_template(
            "admin/nuevo_combo.html",
            categorias=categorias,
            productos_simples=productos_simples,
            proveedores=proveedores,
            combo_limits=combo_limits,
        )

    # ── Validar restricción: combo con seleccionables no puede ser canje directo ──
    if combo.canjeable_con_puntos and componentes_seleccionables:
        db.session.rollback()
        flash(
            "Los combos con grupos seleccionables no pueden marcarse como canje directo con puntos.",
            "danger"
        )
        return render_template(
            "admin/nuevo_combo.html",
            categorias=categorias,
            productos_simples=productos_simples,
            proveedores=proveedores,
            combo_limits=combo_limits,
        )

    pricing_error = _aplicar_precio_combo_desde_form(
        combo,
        request.form,
        componentes_para_agregar,
        combo_limits,
    )
    if pricing_error:
        db.session.rollback()
        flash(pricing_error, "danger")
        return render_template(
            "admin/nuevo_combo.html",
            categorias=categorias,
            productos_simples=productos_simples,
            proveedores=proveedores,
            combo_limits=combo_limits,
        )

    # ── Crear secciones formales del combo y luego insertar componentes ──
    groups_by_uid = {}
    for uid, data in group_defs.items():
        groups_by_uid[uid] = _find_or_create_combo_group(
            combo.id,
            tipo=data["tipo"],
            nombre=data["nombre"],
            max_selecciones=data["max_selecciones"],
            orden=data["orden"],
        )

    for comp_data in componentes_para_agregar:
        group = groups_by_uid.get(comp_data.get("group_uid"))
        if not group:
            group = _find_or_create_combo_group(
                combo.id,
                tipo="seleccion" if comp_data.get("es_seleccionable") else "fijo",
                nombre=comp_data.get("grupo_seleccion"),
                max_selecciones=comp_data.get("max_selecciones") or 1,
                orden=len(groups_by_uid),
            )
        clean_comp_data = {
            key: value for key, value in comp_data.items()
            if key in {
                "combo_id", "producto_id", "cantidad", "es_seleccionable",
                "grupo_seleccion", "max_selecciones", "precio_extra",
                "es_predeterminado", "notas_preparacion",
            }
        }
        clean_comp_data["combo_group_id"] = group.id
        clean_comp_data["orden"] = comp_data.get("orden", 0)
        db.session.add(ComboItem(**clean_comp_data))

    # ── Commit de la transacción completa ──
    try:
        db.session.commit()
        notificar_bot_sync()
        flash(
            f"✓ Combo '{combo.nombre}' creado con {n_comp} componente{'s' if n_comp != 1 else ''}.",
            "success"
        )
    except Exception as exc:
        db.session.rollback()
        flash(f"❌ Error al crear combo: {exc}", "danger")
        return render_template(
            "admin/nuevo_combo.html",
            categorias=categorias,
            productos_simples=productos_simples,
            combo_limits=combo_limits,
        )

    return redirect(url_for("admin.gestionar_combo", producto_id=combo.id))


@admin_bp.route("/productos/<int:producto_id>/editar", methods=["GET", "POST"])
@admin_required
def editar_producto(producto_id):
    p = get_or_404(Product, producto_id)
    if request.method == "GET":
        categorias = Categoria.query.filter_by(activo=True).order_by(Categoria.nombre).all()
        try:
            dias_activos = json.loads(p.dias_semana_json or "[]")
        except (json.JSONDecodeError, TypeError):
            dias_activos = []
        try:
            alergenos_activos = json.loads(p.alergenos_json or "[]")
        except (json.JSONDecodeError, TypeError):
            alergenos_activos = []
        proveedores = User.query.filter_by(rol="proveedor", activo=True).order_by(User.nombre).all()
        return render_template("admin/producto_editar.html",
                               producto=p,
                               categorias=categorias,
                               dias_activos=dias_activos,
                               alergenos_activos=alergenos_activos,
                               proveedores=proveedores)
    campos, error = _parsear_campos_producto(request.form)
    if error:
        flash(error, "danger")
        return redirect(url_for("admin.productos"))
    # Guardar imagen DESPUÉS de validar el formulario para no dejar archivos huérfanos
    ruta_subida = _guardar_imagen_producto_desde_request(request.files)
    if ruta_subida:
        if p.imagen_url and p.imagen_url.startswith("productos/"):
            _borrar_imagen(p.imagen_url)
        campos["imagen_url"] = ruta_subida
    elif not campos.get("imagen_url"):
        campos["imagen_url"] = p.imagen_url
    if p.es_combo:
        campos["es_combo"] = True
        campos["tipo_producto"] = "combo"
        if campos.get("canjeable_con_puntos") and ComboItem.query.filter_by(
            combo_id=p.id, es_seleccionable=True
        ).first():
            flash("Los combos con grupos seleccionables no pueden marcarse como canje directo con puntos.", "danger")
            return redirect(url_for("admin.productos"))
    precio_anterior = float(p.precio)
    for attr, val in campos.items():
        setattr(p, attr, val)
    nuevo_activo = bool(request.form.get("activo"))
    if p.activo and not nuevo_activo:
        combos_afectados = ComboItem.query.filter_by(producto_id=p.id).count()
        if combos_afectados > 0:
            flash(
                f"Este producto es componente de {combos_afectados} combo(s). "
                "Elimínalo de los combos primero.",
                "warning",
            )
            return redirect(url_for("admin.productos"))
    p.activo = nuevo_activo
    if precio_anterior != float(p.precio):
        db.session.add(PriceHistory(
            producto_id=p.id,
            precio_anterior=precio_anterior,
            precio_nuevo=float(p.precio),
            cambiado_por=current_user.id,
            motivo=request.form.get("motivo_precio", ""),
        ))
    try:
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al actualizar producto: {exc}", "danger")
        return redirect(url_for("admin.productos"))
    notificar_bot_sync()
    flash("Producto actualizado.", "success")
    return redirect(url_for("admin.productos"))


# ─── COMBOS ──────────────────────────────────

@admin_bp.route("/productos/<int:producto_id>/combo", methods=["GET"])
@admin_required
def gestionar_combo(producto_id):
    """Vista para gestionar los componentes de un combo fijo."""
    combo = get_or_404(Product, producto_id)
    if not combo.es_combo:
        flash("Este producto no es un combo.", "warning")
        return redirect(url_for("admin.productos"))
    componentes = ComboItem.query.filter_by(combo_id=producto_id).all()
    combo_groups = ComboGroup.query.filter_by(combo_id=producto_id)\
        .order_by(ComboGroup.orden.asc(), ComboGroup.id.asc()).all()
    productos_simples = Product.query.filter_by(activo=True, es_combo=False).order_by(Product.nombre).all()

    combo_limits = _combo_limits_payload()

    return render_template("admin/combo_detalle.html",
                           combo=combo,
                           componentes=componentes,
                           combo_groups=combo_groups,
                           productos_simples=productos_simples,
                           combo_limits=combo_limits)


@admin_bp.route("/productos/<int:producto_id>/combo/agregar", methods=["POST"])
@admin_required
def agregar_componente_combo(producto_id):
    combo = get_or_404(Product, producto_id)
    if not combo.es_combo:
        return redirect(url_for("admin.productos"))
    combo_limits = _combo_limits_payload()
    comp_id = request.form.get("producto_id", type=int)
    cantidad = request.form.get("cantidad", 1, type=int)
    total_componentes = ComboItem.query.filter_by(combo_id=producto_id).count()
    componente, comp_error = _validar_producto_componente_combo(producto_id, comp_id)
    if comp_error:
        flash(comp_error, "danger")
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
    es_seleccionable = bool(request.form.get("es_seleccionable"))
    grupo_seleccion = request.form.get("grupo_seleccion", "").strip() or None
    max_selecciones = request.form.get("max_selecciones", 1, type=int) or 1
    precio_extra = _money(request.form.get("precio_extra") or 0)
    if precio_extra < 0:
        flash("El suplemento no puede ser negativo.", "danger")
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
    es_predeterminado = bool(request.form.get("es_predeterminado"))
    notas_preparacion = (request.form.get("notas_preparacion") or "").strip()[:300] or None
    field_error = _validar_campos_componente_combo(
        es_seleccionable, grupo_seleccion, max_selecciones, cantidad
    )
    if field_error:
        flash(field_error, "danger")
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))

    existente_fijo = ComboItem.query.filter_by(
        combo_id=producto_id,
        producto_id=componente.id,
        es_seleccionable=False,
    ).first()
    if not es_seleccionable and existente_fijo:
        nueva_cantidad = existente_fijo.cantidad + cantidad
        is_valid, error_msg = validate_component_quantity(nueva_cantidad, False)
        if not is_valid:
            flash(
                f"No se puede sumar esa cantidad: {error_msg}",
                "danger",
            )
            return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
    elif total_componentes >= combo_limits["max_components"]:
        flash(
            f"No puedes añadir más de {combo_limits['max_components']} componentes a este combo.",
            "danger",
        )
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))

    if es_seleccionable and combo.canjeable_con_puntos:
        flash(
            "Desactiva el canje con puntos antes de agregar grupos seleccionables al combo.",
            "danger",
        )
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
    if es_seleccionable:
        repetido_grupo = ComboItem.query.filter_by(
            combo_id=producto_id,
            producto_id=componente.id,
            es_seleccionable=True,
            grupo_seleccion=grupo_seleccion,
        ).first()
        if repetido_grupo:
            flash("Ese producto ya existe dentro de ese grupo seleccionable.", "danger")
            return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
        items_grupo = ComboItem.query.filter_by(
            combo_id=producto_id,
            es_seleccionable=True,
            grupo_seleccion=grupo_seleccion,
        ).all()
        if items_grupo:
            max_selecciones = items_grupo[0].max_selecciones or 1
        elif max_selecciones > 1:
            opciones_resultantes = 1
            if max_selecciones > opciones_resultantes:
                flash(
                    "Un grupo nuevo no puede permitir más selecciones que opciones disponibles. "
                    "Añade más opciones al grupo y luego ajusta el límite.",
                    "danger",
                )
                return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))

    if existente_fijo and not es_seleccionable:
        existente_fijo.cantidad += cantidad
    else:
        group = _find_or_create_combo_group(
            producto_id,
            tipo="seleccion" if es_seleccionable else "fijo",
            nombre=grupo_seleccion,
            max_selecciones=max_selecciones,
            orden=total_componentes,
        )
        db.session.add(ComboItem(
            combo_id=producto_id,
            combo_group_id=group.id,
            producto_id=componente.id,
            cantidad=cantidad,
            precio_extra=precio_extra,
            es_predeterminado=es_predeterminado if es_seleccionable else False,
            notas_preparacion=notas_preparacion,
            es_seleccionable=es_seleccionable,
            grupo_seleccion=grupo_seleccion if es_seleccionable else None,
            max_selecciones=max_selecciones if es_seleccionable else 1,
            orden=total_componentes,
        ))
    try:
        db.session.flush()
        _recalcular_precio_combo_si_descuento(combo)
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al añadir componente: {exc}", "danger")
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
    notificar_bot_sync()
    flash("Componente añadido al combo.", "success")
    return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))


@admin_bp.route("/productos/<int:producto_id>/combo/quitar/<int:item_id>", methods=["POST"])
@admin_required
def quitar_componente_combo(producto_id, item_id):
    item = get_or_404(ComboItem, item_id)
    if item.combo_id != producto_id:
        flash("Operación no permitida.", "danger")
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
    combo = db.session.get(Product, producto_id)
    group = item.grupo
    db.session.delete(item)
    try:
        db.session.flush()
        if group and group.items.count() == 0:
            db.session.delete(group)
            db.session.flush()
        _recalcular_precio_combo_si_descuento(combo)
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al quitar componente: {exc}", "danger")
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
    notificar_bot_sync()
    flash("Componente eliminado del combo.", "success")
    return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))


@admin_bp.route("/productos/<int:producto_id>/combo/editar-cantidad/<int:item_id>", methods=["POST"])
@admin_required
def editar_cantidad_combo(producto_id, item_id):
    item = get_or_404(ComboItem, item_id)
    if item.combo_id != producto_id:
        flash("Operación no permitida.", "danger")
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
    nueva_cantidad = request.form.get("cantidad", type=int)
    is_valid, error_msg = validate_component_quantity(
        nueva_cantidad if nueva_cantidad is not None else 0,
        item.es_seleccionable,
    )
    if not is_valid:
        flash(error_msg, "warning")
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
    item.cantidad = nueva_cantidad
    combo = db.session.get(Product, producto_id)
    try:
        db.session.flush()
        _recalcular_precio_combo_si_descuento(combo)
        db.session.commit()
        flash("Cantidad actualizada.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al actualizar cantidad: {exc}", "danger")
    return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))


@admin_bp.route("/productos/<int:producto_id>/combo/precio", methods=["POST"])
@admin_required
def actualizar_precio_combo(producto_id):
    combo = get_or_404(Product, producto_id)
    if not combo.es_combo:
        return redirect(url_for("admin.productos"))
    componentes = ComboItem.query.filter_by(combo_id=producto_id).all()
    pricing_error = _aplicar_precio_combo_desde_form(
        combo,
        request.form,
        componentes,
        _combo_limits_payload(),
    )
    if pricing_error:
        flash(pricing_error, "danger")
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
    try:
        db.session.commit()
        notificar_bot_sync()
        flash("Precio del combo actualizado.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error: {exc}", "danger")
    return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))


@admin_bp.route("/productos/<int:producto_id>/combo/grupo-editar", methods=["POST"])
@admin_required
def editar_grupo_combo(producto_id):
    combo = get_or_404(Product, producto_id)
    if not combo.es_combo:
        return redirect(url_for("admin.productos"))
    grupo = request.form.get("grupo_nombre", "").strip()
    max_sel = request.form.get("max_selecciones", 1, type=int)
    if not grupo:
        flash("Nombre de grupo requerido.", "warning")
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
    items = ComboItem.query.filter_by(
        combo_id=producto_id, grupo_seleccion=grupo, es_seleccionable=True
    ).all()
    if not items:
        flash(f"Grupo '{grupo}' no encontrado.", "warning")
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
    is_valid, error_msg = validate_selections_per_group(max_sel if max_sel is not None else 0)
    if not is_valid:
        flash(error_msg, "danger")
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
    if max_sel > len(items):
        flash(
            f"El grupo '{grupo}' solo tiene {len(items)} opción(es); no puede permitir {max_sel} selecciones.",
            "danger",
        )
        return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))
    for item in items:
        item.max_selecciones = max_sel
        if item.grupo:
            item.grupo.max_selecciones = max_sel
            item.grupo.min_selecciones = min(max_sel, max(1, int(item.grupo.min_selecciones or 1)))
    _recalcular_precio_combo_si_descuento(combo)
    try:
        db.session.commit()
        notificar_bot_sync()
        flash(f"Grupo '{grupo}' actualizado.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error: {exc}", "danger")
    return redirect(url_for("admin.gestionar_combo", producto_id=producto_id))


# ─── CATEGORÍAS ──────────────────────────────

@admin_bp.route("/categorias")
@admin_required
def categorias():
    cats = Categoria.query.order_by(Categoria.orden, Categoria.nombre).all()
    return render_template("admin/categorias.html", categorias=cats)


@admin_bp.route("/categorias/crear", methods=["POST"])
@admin_required
def crear_categoria():
    nombre = request.form.get("nombre", "").strip()
    if not nombre:
        flash("El nombre es obligatorio.", "danger")
        return redirect(url_for("admin.categorias"))
    descripcion = request.form.get("descripcion", "").strip()
    c = Categoria(
        nombre=nombre,
        descripcion=descripcion or None,
        activo=bool(request.form.get("activo", "1")),
        orden=request.form.get("orden", 0, type=int),
    )
    db.session.add(c)
    try:
        db.session.flush()  # obtener c.id para el nombre de imagen y AuditLog
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al crear categoría: {exc}", "danger")
        return redirect(url_for("admin.categorias"))
    AuditLog.registrar(current_user.id, "crear_categoria", "categoria",
                       c.id, detalle=nombre, ip=request.remote_addr)

    img_file = request.files.get("imagen_archivo")
    img_url = _normalizar_imagen_url(request.form.get("imagen_url"))
    if img_file and getattr(img_file, "filename", None):
        ruta = _save_image(img_file, "categorias", f"cat_{c.id}.jpg")
        if ruta:
            c.imagen_url = ruta
    elif img_url:
        c.imagen_url = img_url

    try:
        db.session.commit()
        flash(f"Categoría '{nombre}' creada.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al crear categoría: {exc}", "danger")
    return redirect(url_for("admin.categorias"))


@admin_bp.route("/categorias/<int:cat_id>/editar", methods=["GET", "POST"])
@admin_required
def editar_categoria(cat_id):
    cat = get_or_404(Categoria, cat_id)
    if request.method == "GET":
        return render_template("admin/categoria_editar.html", cat=cat)

    nombre_nuevo = request.form.get("nombre", "").strip()
    if nombre_nuevo:
        cat.nombre = nombre_nuevo
    cat.descripcion = request.form.get("descripcion", "").strip() or None
    cat.activo = bool(request.form.get("activo"))
    cat.orden = request.form.get("orden", cat.orden or 0, type=int)
    img_url = _normalizar_imagen_url(request.form.get("imagen_url"))
    img_file = request.files.get("imagen_archivo")
    if img_file and getattr(img_file, "filename", None):
        ruta = _save_image(img_file, "categorias", f"cat_{cat.id}.jpg")
        if ruta:
            cat.imagen_url = ruta
    elif img_url:
        cat.imagen_url = img_url
    try:
        db.session.commit()
        flash("Categoría actualizada.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al actualizar categoría: {exc}", "danger")
    return redirect(url_for("admin.categorias"))


@admin_bp.route("/categorias/<int:cat_id>/toggle", methods=["POST"])
@admin_required
def toggle_categoria(cat_id):
    cat = get_or_404(Categoria, cat_id)
    cat.activo = not cat.activo
    try:
        db.session.commit()
        notificar_bot_sync()
        flash(f"Categoría '{cat.nombre}' {'activada' if cat.activo else 'desactivada'}.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al cambiar categoría: {exc}", "danger")
    return redirect(url_for("admin.categorias"))


@admin_bp.route("/categorias/<int:cat_id>/eliminar", methods=["POST"])
@admin_required
def eliminar_categoria(cat_id):
    cat = get_or_404(Categoria, cat_id)
    if Product.query.filter_by(categoria_id=cat_id, activo=True).count() > 0:
        flash("No se puede eliminar: tiene productos activos asignados.", "warning")
        return redirect(url_for("admin.categorias"))
    nombre = cat.nombre
    AuditLog.registrar(current_user.id, "eliminar_categoria", "categoria",
                       cat_id, detalle=nombre, ip=request.remote_addr)
    Product.query.filter_by(categoria_id=cat_id).update({"categoria_id": None})
    db.session.delete(cat)
    try:
        db.session.commit()
        flash(f"Categoría '{nombre}' eliminada.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al eliminar categoría: {exc}", "danger")
    return redirect(url_for("admin.categorias"))


# ─── CUPONES ─────────────────────────────────

@admin_bp.route("/cupones")
@marketing_or_admin_required
def cupones():
    return render_template("admin/cupones.html",
                           cupones=Coupon.query.order_by(Coupon.fecha_fin.desc()).all())


@admin_bp.route("/cupones/crear", methods=["POST"])
@marketing_or_admin_required
def crear_cupon():
    codigo = request.form.get("codigo", "").strip().upper()
    tipo = request.form.get("tipo", "")
    if not codigo:
        flash("El código del cupón no puede estar vacío.", "danger")
        return redirect(url_for("admin.cupones"))
    if tipo not in ("porcentaje", "monto_fijo", "envio_gratis"):
        flash("Tipo de cupón inválido.", "danger")
        return redirect(url_for("admin.cupones"))
    fi = request.form.get("fecha_inicio", "").strip() or None
    ff = request.form.get("fecha_fin", "").strip() or None
    try:
        fecha_inicio = _parse_date_strict(fi) if fi else None
        fecha_fin = _parse_date_strict(ff) if ff else None
        valor = float(request.form.get("valor", 0) or 0)
        minimo_pedido = float(request.form.get("minimo_pedido", 0) or 0)
    except (ValueError, TypeError) as e:
        flash(str(e) or "Datos inválidos en el formulario.", "danger")
        return redirect(url_for("admin.cupones"))

    usos_max_raw = request.form.get("usos_maximos", type=int)
    usos_maximos = usos_max_raw if usos_max_raw and usos_max_raw > 0 else None
    cupon = Coupon(
        codigo=codigo,
        descripcion=request.form.get("descripcion", "").strip(),
        tipo=tipo,
        valor=valor,
        minimo_pedido=minimo_pedido,
        usos_maximos=usos_maximos,
        fecha_inicio=fecha_inicio,
        fecha_fin=fecha_fin,
    )
    db.session.add(cupon)
    try:
        db.session.commit()
        flash(f"Cupón '{codigo}' creado.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al crear cupón: {exc}", "danger")
    return redirect(url_for("admin.cupones"))


@admin_bp.route("/cupones/<int:cupon_id>/toggle", methods=["POST"])
@marketing_or_admin_required
def toggle_cupon(cupon_id):
    cupon = get_or_404(Coupon, cupon_id)
    cupon.activo = not cupon.activo
    try:
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        flash(f"Error: {exc}", "danger")
    return redirect(url_for("admin.cupones"))


@admin_bp.route("/cupones/<int:cupon_id>/editar", methods=["GET", "POST"])
@marketing_or_admin_required
def editar_cupon(cupon_id):
    cupon = get_or_404(Coupon, cupon_id)
    if request.method == "GET":
        return render_template("admin/cupon_editar.html", cupon=cupon)

    fi = request.form.get("fecha_inicio")
    ff = request.form.get("fecha_fin")
    cupon.descripcion = request.form.get("descripcion", "").strip()
    nuevo_tipo = request.form.get("tipo", cupon.tipo)
    if nuevo_tipo in ("porcentaje", "monto_fijo", "envio_gratis"):
        cupon.tipo = nuevo_tipo
    try:
        cupon.valor = float(request.form.get("valor", 0) or 0)
        cupon.minimo_pedido = float(request.form.get("minimo_pedido", 0) or 0)
    except (ValueError, TypeError):
        flash("Valor o mínimo de pedido inválidos.", "danger")
        return redirect(url_for("admin.cupones"))
    usos_max = request.form.get("usos_maximos", "").strip()
    try:
        cupon.usos_maximos = int(usos_max) if usos_max else None
        if cupon.usos_maximos is not None and cupon.usos_maximos <= 0:
            cupon.usos_maximos = None
    except (ValueError, TypeError):
        cupon.usos_maximos = None
    try:
        cupon.fecha_inicio = _parse_date_strict(fi) if fi else None
        cupon.fecha_fin = _parse_date_strict(ff) if ff else None
    except ValueError as e:
        flash(str(e), "danger")
        return redirect(url_for("admin.cupones"))
    try:
        db.session.commit()
        flash(f"Cupón {cupon.codigo} actualizado.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al actualizar cupón: {exc}", "danger")
    return redirect(url_for("admin.cupones"))


@admin_bp.route("/cupones/<int:cupon_id>/eliminar", methods=["POST"])
@marketing_or_admin_required
def eliminar_cupon(cupon_id):
    cupon = get_or_404(Coupon, cupon_id)
    if cupon.usos_actuales and cupon.usos_actuales > 0:
        flash("No se puede eliminar un cupón que ya ha sido usado. Desactívalo en su lugar.", "warning")
        return redirect(url_for("admin.cupones"))
    codigo = cupon.codigo
    db.session.delete(cupon)
    try:
        db.session.commit()
        flash(f"Cupón {codigo} eliminado.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al eliminar cupón: {exc}", "danger")
    return redirect(url_for("admin.cupones"))


# ─── RESEÑAS ─────────────────────────────────

@admin_bp.route("/resenas")
@marketing_or_admin_required
def resenas():
    pendientes = Review.query.filter_by(aprobada=False).order_by(Review.creado_en.desc()).all()
    aprobadas = Review.query.filter_by(aprobada=True).order_by(Review.creado_en.desc()).limit(50).all()
    return render_template("admin/resenas.html", pendientes=pendientes, aprobadas=aprobadas)


@admin_bp.route("/resenas/<int:review_id>/aprobar", methods=["POST"])
@marketing_or_admin_required
def aprobar_resena(review_id):
    r = get_or_404(Review, review_id)
    r.aprobada = True
    AuditLog.registrar(current_user.id, "aprobar_resena", "review",
                       r.id, ip=request.remote_addr)
    try:
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        flash(f"Error: {exc}", "danger")
    return redirect(url_for("admin.resenas"))


@admin_bp.route("/resenas/<int:review_id>/eliminar", methods=["POST"])
@marketing_or_admin_required
def eliminar_resena(review_id):
    r = get_or_404(Review, review_id)
    AuditLog.registrar(current_user.id, "eliminar_resena", "review",
                       r.id, ip=request.remote_addr)
    db.session.delete(r)
    try:
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        flash(f"Error: {exc}", "danger")
    return redirect(url_for("admin.resenas"))


# ─── USUARIOS Y ROLES ────────────────────────

@admin_bp.route("/usuarios")
@admin_required
def usuarios():
    q = (request.args.get("q") or "").strip()
    rol = (request.args.get("rol") or "").strip()
    estado = (request.args.get("estado") or "").strip()
    query = User.query
    if q:
        query = query.filter(or_(User.nombre.ilike(f"%{q}%"),
                                 User.email.ilike(f"%{q}%"),
                                 User.telefono.ilike(f"%{q}%")))
    if rol:
        query = query.filter(User.rol == rol)
    if estado == "activo":
        query = query.filter(User.activo == True)
    elif estado == "inactivo":
        query = query.filter(User.activo == False)
    users = query.order_by(User.rol, User.nombre).all()
    return render_template("admin/usuarios.html", users=users, q=q, rol_f=rol,
                           estado_f=estado, roles_validos=_roles_editables_usuario())


@admin_bp.route("/usuarios/crear", methods=["POST"])
@admin_required
def crear_usuario():
    email = request.form.get("email", "").strip().lower()
    if not email:
        flash("El email es obligatorio.", "danger")
        return redirect(url_for("admin.usuarios"))
    if User.query.filter_by(email=email).first():
        flash("Email ya registrado.", "warning")
        return redirect(url_for("admin.usuarios"))
    nombre = request.form.get("nombre", "").strip()
    password = request.form.get("password", "").strip()
    rol = request.form.get("rol", "staff")
    telefono_form = normalizar_telefono_cliente(request.form.get("telefono", "")) or None
    if telefono_form:
        if User.query.filter_by(telefono_normalizado=telefono_form).first():
            flash("Ese teléfono ya identifica a otra persona.", "warning")
            return redirect(url_for("admin.usuarios"))

    if not nombre:
        flash("El nombre es obligatorio.", "danger")
        return redirect(url_for("admin.usuarios"))
    if len(password) < 6:
        flash("La contraseña debe tener al menos 6 caracteres.", "danger")
        return redirect(url_for("admin.usuarios"))
    roles_validos = _roles_editables_usuario()
    if rol not in roles_validos:
        flash("Rol no válido o sin permisos suficientes para asignarlo.", "danger")
        return redirect(url_for("admin.usuarios"))

    try:
        salario_base = float(request.form.get("salario_base", 0) or 0)
        tarifa_entrega = float(request.form.get("tarifa_entrega", 0) or 0)
    except (ValueError, TypeError):
        salario_base = 0.0
        tarifa_entrega = 0.0

    u = User(
        nombre=nombre,
        email=email,
        rol=rol,
        telefono=telefono_form,
        puesto_trabajo=request.form.get("puesto_trabajo", "").strip() or None,
        salario_base=salario_base,
        tarifa_entrega=tarifa_entrega,
    )
    u.set_password(password)
    db.session.add(u)
    try:
        db.session.flush()  # obtener u.id antes de AuditLog
        AuditLog.registrar(current_user.id, "crear_usuario", "user",
                           u.id, detalle=f"{email} [{u.rol}]", ip=request.remote_addr)
        db.session.commit()
        flash(f"Usuario {u.nombre} creado.", "success")
    except IntegrityError:
        db.session.rollback()
        flash("No se pudo crear: el email o el teléfono ya están en uso.", "warning")
    except Exception:
        db.session.rollback()
        current_app.logger.exception("Error al crear usuario")
        flash("No se pudo crear el usuario. Revisa los datos e inténtalo de nuevo.", "danger")
    return redirect(url_for("admin.usuarios"))


@admin_bp.route("/usuarios/<int:user_id>/editar", methods=["GET", "POST"])
@admin_required
def editar_usuario(user_id):
    u = get_or_404(User, user_id)
    roles_validos = _roles_editables_usuario()
    if request.method == "GET":
        return render_template("admin/usuario_editar.html", usuario=u, roles_validos=roles_validos)

    u.nombre = request.form.get("nombre", u.nombre).strip()
    nuevo_rol = request.form.get("rol")
    if nuevo_rol in roles_validos:
        if current_user.rol != "super_admin" and u.rol in ("admin", "super_admin"):
            flash("Solo un super admin puede cambiar el rol de otro administrador.", "danger")
            return redirect(url_for("admin.usuarios"))
        if nuevo_rol in ("admin", "super_admin") and current_user.rol != "super_admin":
            flash("Solo un super admin puede asignar el rol de administrador.", "danger")
            return redirect(url_for("admin.usuarios"))
        u.rol = nuevo_rol
    u.puesto_trabajo = request.form.get("puesto_trabajo", u.puesto_trabajo or "").strip() or None
    telefono_form = normalizar_telefono_cliente(
        request.form.get("telefono", u.telefono or "")
    ) or None
    if telefono_form:
        duplicado = (
            User.query
            .filter(User.telefono_normalizado == telefono_form, User.id != u.id)
            .first()
        )
        if duplicado:
            flash("Ese teléfono ya identifica a otra persona.", "warning")
            return redirect(url_for("admin.editar_usuario", user_id=u.id))
    u.telefono = telefono_form
    try:
        u.salario_base = float(request.form.get("salario_base", u.salario_base) or 0)
        u.tarifa_entrega = float(request.form.get("tarifa_entrega", u.tarifa_entrega) or 0)
    except (ValueError, TypeError):
        pass  # conservar valores anteriores si el input es inválido
    nueva_pw = request.form.get("nueva_password", request.form.get("password", "")).strip()
    if nueva_pw:
        if len(nueva_pw) < 6:
            flash("La contraseña debe tener al menos 6 caracteres.", "danger")
            return redirect(url_for("admin.usuarios"))
        u.set_password(nueva_pw)
    AuditLog.registrar(current_user.id, "editar_usuario", "user",
                       u.id, ip=request.remote_addr)
    try:
        db.session.commit()
        flash(f"Usuario {u.nombre} actualizado.", "success")
    except IntegrityError:
        db.session.rollback()
        flash("No se pudo actualizar: el email o el teléfono ya están en uso.", "warning")
    except Exception:
        db.session.rollback()
        current_app.logger.exception("Error al actualizar usuario")
        flash("No se pudo actualizar el usuario. Revisa los datos.", "danger")
    return redirect(url_for("admin.usuarios"))


@admin_bp.route("/usuarios/<int:user_id>/toggle", methods=["POST"])
@admin_required
def toggle_usuario(user_id):
    u = get_or_404(User, user_id)
    if u.id == current_user.id:
        flash("No puedes desactivarte a ti mismo.", "warning")
        return redirect(url_for("admin.usuarios"))
    if u.rol in ("admin", "super_admin") and current_user.rol != "super_admin":
        flash("Solo un super admin puede desactivar a otros administradores.", "danger")
        return redirect(url_for("admin.usuarios"))
    u.activo = not u.activo
    try:
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        flash(f"Error: {exc}", "danger")
    return redirect(url_for("admin.usuarios"))


# ─── WHATSAPP QR ─────────────────────────────

@admin_bp.route("/whatsapp-qr")
@admin_required
def whatsapp_qr():
    if current_user.rol != "super_admin":
        abort(403)
    return redirect(url_for("superadmin.chatbot"))


@admin_bp.route("/notificaciones")
@admin_required
def notificaciones():
    estado = (request.args.get("estado") or "pending").strip().lower()
    canal = (request.args.get("canal") or "").strip().lower()
    buscar = (request.args.get("q") or "").strip()[:100]
    estados_validos = {"pending", "processing", "sent", "failed", "all"}

    query = NotificationOutbox.query.order_by(NotificationOutbox.creado_en.desc())
    if estado in estados_validos and estado != "all":
        query = query.filter(NotificationOutbox.estado == estado)
    if canal:
        query = query.filter(NotificationOutbox.canal == canal)
    if buscar:
        patron = f"%{buscar}%"
        query = query.filter(or_(
            NotificationOutbox.destinatario.ilike(patron),
            NotificationOutbox.evento.ilike(patron),
            NotificationOutbox.ultimo_error.ilike(patron),
        ))

    items = query.limit(200).all()
    conteos = {
        row.estado: row.total
        for row in db.session.query(
            NotificationOutbox.estado,
            db.func.count(NotificationOutbox.id).label("total"),
        ).group_by(NotificationOutbox.estado).all()
    }
    canales = [
        r[0] for r in db.session.query(NotificationOutbox.canal)
        .distinct()
        .order_by(NotificationOutbox.canal.asc())
        .all()
    ]
    ahora = utcnow()
    hace_24h = ahora - timedelta(hours=24)
    pendientes_vencidas = NotificationOutbox.query.filter(
        NotificationOutbox.estado == "pending",
        or_(
            NotificationOutbox.siguiente_intento_en.is_(None),
            NotificationOutbox.siguiente_intento_en <= ahora,
        ),
    ).count()
    agotadas = NotificationOutbox.query.filter(
        NotificationOutbox.estado == "failed",
        NotificationOutbox.intentos >= NotificationOutbox.max_intentos,
    ).count()
    enviadas_24h = NotificationOutbox.query.filter(
        NotificationOutbox.estado == "sent",
        NotificationOutbox.enviado_en >= hace_24h,
    ).count()
    fallidas_24h = NotificationOutbox.query.filter(
        NotificationOutbox.estado == "failed",
        NotificationOutbox.creado_en >= hace_24h,
    ).count()
    return render_template(
        "admin/notificaciones.html",
        notificaciones=items,
        estado=estado if estado in estados_validos else "all",
        canal=canal,
        conteos=conteos,
        canales=canales,
        buscar=buscar,
        pendientes_vencidas=pendientes_vencidas,
        agotadas=agotadas,
        enviadas_24h=enviadas_24h,
        fallidas_24h=fallidas_24h,
        ahora=ahora,
    )


@admin_bp.route("/notificaciones/procesar", methods=["POST"])
@admin_required
def procesar_notificaciones():
    limit = request.form.get("limit", type=int) or 25
    resultado = procesar_notificaciones_pendientes(limit=min(max(limit, 1), 200))
    flash(
        "Outbox procesado: "
        f"{resultado.get('procesadas', 0)} procesadas, "
        f"{resultado.get('enviadas', 0)} enviadas, "
        f"{resultado.get('fallidas', 0)} fallidas.",
        "info",
    )
    return redirect(url_for("admin.notificaciones", estado=request.form.get("estado") or "pending"))


@admin_bp.route("/notificaciones/<int:notificacion_id>/reintentar", methods=["POST"])
@admin_required
def reintentar_notificacion(notificacion_id):
    notif = get_or_404(NotificationOutbox, notificacion_id)
    if notif.estado == "sent":
        flash("La notificación ya fue enviada.", "info")
        return redirect(url_for("admin.notificaciones", estado=request.form.get("estado") or "failed"))
    if (
        notif.estado == "processing"
        and notif.siguiente_intento_en
        and notif.siguiente_intento_en > utcnow()
    ):
        flash("La notificación está siendo procesada. Espera a que termine el intento actual.", "warning")
        return redirect(url_for("admin.notificaciones", estado="processing"))
    notif.estado = "pending"
    notif.intentos = 0
    notif.siguiente_intento_en = utcnow()
    notif.ultimo_error = None
    try:
        db.session.commit()
        flash("Notificación reencolada para reintento.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"No se pudo reencolar: {exc}", "danger")
    return redirect(url_for("admin.notificaciones", estado=request.form.get("estado") or "pending"))


# ─── HELPERS ─────────────────────────────────

def _count_alertas_stock():
    dias = current_app.config["ALERTA_CADUCIDAD_DIAS"]
    limite = date.today() + timedelta(days=dias)
    return Stock.query.filter(
        Stock.fecha_caducidad != None,
        Stock.fecha_caducidad <= limite,
        Stock.cantidad > 0
    ).count()


# ─── AFILIADOS ───────────────────────────────

@admin_bp.route("/afiliados")
@marketing_or_admin_required
def afiliados():
    codigos = AffiliateCode.query.order_by(AffiliateCode.creado_en.desc()).all()
    staff_users = User.query.filter(
        User.rol.in_(["staff", "repartidor", "cocina", "preparacion"]),
        User.activo == True
    ).order_by(User.nombre).all()
    return render_template("admin/afiliados.html", codigos=codigos, staff_users=staff_users)


@admin_bp.route("/afiliados/crear", methods=["POST"])
@marketing_or_admin_required
def crear_afiliado():
    fi = request.form.get("fecha_inicio")
    ff = request.form.get("fecha_fin")
    codigo = request.form.get("codigo", "").strip().upper()
    if not codigo:
        flash("El código no puede estar vacío.", "danger")
        return redirect(url_for("admin.afiliados"))
    if AffiliateCode.query.filter_by(codigo=codigo).first():
        flash("Ese código ya existe.", "warning")
        return redirect(url_for("admin.afiliados"))
    try:
        desc_valor = float(request.form.get("descuento_valor", 0) or 0)
        com_valor  = float(request.form.get("comision_valor", 0) or 0)
        fi_date    = _parse_date_strict(fi) if fi else None
        ff_date    = _parse_date_strict(ff) if ff else None
    except (ValueError, TypeError) as e:
        flash(str(e) or "Valores numéricos o de fecha inválidos.", "danger")
        return redirect(url_for("admin.afiliados"))

    af = AffiliateCode(
        codigo=codigo,
        descripcion=request.form.get("descripcion", "").strip(),
        tipo=request.form.get("tipo", "externo"),
        user_id=request.form.get("user_id", type=int) or None,
        descuento_tipo=request.form.get("descuento_tipo") or None,
        descuento_valor=desc_valor,
        comision_tipo=request.form.get("comision_tipo") or None,
        comision_valor=com_valor,
        usos_maximos=request.form.get("usos_maximos", type=int) or None,
        fecha_inicio=fi_date,
        fecha_fin=ff_date,
        creado_por=current_user.id,
    )
    db.session.add(af)
    try:
        db.session.flush()  # obtener af.id antes del AuditLog
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al crear afiliado: {exc}", "danger")
        return redirect(url_for("admin.afiliados"))
    AuditLog.registrar(current_user.id, "crear_afiliado", "affiliate_code",
                       af.id, detalle=codigo, ip=request.remote_addr)
    try:
        db.session.commit()
        flash(f"Código '{codigo}' creado.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al crear afiliado: {exc}", "danger")
    return redirect(url_for("admin.afiliados"))


@admin_bp.route("/afiliados/<int:codigo_id>/toggle", methods=["POST"])
@marketing_or_admin_required
def toggle_afiliado(codigo_id):
    af = get_or_404(AffiliateCode, codigo_id)
    af.activo = not af.activo
    try:
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        flash(f"Error: {exc}", "danger")
    return redirect(url_for("admin.afiliados"))


@admin_bp.route("/afiliados/<int:codigo_id>/editar", methods=["POST"])
@marketing_or_admin_required
def editar_afiliado(codigo_id):
    af = get_or_404(AffiliateCode, codigo_id)
    af.descripcion = request.form.get("descripcion", "").strip() or None
    af.tipo = request.form.get("tipo", "externo")
    user_id = request.form.get("user_id", type=int)
    af.user_id = user_id if user_id else None
    af.descuento_tipo = request.form.get("descuento_tipo") or None
    af.descuento_valor = request.form.get("descuento_valor", type=float) or 0
    af.comision_tipo = request.form.get("comision_tipo") or None
    af.comision_valor = request.form.get("comision_valor", type=float) or 0
    af.usos_maximos = request.form.get("usos_maximos", type=int) or None
    fi = request.form.get("fecha_inicio")
    ff = request.form.get("fecha_fin")
    from datetime import date as _date
    af.fecha_inicio = _date.fromisoformat(fi) if fi else None
    af.fecha_fin = _date.fromisoformat(ff) if ff else None
    AuditLog.registrar(current_user.id, "editar_afiliado", "affiliate_code",
                       af.id, detalle=af.codigo, ip=request.remote_addr)
    try:
        db.session.commit()
        flash(f"Afiliado '{af.codigo}' actualizado.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al editar: {exc}", "danger")
    return redirect(url_for("admin.afiliados"))


@admin_bp.route("/afiliados/<int:codigo_id>/eliminar", methods=["POST"])
@marketing_or_admin_required
def eliminar_afiliado(codigo_id):
    af = get_or_404(AffiliateCode, codigo_id)
    if af.usos_actuales and af.usos_actuales > 0:
        flash("No se puede eliminar un código con usos. Desactívalo en su lugar.", "warning")
        return redirect(url_for("admin.afiliados"))
    codigo = af.codigo
    AuditLog.registrar(current_user.id, "eliminar_afiliado", "affiliate_code",
                       af.id, detalle=codigo, ip=request.remote_addr)
    db.session.delete(af)
    try:
        db.session.commit()
        flash(f"Código '{codigo}' eliminado.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al eliminar: {exc}", "danger")
    return redirect(url_for("admin.afiliados"))


@admin_bp.route("/afiliados/<int:codigo_id>/usos")
@marketing_or_admin_required
def usos_afiliado(codigo_id):
    af = get_or_404(AffiliateCode, codigo_id)
    usos = AffiliateUse.query.filter_by(codigo_id=codigo_id)\
                             .order_by(AffiliateUse.creado_en.desc()).all()
    total_comisiones = sum(float(u.comision_generada or 0) for u in usos)
    pendiente = sum(float(u.comision_generada or 0) for u in usos if not u.comision_pagada)
    return render_template("admin/afiliado_usos.html",
                           codigo=af, usos=usos,
                           total_comisiones=total_comisiones, pendiente=pendiente)


@admin_bp.route("/afiliados/<int:codigo_id>/pagar-pendientes", methods=["POST"])
@marketing_or_admin_required
def pagar_comisiones_afiliado(codigo_id):
    af = get_or_404(AffiliateCode, codigo_id)
    pendientes = AffiliateUse.query.filter_by(codigo_id=codigo_id, comision_pagada=False).all()
    if not pendientes:
        flash("No hay comisiones pendientes.", "info")
        return redirect(url_for("admin.usos_afiliado", codigo_id=codigo_id))
    total = 0.0
    for u in pendientes:
        pago = u.staff_payment
        if pago and not pago.pagado:
            pago.marcar_pagado()
            registrar_egreso(
                float(pago.monto),
                f"Pago staff: {pago.empleado.nombre} — {pago.descripcion_completa}",
                categoria="pago_staff",
                staff_payment_id=pago.id,
                registrado_por=current_user.id,
            )
            total += float(pago.monto)
        elif not pago:
            monto = float(u.comision_generada or 0)
            if monto > 0:
                registrar_egreso(
                    monto,
                    f"Comisión afiliado uso #{u.id}",
                    categoria="general",
                    registrado_por=current_user.id,
                )
                total += monto
        u.comision_pagada = True
    AuditLog.registrar(current_user.id, "pagar_comisiones_afiliado", "affiliate_code",
                       codigo_id, f"Pagadas {len(pendientes)} comisiones (€{total:.2f})",
                       ip=request.remote_addr)
    try:
        db.session.commit()
        flash(f"Marcadas {len(pendientes)} comisiones como pagadas (€{total:.2f} total).", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al registrar pagos: {exc}", "danger")
    return redirect(url_for("admin.usos_afiliado", codigo_id=codigo_id))


@admin_bp.route("/afiliados/uso/<int:uso_id>/pagar", methods=["POST"])
@marketing_or_admin_required
def pagar_comision_individual(uso_id):
    uso = get_or_404(AffiliateUse, uso_id)
    if uso.comision_pagada:
        flash("Esta comisión ya estaba pagada.", "info")
        return redirect(url_for("admin.usos_afiliado", codigo_id=uso.codigo_id))
    uso.comision_pagada = True
    pago = uso.staff_payment
    monto = float(pago.monto if pago else (uso.comision_generada or 0))
    if pago and not pago.pagado:
        pago.marcar_pagado()
        registrar_egreso(
            monto,
            f"Pago staff: {pago.empleado.nombre} — {pago.descripcion_completa}",
            categoria="pago_staff",
            staff_payment_id=pago.id,
            registrado_por=current_user.id,
        )
    elif not pago and monto > 0:
        registrar_egreso(
            monto,
            f"Comisión afiliado uso #{uso_id}",
            categoria="general",
            registrado_por=current_user.id,
        )
    AuditLog.registrar(current_user.id, "pagar_comision_individual", "affiliate_use",
                       uso_id, detalle=f"€{monto:.2f}", ip=request.remote_addr)
    try:
        db.session.commit()
        flash("Comisión marcada como pagada.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al registrar pago: {exc}", "danger")
    return redirect(url_for("admin.usos_afiliado", codigo_id=uso.codigo_id))


# ─── MENÚ CONFIG ─────────────────────────────

_MENU_CONFIG_TIPOS = {"banner", "producto_destacado", "texto_promo", "seccion"}
_MENU_CONFIG_PAGINAS = {"home", "menu", "checkout"}


def _validar_menu_config_form(form):
    tipo = (form.get("tipo") or "banner").strip()
    pagina = (form.get("pagina") or "home").strip()
    categoria_id = form.get("categoria_id", type=int) or None
    producto_id = form.get("producto_id", type=int) or None
    if tipo not in _MENU_CONFIG_TIPOS:
        return None, "Tipo de elemento inválido."
    if pagina not in _MENU_CONFIG_PAGINAS:
        return None, "Página inválida."
    if tipo == "seccion" and not categoria_id:
        return None, "Selecciona una categoría para la sección."
    if tipo == "producto_destacado" and not producto_id:
        return None, "Selecciona un producto para el destacado."
    if categoria_id and not Categoria.query.filter_by(id=categoria_id, activo=True).first():
        return None, "La categoría seleccionada no existe o está inactiva."
    if producto_id and not Product.query.filter_by(id=producto_id, activo=True).first():
        return None, "El producto seleccionado no existe o está inactivo."
    if tipo != "seccion":
        categoria_id = None
    if tipo != "producto_destacado":
        producto_id = None
    return {
        "tipo": tipo,
        "pagina": pagina,
        "categoria_id": categoria_id,
        "producto_id": producto_id,
    }, None


def _validar_contenido_menu_config(tipo, titulo, contenido, imagen_url):
    if len(titulo) > 160 or len(contenido) > 1000:
        return "El título o contenido supera la longitud permitida."
    if tipo == "banner" and not imagen_url:
        return "El banner necesita una imagen subida o una URL de imagen."
    if tipo == "texto_promo" and not (titulo or contenido):
        return "El texto promocional necesita un título o una descripción."
    return None


@admin_bp.route("/menu-config")
@marketing_or_admin_required
def menu_config():
    pagina = request.args.get("pagina", "")
    query = MenuConfig.query.order_by(MenuConfig.pagina, MenuConfig.orden)
    if pagina:
        query = query.filter_by(pagina=pagina)
    items = query.all()
    categorias = Categoria.query.filter_by(activo=True).all()
    productos = Product.query.filter_by(activo=True).order_by(Product.nombre).all()
    return render_template("admin/menu_config.html",
                           items=items, categorias=categorias,
                           productos=productos, pagina=pagina)


@admin_bp.route("/menu-config/crear", methods=["POST"])
@marketing_or_admin_required
def crear_menu_config():
    campos_tipo, error = _validar_menu_config_form(request.form)
    if error:
        flash(error, "danger")
        return redirect(url_for("admin.menu_config"))
    imagen_url = _normalizar_imagen_url(request.form.get("imagen_url"))
    img_file = request.files.get("imagen_archivo")
    if img_file and getattr(img_file, "filename", None):
        ruta = _save_image(img_file, "banners", f"banner_{uuid.uuid4().hex[:10]}.jpg")
        if ruta:
            imagen_url = ruta
    titulo = request.form.get("titulo", "").strip()
    contenido = request.form.get("contenido", "").strip()
    enlace_url = request.form.get("enlace_url", "").strip() or None
    error = _validar_contenido_menu_config(
        campos_tipo["tipo"], titulo, contenido, imagen_url
    )
    if error:
        if img_file and imagen_url:
            _borrar_imagen(imagen_url)
        flash(error, "danger")
        return redirect(url_for("admin.menu_config"))
    if enlace_url and not enlace_url.startswith(("/", "http://", "https://", "#")):
        if img_file and imagen_url:
            _borrar_imagen(imagen_url)
        flash("El enlace debe ser una ruta interna, ancla o URL http(s).", "danger")
        return redirect(url_for("admin.menu_config"))
    item = MenuConfig(
        tipo=campos_tipo["tipo"],
        titulo=titulo,
        contenido=contenido,
        imagen_url=imagen_url,
        enlace_url=enlace_url,
        orden=max(0, min(9999, request.form.get("orden", 0, type=int))),
        pagina=campos_tipo["pagina"],
        categoria_id=campos_tipo["categoria_id"],
        producto_id=campos_tipo["producto_id"],
        creado_por=current_user.id,
    )
    db.session.add(item)
    try:
        db.session.commit()
        flash("Item de menú creado.", "success")
    except Exception as exc:
        db.session.rollback()
        if img_file and imagen_url:
            _borrar_imagen(imagen_url)
        flash(f"Error al crear item: {exc}", "danger")
    return redirect(url_for("admin.menu_config"))


@admin_bp.route("/menu-config/<int:item_id>/editar", methods=["GET", "POST"])
@marketing_or_admin_required
def editar_menu_config(item_id):
    item = get_or_404(MenuConfig, item_id)
    if request.method == "GET":
        categorias = Categoria.query.filter_by(activo=True).order_by(Categoria.nombre).all()
        productos = Product.query.filter_by(activo=True).order_by(Product.nombre).all()
        return render_template("admin/menu_config_editar.html",
                               item=item, categorias=categorias, productos=productos)

    campos_tipo, error = _validar_menu_config_form(request.form)
    if error:
        flash(error, "danger")
        return redirect(url_for("admin.menu_config"))
    titulo = request.form.get("titulo", item.titulo or "").strip()
    contenido = request.form.get("contenido", item.contenido or "").strip()
    enlace_url = request.form.get("enlace_url", "").strip() or None
    if enlace_url and not enlace_url.startswith(("/", "http://", "https://", "#")):
        flash("El enlace debe ser una ruta interna, ancla o URL http(s).", "danger")
        return redirect(url_for("admin.menu_config"))
    img_url = _normalizar_imagen_url(request.form.get("imagen_url"))
    img_file = request.files.get("imagen_archivo")
    imagen_anterior = item.imagen_url
    imagen_nueva = item.imagen_url
    if img_file and getattr(img_file, "filename", None):
        ruta = _save_image(img_file, "banners", f"banner_{uuid.uuid4().hex[:10]}.jpg")
        if ruta:
            imagen_nueva = ruta
    elif img_url:
        imagen_nueva = img_url
    if campos_tipo["tipo"] != "banner":
        imagen_nueva = None
    error = _validar_contenido_menu_config(
        campos_tipo["tipo"], titulo, contenido, imagen_nueva
    )
    if error:
        if imagen_nueva and imagen_nueva != imagen_anterior:
            _borrar_imagen(imagen_nueva)
        flash(error, "danger")
        return redirect(url_for("admin.menu_config"))
    item.tipo = campos_tipo["tipo"]
    item.titulo = titulo
    item.contenido = contenido
    item.imagen_url = imagen_nueva
    item.enlace_url = enlace_url
    item.orden = max(0, min(9999, request.form.get("orden", item.orden, type=int)))
    item.pagina = campos_tipo["pagina"]
    item.categoria_id = campos_tipo["categoria_id"]
    item.producto_id = campos_tipo["producto_id"]
    try:
        db.session.commit()
        if imagen_anterior and imagen_anterior != imagen_nueva:
            _borrar_imagen(imagen_anterior)
        flash("Banner actualizado.", "success")
    except Exception as exc:
        db.session.rollback()
        if imagen_nueva and imagen_nueva != imagen_anterior:
            _borrar_imagen(imagen_nueva)
        flash(f"Error al actualizar banner: {exc}", "danger")
    return redirect(url_for("admin.menu_config"))


@admin_bp.route("/menu-config/<int:item_id>/toggle", methods=["GET", "POST"])
@marketing_or_admin_required
def toggle_menu_config(item_id):
    if request.method == "GET":
        flash("Esa acción necesita confirmación. Usa el botón del panel.", "info")
        return redirect(url_for("admin.menu_config"))
    item = get_or_404(MenuConfig, item_id)
    item.activo = not item.activo
    try:
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        flash(f"Error: {exc}", "danger")
    return redirect(url_for("admin.menu_config"))


@admin_bp.route("/menu-config/<int:item_id>/eliminar", methods=["POST"])
@marketing_or_admin_required
def eliminar_menu_config(item_id):
    item = get_or_404(MenuConfig, item_id)
    imagen_url = item.imagen_url
    db.session.delete(item)
    try:
        db.session.commit()
        if imagen_url:
            _borrar_imagen(imagen_url)
        flash("Item eliminado.", "warning")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error: {exc}", "danger")
    return redirect(url_for("admin.menu_config"))


# ─── ANALYTICS / P&L ─────────────────────────

@admin_bp.route("/analytics")
@admin_required
def analytics():
    from calendar import monthrange
    hoy = date.today()
    primer_dia = hoy.replace(day=1)
    ultimo_dia = hoy.replace(day=monthrange(hoy.year, hoy.month)[1])

    fecha_ini = request.args.get("fecha_ini", primer_dia.isoformat())
    fecha_fin = request.args.get("fecha_fin", ultimo_dia.isoformat())
    try:
        fi = date.fromisoformat(fecha_ini)
        ff = date.fromisoformat(fecha_fin)
    except (ValueError, TypeError):
        fi, ff = primer_dia, ultimo_dia
        fecha_ini, fecha_fin = fi.isoformat(), ff.isoformat()

    pl = calcular_pl(fi, ff)
    por_categoria = resumen_ventas_por_categoria(fi, ff)
    top_prods = top_productos(limit=10, fecha_ini=fi, fecha_fin=ff)

    # Ventas diarias para gráfico de tendencia (fecha de entrega)
    from sqlalchemy import func as sqlfunc
    ventas_diarias = {}
    resultado_dia = db.session.query(
        sqlfunc.date(Order.entregado_en).label("dia"),
        sqlfunc.count(Order.id).label("pedidos"),
        sqlfunc.sum(Order.total).label("total"),
    ).filter(
        Order.estado == "entregado",
        sqlfunc.date(Order.entregado_en) >= fi,
        sqlfunc.date(Order.entregado_en) <= ff,
    ).group_by("dia").all()
    for row in resultado_dia:
        ventas_diarias[str(row.dia)] = {"pedidos": row.pedidos, "total": float(row.total or 0)}

    # Rellenar días sin ventas
    labels_dias, data_pedidos, data_totales = [], [], []
    d = fi
    while d <= ff:
        ds = d.isoformat()
        labels_dias.append(d.strftime("%d/%m"))
        data_pedidos.append(ventas_diarias.get(ds, {}).get("pedidos", 0))
        data_totales.append(round(ventas_diarias.get(ds, {}).get("total", 0), 2))
        d += timedelta(days=1)

    return render_template("admin/analytics.html",
                           pl=pl, por_categoria=por_categoria,
                           top_prods=top_prods,
                           fecha_ini=fecha_ini, fecha_fin=fecha_fin,
                           labels_dias=labels_dias,
                           data_pedidos=data_pedidos,
                           data_totales=data_totales)


# ─── HISTORIAL CLIENTE ────────────────────────

@admin_bp.route("/clientes/<int:user_id>/historial")
@admin_required
def historial_cliente(user_id):
    cliente = get_or_404(User, user_id)
    pedidos = Order.query.filter_by(cliente_id=user_id)\
                         .order_by(Order.creado_en.desc()).all()
    puntos_log = PointsLog.query.filter_by(cliente_id=user_id)\
                                .order_by(PointsLog.creado_en.desc()).all()
    total_gastado = sum(float(p.total or 0) for p in pedidos if p.estado != "cancelado")
    return render_template("admin/cliente_historial.html",
                           cliente=cliente, pedidos=pedidos,
                           puntos_log=puntos_log, total_gastado=total_gastado)


# ─── HISTORIAL DE PRECIOS ────────────────────

@admin_bp.route("/productos/<int:producto_id>/precios")
@admin_required
def historial_precios(producto_id):
    producto = get_or_404(Product, producto_id)
    historial = PriceHistory.query.filter_by(producto_id=producto_id)\
                                  .order_by(PriceHistory.cambiado_en.desc()).all()
    return render_template("admin/historial_precios.html",
                           producto=producto, historial=historial)


@admin_bp.route("/productos/<int:producto_id>/precio/cambiar", methods=["POST"])
@admin_required
def cambiar_precio(producto_id):
    producto = get_or_404(Product, producto_id)
    nuevo_precio = request.form.get("precio", type=float)
    motivo = request.form.get("motivo", "").strip()[:200]
    if nuevo_precio is None or nuevo_precio <= 0:
        flash("Precio inválido.", "danger")
        return redirect(url_for("admin.productos"))
    hist = PriceHistory(
        producto_id=producto.id,
        precio_anterior=producto.precio,
        precio_nuevo=nuevo_precio,
        cambiado_por=current_user.id,
        motivo=motivo or None,
    )
    db.session.add(hist)
    producto.precio = nuevo_precio
    AuditLog.registrar(current_user.id, "cambiar_precio", "product",
                       producto.id, detalle=f"{hist.precio_anterior}→{nuevo_precio}",
                       ip=request.remote_addr)
    try:
        db.session.commit()
        flash(f"Precio de '{producto.nombre}' actualizado a €{nuevo_precio:.2f}.", "success")
    except Exception as exc:
        db.session.rollback()
        flash(f"Error al actualizar precio: {exc}", "danger")
    return redirect(url_for("admin.productos"))
