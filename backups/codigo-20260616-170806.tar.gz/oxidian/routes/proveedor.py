import logging
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from functools import wraps
from extensions import db, get_or_404
from models import Order, OrderProviderStatus, User, utcnow
from services import lineas_proveedor_pedido, registrar_evento_pedido

proveedor_bp = Blueprint("proveedor", __name__)
logger = logging.getLogger(__name__)

ROLES_PROVEEDOR = {"proveedor", "admin", "super_admin"}
_ESTADOS_ACTIVOS = ("pendiente", "armando")


def proveedor_required(f):
    @wraps(f)
    @login_required
    def decorated(*args, **kwargs):
        if current_user.rol not in ROLES_PROVEEDOR:
            flash("Acceso restringido.", "danger")
            return redirect(url_for("public.index"))
        return f(*args, **kwargs)
    return decorated


def _proveedor_id_efectivo():
    """Devuelve el proveedor_id del usuario actual, o None si es admin (sin filtro)."""
    if current_user.rol in ("admin", "super_admin"):
        return None
    return current_user.id


def _notificar_preparador(pedido, titulo, mensaje):
    if not pedido.preparador_id:
        return
    try:
        from push_service import notify_user
        notify_user(
            pedido.preparador_id,
            titulo,
            mensaje,
            url="/preparador/pedidos",
        )
    except Exception:
        logger.exception("No se pudo notificar al preparador del pedido %s", pedido.id)


@proveedor_bp.route("/pedidos")
@proveedor_required
def pedidos():
    prov_id = _proveedor_id_efectivo()

    if prov_id:
        base = Order.query.join(OrderProviderStatus).filter(
            Order.estado.in_(_ESTADOS_ACTIVOS),
            OrderProviderStatus.proveedor_id == prov_id,
        )
    else:
        base = Order.query.join(OrderProviderStatus).filter(
            Order.estado.in_(_ESTADOS_ACTIVOS),
        ).distinct()

    pendientes = base.filter(Order.estado == "pendiente").order_by(Order.creado_en).all()
    armando    = base.filter(Order.estado == "armando").order_by(Order.creado_en).all()

    return render_template(
        "proveedor/pedidos.html",
        pendientes=pendientes,
        armando=armando,
        prov_id=prov_id,
        lineas_proveedor_pedido=lineas_proveedor_pedido,
        proveedores=(
            User.query.filter_by(rol="proveedor", activo=True).order_by(User.nombre).all()
            if not prov_id else []
        ),
    )


@proveedor_bp.route("/pedidos/<int:pedido_id>/preparado", methods=["POST"])
@proveedor_required
def marcar_preparado(pedido_id):
    pedido = Order.query.filter_by(id=pedido_id).with_for_update().first_or_404()
    if pedido.estado not in _ESTADOS_ACTIVOS:
        flash("Este pedido ya no está activo.", "warning")
        return redirect(url_for("proveedor.pedidos"))
    prov_id = _proveedor_id_efectivo()
    if not prov_id and current_user.rol in ("admin", "super_admin"):
        prov_id = request.form.get("proveedor_id", type=int)

    estados_q = OrderProviderStatus.query.filter_by(pedido_id=pedido.id)
    estados_totales = estados_q.count()
    if not prov_id and estados_totales > 1:
        flash("Selecciona el proveedor concreto que confirmó su preparación.", "warning")
        return redirect(url_for("proveedor.pedidos"))
    if prov_id:
        estados_q = estados_q.filter_by(proveedor_id=prov_id)
    estados = estados_q.with_for_update().all()
    if not estados:
        if _proveedor_id_efectivo():
            flash("Este pedido no contiene tus productos.", "danger")
        else:
            flash("Este pedido no tiene proveedores pendientes registrados.", "warning")
        return redirect(url_for("proveedor.pedidos"))

    if all(estado.preparado for estado in estados):
        flash(f"Pedido {pedido.numero_pedido} ya estaba marcado como preparado.", "info")
        return redirect(url_for("proveedor.pedidos"))

    ahora = utcnow()
    for estado in estados:
        estado.preparado = True
        estado.preparado_en = ahora
        estado.actualizado_por = current_user.id
    db.session.flush()
    todos = OrderProviderStatus.query.filter_by(pedido_id=pedido.id).all()
    pedido.proveedor_preparado = bool(todos) and all(estado.preparado for estado in todos)
    pedido.proveedor_preparado_en = ahora if pedido.proveedor_preparado else None
    registrar_evento_pedido(
        pedido,
        "proveedor_preparado",
        actor_id=current_user.id,
        estado_anterior=pedido.estado,
        estado_nuevo=pedido.estado,
        canal="proveedor",
        metadata={"proveedor_ids": [estado.proveedor_id for estado in estados]},
    )
    try:
        db.session.commit()
        try:
            from push_service import notify_roles
            notify_roles(
                ["cocina", "preparacion"],
                "Proveedor listo",
                f"El proveedor confirmó su parte del pedido #{pedido.numero_pedido}.",
                url="/preparador/pedidos",
            )
        except Exception:
            logger.exception("No se pudo avisar a preparación del pedido %s", pedido.id)
        flash(f"Pedido {pedido.numero_pedido} marcado como preparado.", "success")
    except Exception as exc:
        db.session.rollback()
        logger.exception("Error marcando pedido %s como preparado", pedido_id)
        flash(f"Error al guardar: {exc}", "danger")
        return redirect(url_for("proveedor.pedidos"))
    _notificar_preparador(
        pedido,
        "Proveedor listo",
        f"#{pedido.numero_pedido}: la preparación externa está lista.",
    )
    return redirect(url_for("proveedor.pedidos"))


@proveedor_bp.route("/pedidos/<int:pedido_id>/reabrir", methods=["POST"])
@proveedor_required
def reabrir_preparacion(pedido_id):
    pedido = Order.query.filter_by(id=pedido_id).with_for_update().first_or_404()
    if pedido.estado not in _ESTADOS_ACTIVOS:
        flash("Solo se puede corregir un pedido que siga en preparación.", "warning")
        return redirect(url_for("proveedor.pedidos"))

    prov_id = _proveedor_id_efectivo()
    if not prov_id:
        prov_id = request.form.get("proveedor_id", type=int)

    estados_q = OrderProviderStatus.query.filter_by(pedido_id=pedido.id)
    if prov_id:
        estados_q = estados_q.filter_by(proveedor_id=prov_id)
    estados = estados_q.with_for_update().all()
    if not estados:
        flash("No se encontró la preparación de proveedor que quieres corregir.", "warning")
        return redirect(url_for("proveedor.pedidos"))
    if len(estados) > 1:
        flash("Selecciona el proveedor concreto que debe reabrir su preparación.", "warning")
        return redirect(url_for("proveedor.pedidos"))
    if not estados[0].preparado:
        flash("Esta preparación ya estaba pendiente.", "info")
        return redirect(url_for("proveedor.pedidos"))

    estado = estados[0]
    estado.preparado = False
    estado.preparado_en = None
    estado.actualizado_por = current_user.id
    pedido.proveedor_preparado = False
    pedido.proveedor_preparado_en = None
    registrar_evento_pedido(
        pedido,
        "proveedor_reabierto",
        actor_id=current_user.id,
        estado_anterior=pedido.estado,
        estado_nuevo=pedido.estado,
        canal="proveedor",
        metadata={"proveedor_ids": [estado.proveedor_id]},
    )
    try:
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        logger.exception("Error reabriendo proveedor del pedido %s", pedido_id)
        flash(f"Error al guardar: {exc}", "danger")
        return redirect(url_for("proveedor.pedidos"))

    flash(f"Preparación de {pedido.numero_pedido} reabierta.", "warning")
    _notificar_preparador(
        pedido,
        "Proveedor reabrió preparación",
        f"#{pedido.numero_pedido}: la preparación externa vuelve a estar pendiente.",
    )
    return redirect(url_for("proveedor.pedidos"))
