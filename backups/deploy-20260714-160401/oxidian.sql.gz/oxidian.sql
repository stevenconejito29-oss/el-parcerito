--
-- PostgreSQL database dump
--

\restrict FUNvrdqnjBjoRo42sztOtvcb2RGRcQms4ID4MMlLPKK7fN5QcwKqA6pWFcra1gW

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: oxidian
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO oxidian;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: oxidian
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_features; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.admin_features (
    id integer NOT NULL,
    user_id integer NOT NULL,
    feature character varying(50) NOT NULL,
    activo boolean,
    actualizado_por integer,
    actualizado_en timestamp without time zone
);


ALTER TABLE public.admin_features OWNER TO oxidian;

--
-- Name: admin_features_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.admin_features_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_features_id_seq OWNER TO oxidian;

--
-- Name: admin_features_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.admin_features_id_seq OWNED BY public.admin_features.id;


--
-- Name: affiliate_codes; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.affiliate_codes (
    id integer NOT NULL,
    codigo character varying(30) NOT NULL,
    descripcion character varying(200),
    tipo character varying(20),
    user_id integer,
    descuento_tipo character varying(20),
    descuento_valor numeric(10,2),
    comision_tipo character varying(20),
    comision_valor numeric(10,2),
    activo boolean,
    usos_maximos integer,
    usos_actuales integer,
    fecha_inicio date,
    fecha_fin date,
    creado_en timestamp without time zone,
    creado_por integer
);


ALTER TABLE public.affiliate_codes OWNER TO oxidian;

--
-- Name: affiliate_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.affiliate_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.affiliate_codes_id_seq OWNER TO oxidian;

--
-- Name: affiliate_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.affiliate_codes_id_seq OWNED BY public.affiliate_codes.id;


--
-- Name: affiliate_uses; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.affiliate_uses (
    id integer NOT NULL,
    codigo_id integer NOT NULL,
    pedido_id integer NOT NULL,
    cliente_id integer NOT NULL,
    descuento_aplicado numeric(10,2),
    comision_generada numeric(10,2),
    comision_pagada boolean,
    staff_payment_id integer,
    creado_en timestamp without time zone
);


ALTER TABLE public.affiliate_uses OWNER TO oxidian;

--
-- Name: affiliate_uses_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.affiliate_uses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.affiliate_uses_id_seq OWNER TO oxidian;

--
-- Name: affiliate_uses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.affiliate_uses_id_seq OWNED BY public.affiliate_uses.id;


--
-- Name: ai_assistant_config; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.ai_assistant_config (
    id integer NOT NULL,
    activo boolean,
    modelo character varying(80),
    api_key character varying(255),
    system_prompt text
);


ALTER TABLE public.ai_assistant_config OWNER TO oxidian;

--
-- Name: ai_assistant_config_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.ai_assistant_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ai_assistant_config_id_seq OWNER TO oxidian;

--
-- Name: ai_assistant_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.ai_assistant_config_id_seq OWNED BY public.ai_assistant_config.id;


--
-- Name: ai_conversations; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.ai_conversations (
    id integer NOT NULL,
    telefono character varying(30),
    resumen text,
    creado_en timestamp without time zone
);


ALTER TABLE public.ai_conversations OWNER TO oxidian;

--
-- Name: ai_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.ai_conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ai_conversations_id_seq OWNER TO oxidian;

--
-- Name: ai_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.ai_conversations_id_seq OWNED BY public.ai_conversations.id;


--
-- Name: ai_usage_log; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.ai_usage_log (
    id integer NOT NULL,
    conversation_id integer,
    tokens_in integer,
    tokens_out integer,
    creado_en timestamp without time zone
);


ALTER TABLE public.ai_usage_log OWNER TO oxidian;

--
-- Name: ai_usage_log_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.ai_usage_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ai_usage_log_id_seq OWNER TO oxidian;

--
-- Name: ai_usage_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.ai_usage_log_id_seq OWNED BY public.ai_usage_log.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    user_id integer,
    accion character varying(100) NOT NULL,
    recurso character varying(50),
    recurso_id integer,
    detalle text,
    ip character varying(50),
    creado_en timestamp without time zone
);


ALTER TABLE public.audit_log OWNER TO oxidian;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_log_id_seq OWNER TO oxidian;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: bot_ai_messages; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.bot_ai_messages (
    id integer NOT NULL,
    telefono_hash character varying(64) NOT NULL,
    rol character varying(12) NOT NULL,
    contenido text NOT NULL,
    creado_en timestamp without time zone NOT NULL
);


ALTER TABLE public.bot_ai_messages OWNER TO oxidian;

--
-- Name: bot_ai_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.bot_ai_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bot_ai_messages_id_seq OWNER TO oxidian;

--
-- Name: bot_ai_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.bot_ai_messages_id_seq OWNED BY public.bot_ai_messages.id;


--
-- Name: bot_ai_usage; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.bot_ai_usage (
    id integer NOT NULL,
    telefono_hash character varying(64) NOT NULL,
    tokens_in integer NOT NULL,
    tokens_out integer NOT NULL,
    creado_en timestamp without time zone NOT NULL
);


ALTER TABLE public.bot_ai_usage OWNER TO oxidian;

--
-- Name: bot_ai_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.bot_ai_usage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bot_ai_usage_id_seq OWNER TO oxidian;

--
-- Name: bot_ai_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.bot_ai_usage_id_seq OWNED BY public.bot_ai_usage.id;


--
-- Name: caja; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.caja (
    id integer NOT NULL,
    tipo character varying(20) NOT NULL,
    categoria character varying(30),
    monto numeric(10,2) NOT NULL,
    concepto character varying(200),
    pedido_id integer,
    staff_payment_id integer,
    registrado_por integer,
    fecha timestamp without time zone
);


ALTER TABLE public.caja OWNER TO oxidian;

--
-- Name: caja_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.caja_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.caja_id_seq OWNER TO oxidian;

--
-- Name: caja_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.caja_id_seq OWNED BY public.caja.id;


--
-- Name: campanas_marketing; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.campanas_marketing (
    id integer NOT NULL,
    titulo character varying(200) NOT NULL,
    mensaje text NOT NULL,
    filtro_audiencia character varying(50),
    zona_id integer,
    enviados integer,
    estado character varying(20),
    error_detalle text,
    creado_por integer NOT NULL,
    creado_en timestamp without time zone,
    enviado_en timestamp without time zone
);


ALTER TABLE public.campanas_marketing OWNER TO oxidian;

--
-- Name: campanas_marketing_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.campanas_marketing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.campanas_marketing_id_seq OWNER TO oxidian;

--
-- Name: campanas_marketing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.campanas_marketing_id_seq OWNED BY public.campanas_marketing.id;


--
-- Name: categorias; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.categorias (
    id integer NOT NULL,
    nombre character varying(80) NOT NULL,
    descripcion text,
    imagen_url text,
    activo boolean,
    orden integer
);


ALTER TABLE public.categorias OWNER TO oxidian;

--
-- Name: categorias_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.categorias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categorias_id_seq OWNER TO oxidian;

--
-- Name: categorias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.categorias_id_seq OWNED BY public.categorias.id;


--
-- Name: combo_groups; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.combo_groups (
    id integer NOT NULL,
    combo_id integer NOT NULL,
    nombre character varying(80) NOT NULL,
    tipo character varying(20) NOT NULL,
    min_selecciones integer NOT NULL,
    max_selecciones integer NOT NULL,
    orden integer NOT NULL,
    requerido boolean,
    descripcion text,
    creado_en timestamp without time zone
);


ALTER TABLE public.combo_groups OWNER TO oxidian;

--
-- Name: combo_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.combo_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.combo_groups_id_seq OWNER TO oxidian;

--
-- Name: combo_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.combo_groups_id_seq OWNED BY public.combo_groups.id;


--
-- Name: combo_items; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.combo_items (
    id integer NOT NULL,
    combo_id integer NOT NULL,
    combo_group_id integer,
    producto_id integer NOT NULL,
    cantidad integer NOT NULL,
    orden integer NOT NULL,
    precio_extra numeric(10,2) NOT NULL,
    es_predeterminado boolean,
    activo boolean DEFAULT true NOT NULL,
    notas_preparacion text,
    es_seleccionable boolean,
    grupo_seleccion character varying(50),
    max_selecciones integer,
    variant_id integer,
    CONSTRAINT ck_combo_items_cantidad_positive CHECK ((cantidad > 0))
);


ALTER TABLE public.combo_items OWNER TO oxidian;

--
-- Name: combo_items_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.combo_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.combo_items_id_seq OWNER TO oxidian;

--
-- Name: combo_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.combo_items_id_seq OWNED BY public.combo_items.id;


--
-- Name: coupons; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.coupons (
    id integer NOT NULL,
    codigo character varying(30) NOT NULL,
    descripcion character varying(200),
    tipo character varying(20) NOT NULL,
    valor numeric(10,2) NOT NULL,
    minimo_pedido numeric(10,2),
    usos_maximos integer,
    usos_actuales integer,
    activo boolean,
    fecha_inicio date,
    fecha_fin date
);


ALTER TABLE public.coupons OWNER TO oxidian;

--
-- Name: coupons_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.coupons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.coupons_id_seq OWNER TO oxidian;

--
-- Name: coupons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.coupons_id_seq OWNED BY public.coupons.id;


--
-- Name: extra_catalog_items; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.extra_catalog_items (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion character varying(240),
    precio numeric(10,2) NOT NULL,
    max_cantidad integer NOT NULL,
    activo boolean NOT NULL,
    creado_en timestamp without time zone NOT NULL,
    actualizado_en timestamp without time zone NOT NULL,
    CONSTRAINT ck_extra_catalog_max_qty CHECK ((max_cantidad >= 1)),
    CONSTRAINT ck_extra_catalog_price CHECK ((precio >= (0)::numeric))
);


ALTER TABLE public.extra_catalog_items OWNER TO oxidian;

--
-- Name: extra_catalog_items_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.extra_catalog_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.extra_catalog_items_id_seq OWNER TO oxidian;

--
-- Name: extra_catalog_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.extra_catalog_items_id_seq OWNED BY public.extra_catalog_items.id;


--
-- Name: hub_commissions; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.hub_commissions (
    id integer NOT NULL,
    pedido_id integer,
    monto numeric(10,2),
    pct numeric(5,2),
    creado_en timestamp without time zone
);


ALTER TABLE public.hub_commissions OWNER TO oxidian;

--
-- Name: hub_commissions_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.hub_commissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hub_commissions_id_seq OWNER TO oxidian;

--
-- Name: hub_commissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.hub_commissions_id_seq OWNED BY public.hub_commissions.id;


--
-- Name: idempotency_keys; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.idempotency_keys (
    id integer NOT NULL,
    scope character varying(40) NOT NULL,
    key character varying(120) NOT NULL,
    request_hash character varying(64) NOT NULL,
    response_status integer NOT NULL,
    response_body text,
    order_id integer,
    user_id integer,
    creado_en timestamp without time zone NOT NULL,
    expira_en timestamp without time zone NOT NULL
);


ALTER TABLE public.idempotency_keys OWNER TO oxidian;

--
-- Name: idempotency_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.idempotency_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.idempotency_keys_id_seq OWNER TO oxidian;

--
-- Name: idempotency_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.idempotency_keys_id_seq OWNED BY public.idempotency_keys.id;


--
-- Name: menu_config; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.menu_config (
    id integer NOT NULL,
    tipo character varying(30) NOT NULL,
    titulo character varying(200),
    contenido text,
    imagen_url text,
    enlace_url text,
    orden integer,
    activo boolean,
    pagina character varying(30),
    categoria_id integer,
    producto_id integer,
    creado_por integer,
    actualizado_en timestamp without time zone
);


ALTER TABLE public.menu_config OWNER TO oxidian;

--
-- Name: menu_config_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.menu_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_config_id_seq OWNER TO oxidian;

--
-- Name: menu_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.menu_config_id_seq OWNED BY public.menu_config.id;


--
-- Name: notification_outbox; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.notification_outbox (
    id integer NOT NULL,
    canal character varying(30) NOT NULL,
    evento character varying(60) NOT NULL,
    destinatario character varying(200) NOT NULL,
    payload_json text NOT NULL,
    estado character varying(20) NOT NULL,
    intentos integer NOT NULL,
    max_intentos integer NOT NULL,
    siguiente_intento_en timestamp without time zone,
    ultimo_error text,
    pedido_id integer,
    user_id integer,
    creado_en timestamp without time zone NOT NULL,
    enviado_en timestamp without time zone
);


ALTER TABLE public.notification_outbox OWNER TO oxidian;

--
-- Name: notification_outbox_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.notification_outbox_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_outbox_id_seq OWNER TO oxidian;

--
-- Name: notification_outbox_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.notification_outbox_id_seq OWNED BY public.notification_outbox.id;


--
-- Name: order_events; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.order_events (
    id integer NOT NULL,
    pedido_id integer NOT NULL,
    tipo character varying(50) NOT NULL,
    estado_anterior character varying(30),
    estado_nuevo character varying(30),
    actor_id integer,
    canal character varying(30),
    detalle text,
    metadata_json text,
    creado_en timestamp without time zone NOT NULL
);


ALTER TABLE public.order_events OWNER TO oxidian;

--
-- Name: order_events_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.order_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_events_id_seq OWNER TO oxidian;

--
-- Name: order_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.order_events_id_seq OWNED BY public.order_events.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    pedido_id integer NOT NULL,
    producto_id integer NOT NULL,
    cantidad integer NOT NULL,
    precio_unit numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    notas text,
    metadata_json text
);


ALTER TABLE public.order_items OWNER TO oxidian;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_items_id_seq OWNER TO oxidian;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: order_provider_status; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.order_provider_status (
    id integer NOT NULL,
    pedido_id integer NOT NULL,
    preparado boolean NOT NULL,
    preparado_en timestamp without time zone,
    actualizado_por integer,
    proveedor_id integer NOT NULL
);


ALTER TABLE public.order_provider_status OWNER TO oxidian;

--
-- Name: order_provider_status_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.order_provider_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_provider_status_id_seq OWNER TO oxidian;

--
-- Name: order_provider_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.order_provider_status_id_seq OWNED BY public.order_provider_status.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    numero_pedido character varying(20) NOT NULL,
    cliente_id integer NOT NULL,
    estado character varying(30) NOT NULL,
    origen character varying(20),
    subtotal numeric(10,2) NOT NULL,
    descuento numeric(10,2),
    total numeric(10,2) NOT NULL,
    cupon_id integer,
    puntos_usados integer,
    puntos_ganados integer,
    metodo_pago character varying(30),
    direccion_entrega text,
    notas text,
    preparador_id integer,
    repartidor_id integer,
    cajero_id integer,
    creado_en timestamp without time zone,
    entregado_en timestamp without time zone,
    zona_id integer,
    afiliado_codigo_id integer,
    es_entrega_epicentro boolean,
    codigo_confirmacion character varying(8),
    codigo_confirmado_en timestamp without time zone,
    intentos_codigo integer,
    pago_confirmado boolean,
    pago_confirmado_por integer,
    pago_confirmado_en timestamp without time zone,
    whatsapp_enviado_confirmacion boolean,
    resena_calificacion integer,
    resena_comentario text,
    resena_enviada boolean,
    tipo_entrega_cliente character varying(20) DEFAULT 'delivery'::character varying NOT NULL,
    service_commission_pct numeric(5,2) DEFAULT 0 NOT NULL,
    service_commission_amount numeric(10,2) DEFAULT 0 NOT NULL,
    merchant_net_amount numeric(10,2) DEFAULT 0 NOT NULL,
    proveedor_preparado boolean DEFAULT false NOT NULL,
    proveedor_preparado_en timestamp without time zone,
    en_punto_encuentro boolean DEFAULT false NOT NULL,
    en_punto_encuentro_en timestamp without time zone,
    codigo_confirmacion_expira_en timestamp without time zone,
    iva_total numeric(10,2) DEFAULT 0 NOT NULL,
    confirmacion_estado character varying(30),
    confirmacion_en timestamp without time zone,
    confirmacion_nivel character varying(10)
);


ALTER TABLE public.orders OWNER TO oxidian;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO oxidian;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: points_log; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.points_log (
    id integer NOT NULL,
    cliente_id integer NOT NULL,
    pedido_id integer,
    tipo character varying(20) NOT NULL,
    cantidad integer NOT NULL,
    descripcion character varying(200),
    creado_en timestamp without time zone
);


ALTER TABLE public.points_log OWNER TO oxidian;

--
-- Name: points_log_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.points_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.points_log_id_seq OWNER TO oxidian;

--
-- Name: points_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.points_log_id_seq OWNED BY public.points_log.id;


--
-- Name: price_history; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.price_history (
    id integer NOT NULL,
    producto_id integer NOT NULL,
    precio_anterior numeric(10,2),
    precio_nuevo numeric(10,2) NOT NULL,
    cambiado_por integer,
    cambiado_en timestamp without time zone,
    motivo character varying(200)
);


ALTER TABLE public.price_history OWNER TO oxidian;

--
-- Name: price_history_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.price_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.price_history_id_seq OWNER TO oxidian;

--
-- Name: price_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.price_history_id_seq OWNED BY public.price_history.id;


--
-- Name: product_extra_groups; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.product_extra_groups (
    id integer NOT NULL,
    producto_id integer NOT NULL,
    nombre character varying(80) NOT NULL,
    descripcion character varying(240),
    min_selecciones integer DEFAULT 0 NOT NULL,
    max_selecciones integer DEFAULT 1 NOT NULL,
    orden integer NOT NULL,
    activo boolean NOT NULL,
    CONSTRAINT ck_extra_group_min CHECK ((min_selecciones >= 0)),
    CONSTRAINT ck_extra_group_range CHECK ((max_selecciones >= min_selecciones))
);


ALTER TABLE public.product_extra_groups OWNER TO oxidian;

--
-- Name: product_extra_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.product_extra_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_extra_groups_id_seq OWNER TO oxidian;

--
-- Name: product_extra_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.product_extra_groups_id_seq OWNED BY public.product_extra_groups.id;


--
-- Name: product_extra_options; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.product_extra_options (
    id integer NOT NULL,
    grupo_id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    precio numeric(10,2) NOT NULL,
    max_cantidad integer NOT NULL,
    orden integer NOT NULL,
    activo boolean NOT NULL,
    catalog_item_id integer,
    CONSTRAINT ck_extra_option_max_qty CHECK ((max_cantidad >= 1)),
    CONSTRAINT ck_extra_option_price CHECK ((precio >= (0)::numeric))
);


ALTER TABLE public.product_extra_options OWNER TO oxidian;

--
-- Name: product_extra_options_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.product_extra_options_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_extra_options_id_seq OWNER TO oxidian;

--
-- Name: product_extra_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.product_extra_options_id_seq OWNED BY public.product_extra_options.id;


--
-- Name: product_extras; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.product_extras (
    id integer NOT NULL,
    producto_id integer NOT NULL,
    nombre character varying(80) NOT NULL,
    precio numeric(10,2) NOT NULL,
    activo boolean NOT NULL,
    orden integer NOT NULL,
    creado_en timestamp without time zone
);


ALTER TABLE public.product_extras OWNER TO oxidian;

--
-- Name: product_extras_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.product_extras_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_extras_id_seq OWNER TO oxidian;

--
-- Name: product_extras_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.product_extras_id_seq OWNED BY public.product_extras.id;


--
-- Name: product_presentations; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.product_presentations (
    id integer NOT NULL,
    producto_id integer NOT NULL,
    "tamaño" character varying(20) NOT NULL,
    precio_extra numeric(10,2) NOT NULL,
    activo boolean NOT NULL,
    orden integer NOT NULL
);


ALTER TABLE public.product_presentations OWNER TO oxidian;

--
-- Name: product_presentations_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.product_presentations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_presentations_id_seq OWNER TO oxidian;

--
-- Name: product_presentations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.product_presentations_id_seq OWNED BY public.product_presentations.id;


--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.product_variants (
    id integer NOT NULL,
    product_id integer NOT NULL,
    sku character varying(60),
    talla character varying(20),
    color character varying(40),
    color_hex character varying(7),
    precio_override numeric(10,2),
    stock integer DEFAULT 0 NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    orden integer DEFAULT 0 NOT NULL,
    imagen_url character varying(300)
);


ALTER TABLE public.product_variants OWNER TO oxidian;

--
-- Name: product_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.product_variants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_variants_id_seq OWNER TO oxidian;

--
-- Name: product_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.product_variants_id_seq OWNED BY public.product_variants.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.products (
    id integer NOT NULL,
    nombre character varying(150) NOT NULL,
    descripcion text,
    precio numeric(10,2) NOT NULL,
    precio_costo numeric(10,2),
    categoria_id integer,
    imagen_url text,
    origen_pais character varying(50),
    es_combo boolean,
    combo_precio_modo character varying(30) NOT NULL,
    combo_descuento_pct numeric(5,2) NOT NULL,
    combo_precio_base numeric(10,2) NOT NULL,
    tipo_producto character varying(50),
    atributos_json text,
    activo boolean,
    creado_en timestamp without time zone,
    canal_preparacion character varying(20) NOT NULL,
    tipo_entrega character varying(20),
    fecha_llegada date,
    dias_anticipacion_encargo integer,
    hora_inicio_visibilidad time without time zone,
    hora_fin_visibilidad time without time zone,
    dias_semana_json text,
    stock_mostrar_en_web boolean,
    canjeable_con_puntos boolean,
    puntos_para_canje integer,
    es_hipoalergenico boolean,
    alergenos_info text,
    alergenos_json text,
    modalidad_entrega character varying(20) DEFAULT 'ambas'::character varying NOT NULL,
    proveedor_id integer,
    proveedor_despachador_id integer,
    metodo_entrega_permitido character varying(20) DEFAULT 'ambas'::character varying NOT NULL,
    grupo_pedido character varying(80),
    solo_canje boolean DEFAULT false NOT NULL,
    vertical character varying(20) DEFAULT 'ambos'::character varying NOT NULL,
    iva_pct numeric(4,2),
    marca character varying(100),
    material character varying(100),
    dimensiones character varying(80),
    peso_gramos integer,
    garantia_meses integer
);


ALTER TABLE public.products OWNER TO oxidian;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO oxidian;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: proveedor_productos; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.proveedor_productos (
    id integer NOT NULL,
    proveedor_id integer NOT NULL,
    producto_id integer NOT NULL,
    stock integer NOT NULL,
    precio_costo numeric(10,2),
    activo boolean NOT NULL,
    actualizado_en timestamp without time zone,
    CONSTRAINT ck_proveedor_productos_stock_nonnegative CHECK ((stock >= 0))
);


ALTER TABLE public.proveedor_productos OWNER TO oxidian;

--
-- Name: proveedor_productos_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.proveedor_productos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proveedor_productos_id_seq OWNER TO oxidian;

--
-- Name: proveedor_productos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.proveedor_productos_id_seq OWNED BY public.proveedor_productos.id;


--
-- Name: proveedores; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.proveedores (
    id integer NOT NULL,
    nombre character varying(150) NOT NULL,
    razon_social character varying(200),
    direccion text,
    telefono character varying(20),
    email character varying(120),
    horario text,
    hora_apertura time without time zone,
    hora_cierre time without time zone,
    modelo_acuerdo character varying(30) DEFAULT 'stock_proveedor'::character varying NOT NULL,
    comision_pct numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    iban character varying(40),
    notas text,
    activo boolean NOT NULL,
    branding_logo_url character varying(300),
    branding_color_primario character varying(20),
    branding_color_secundario character varying(20),
    branding_color_acento character varying(20),
    branding_slogan character varying(200),
    tienda_abierta_override boolean,
    tienda_mensaje_cierre character varying(300),
    creado_en timestamp without time zone NOT NULL,
    CONSTRAINT ck_proveedores_comision_pct_range CHECK (((comision_pct >= (0)::numeric) AND (comision_pct <= (100)::numeric)))
);


ALTER TABLE public.proveedores OWNER TO oxidian;

--
-- Name: proveedores_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.proveedores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proveedores_id_seq OWNER TO oxidian;

--
-- Name: proveedores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.proveedores_id_seq OWNED BY public.proveedores.id;


--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.push_subscriptions (
    id integer NOT NULL,
    user_id integer,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth character varying(100) NOT NULL,
    rol character varying(30),
    user_agent character varying(300),
    creado_en timestamp without time zone,
    ultimo_uso timestamp without time zone,
    activo boolean
);


ALTER TABLE public.push_subscriptions OWNER TO oxidian;

--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.push_subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.push_subscriptions_id_seq OWNER TO oxidian;

--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.push_subscriptions_id_seq OWNED BY public.push_subscriptions.id;


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.reviews (
    id integer NOT NULL,
    producto_id integer NOT NULL,
    cliente_id integer NOT NULL,
    pedido_id integer,
    calificacion integer NOT NULL,
    comentario text,
    aprobada boolean,
    creado_en timestamp without time zone
);


ALTER TABLE public.reviews OWNER TO oxidian;

--
-- Name: reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reviews_id_seq OWNER TO oxidian;

--
-- Name: reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.reviews_id_seq OWNED BY public.reviews.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.schema_migrations (
    id character varying(120) NOT NULL,
    description text,
    applied_at timestamp without time zone NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO oxidian;

--
-- Name: site_config; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.site_config (
    id integer NOT NULL,
    clave character varying(50) NOT NULL,
    valor text,
    descripcion character varying(200),
    actualizado_en timestamp without time zone,
    actualizado_por integer
);


ALTER TABLE public.site_config OWNER TO oxidian;

--
-- Name: site_config_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.site_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.site_config_id_seq OWNER TO oxidian;

--
-- Name: site_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.site_config_id_seq OWNED BY public.site_config.id;


--
-- Name: staff_payments; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.staff_payments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    tipo character varying(20) NOT NULL,
    monto numeric(10,2) NOT NULL,
    concepto character varying(200),
    periodo_inicio date,
    periodo_fin date,
    pedido_id integer,
    origen character varying(30) NOT NULL,
    pagado boolean,
    fecha_pago timestamp without time zone,
    registrado_por integer,
    creado_en timestamp without time zone,
    CONSTRAINT ck_staff_payment_monto_nonnegative CHECK ((monto >= (0)::numeric))
);


ALTER TABLE public.staff_payments OWNER TO oxidian;

--
-- Name: staff_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.staff_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.staff_payments_id_seq OWNER TO oxidian;

--
-- Name: staff_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.staff_payments_id_seq OWNED BY public.staff_payments.id;


--
-- Name: stock; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.stock (
    id integer NOT NULL,
    producto_id integer NOT NULL,
    cantidad integer NOT NULL,
    unidad character varying(20),
    lote character varying(50),
    fecha_entrada date,
    fecha_caducidad date,
    alerta_dias integer,
    ubicacion character varying(100),
    CONSTRAINT ck_stock_cantidad_nonnegative CHECK ((cantidad >= 0))
);


ALTER TABLE public.stock OWNER TO oxidian;

--
-- Name: stock_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.stock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stock_id_seq OWNER TO oxidian;

--
-- Name: stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.stock_id_seq OWNED BY public.stock.id;


--
-- Name: tenant_config; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.tenant_config (
    id integer NOT NULL,
    modo character varying(20),
    comision_pct numeric(5,2),
    delivery_habilitado boolean,
    pickup_habilitado boolean,
    suspendido boolean,
    ciclo_dias integer,
    suspendida boolean DEFAULT false NOT NULL,
    suspendida_motivo character varying(300),
    suspendida_en timestamp without time zone,
    ciclo_inicio date
);


ALTER TABLE public.tenant_config OWNER TO oxidian;

--
-- Name: tenant_config_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.tenant_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tenant_config_id_seq OWNER TO oxidian;

--
-- Name: tenant_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.tenant_config_id_seq OWNED BY public.tenant_config.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.users (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(256) NOT NULL,
    rol character varying(20) NOT NULL,
    telefono character varying(20),
    telefono_normalizado character varying(20),
    direccion text,
    puntos integer,
    activo boolean,
    creado_en timestamp without time zone,
    last_seen timestamp without time zone,
    en_linea boolean,
    cod_puntos character varying(8),
    cod_puntos_expira timestamp without time zone,
    cod_puntos_intentos integer,
    mfa_secret character varying(64),
    mfa_enabled boolean DEFAULT false NOT NULL,
    mfa_session_version integer DEFAULT 0 NOT NULL,
    puesto_trabajo character varying(100),
    salario_base numeric(10,2),
    tarifa_entrega numeric(10,2),
    proveedor_id integer,
    mfa_recovery_codes_hash text,
    whatsapp_opt_out boolean DEFAULT false NOT NULL,
    whatsapp_opt_out_en timestamp without time zone,
    zona_repartidor_id integer,
    nif character varying(15)
);


ALTER TABLE public.users OWNER TO oxidian;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO oxidian;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: zonas_entrega; Type: TABLE; Schema: public; Owner: oxidian
--

CREATE TABLE public.zonas_entrega (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion text,
    es_epicentro boolean,
    activo boolean,
    precio_envio numeric(10,2),
    tiempo_estimado_min integer,
    gratis_desde numeric(10,2),
    orden integer,
    centro_lat double precision,
    centro_lng double precision,
    radio_km double precision
);


ALTER TABLE public.zonas_entrega OWNER TO oxidian;

--
-- Name: zonas_entrega_id_seq; Type: SEQUENCE; Schema: public; Owner: oxidian
--

CREATE SEQUENCE public.zonas_entrega_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.zonas_entrega_id_seq OWNER TO oxidian;

--
-- Name: zonas_entrega_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oxidian
--

ALTER SEQUENCE public.zonas_entrega_id_seq OWNED BY public.zonas_entrega.id;


--
-- Name: admin_features id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.admin_features ALTER COLUMN id SET DEFAULT nextval('public.admin_features_id_seq'::regclass);


--
-- Name: affiliate_codes id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.affiliate_codes ALTER COLUMN id SET DEFAULT nextval('public.affiliate_codes_id_seq'::regclass);


--
-- Name: affiliate_uses id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.affiliate_uses ALTER COLUMN id SET DEFAULT nextval('public.affiliate_uses_id_seq'::regclass);


--
-- Name: ai_assistant_config id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.ai_assistant_config ALTER COLUMN id SET DEFAULT nextval('public.ai_assistant_config_id_seq'::regclass);


--
-- Name: ai_conversations id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.ai_conversations ALTER COLUMN id SET DEFAULT nextval('public.ai_conversations_id_seq'::regclass);


--
-- Name: ai_usage_log id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.ai_usage_log ALTER COLUMN id SET DEFAULT nextval('public.ai_usage_log_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: bot_ai_messages id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.bot_ai_messages ALTER COLUMN id SET DEFAULT nextval('public.bot_ai_messages_id_seq'::regclass);


--
-- Name: bot_ai_usage id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.bot_ai_usage ALTER COLUMN id SET DEFAULT nextval('public.bot_ai_usage_id_seq'::regclass);


--
-- Name: caja id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.caja ALTER COLUMN id SET DEFAULT nextval('public.caja_id_seq'::regclass);


--
-- Name: campanas_marketing id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.campanas_marketing ALTER COLUMN id SET DEFAULT nextval('public.campanas_marketing_id_seq'::regclass);


--
-- Name: categorias id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.categorias ALTER COLUMN id SET DEFAULT nextval('public.categorias_id_seq'::regclass);


--
-- Name: combo_groups id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.combo_groups ALTER COLUMN id SET DEFAULT nextval('public.combo_groups_id_seq'::regclass);


--
-- Name: combo_items id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.combo_items ALTER COLUMN id SET DEFAULT nextval('public.combo_items_id_seq'::regclass);


--
-- Name: coupons id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.coupons ALTER COLUMN id SET DEFAULT nextval('public.coupons_id_seq'::regclass);


--
-- Name: extra_catalog_items id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.extra_catalog_items ALTER COLUMN id SET DEFAULT nextval('public.extra_catalog_items_id_seq'::regclass);


--
-- Name: hub_commissions id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.hub_commissions ALTER COLUMN id SET DEFAULT nextval('public.hub_commissions_id_seq'::regclass);


--
-- Name: idempotency_keys id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.idempotency_keys ALTER COLUMN id SET DEFAULT nextval('public.idempotency_keys_id_seq'::regclass);


--
-- Name: menu_config id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.menu_config ALTER COLUMN id SET DEFAULT nextval('public.menu_config_id_seq'::regclass);


--
-- Name: notification_outbox id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.notification_outbox ALTER COLUMN id SET DEFAULT nextval('public.notification_outbox_id_seq'::regclass);


--
-- Name: order_events id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.order_events ALTER COLUMN id SET DEFAULT nextval('public.order_events_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: order_provider_status id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.order_provider_status ALTER COLUMN id SET DEFAULT nextval('public.order_provider_status_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: points_log id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.points_log ALTER COLUMN id SET DEFAULT nextval('public.points_log_id_seq'::regclass);


--
-- Name: price_history id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.price_history ALTER COLUMN id SET DEFAULT nextval('public.price_history_id_seq'::regclass);


--
-- Name: product_extra_groups id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_extra_groups ALTER COLUMN id SET DEFAULT nextval('public.product_extra_groups_id_seq'::regclass);


--
-- Name: product_extra_options id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_extra_options ALTER COLUMN id SET DEFAULT nextval('public.product_extra_options_id_seq'::regclass);


--
-- Name: product_extras id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_extras ALTER COLUMN id SET DEFAULT nextval('public.product_extras_id_seq'::regclass);


--
-- Name: product_presentations id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_presentations ALTER COLUMN id SET DEFAULT nextval('public.product_presentations_id_seq'::regclass);


--
-- Name: product_variants id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_variants ALTER COLUMN id SET DEFAULT nextval('public.product_variants_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: proveedor_productos id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.proveedor_productos ALTER COLUMN id SET DEFAULT nextval('public.proveedor_productos_id_seq'::regclass);


--
-- Name: proveedores id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.proveedores ALTER COLUMN id SET DEFAULT nextval('public.proveedores_id_seq'::regclass);


--
-- Name: push_subscriptions id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.push_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.push_subscriptions_id_seq'::regclass);


--
-- Name: reviews id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.reviews ALTER COLUMN id SET DEFAULT nextval('public.reviews_id_seq'::regclass);


--
-- Name: site_config id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.site_config ALTER COLUMN id SET DEFAULT nextval('public.site_config_id_seq'::regclass);


--
-- Name: staff_payments id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.staff_payments ALTER COLUMN id SET DEFAULT nextval('public.staff_payments_id_seq'::regclass);


--
-- Name: stock id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.stock ALTER COLUMN id SET DEFAULT nextval('public.stock_id_seq'::regclass);


--
-- Name: tenant_config id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.tenant_config ALTER COLUMN id SET DEFAULT nextval('public.tenant_config_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: zonas_entrega id; Type: DEFAULT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.zonas_entrega ALTER COLUMN id SET DEFAULT nextval('public.zonas_entrega_id_seq'::regclass);


--
-- Data for Name: admin_features; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.admin_features (id, user_id, feature, activo, actualizado_por, actualizado_en) FROM stdin;
1	2	caja	t	\N	2026-07-11 08:29:44.597063
2	2	productos	t	\N	2026-07-11 08:29:44.598812
3	2	stock	t	\N	2026-07-11 08:29:44.599876
4	2	cupones	t	\N	2026-07-11 08:29:44.600888
5	2	staff_pagos	t	\N	2026-07-11 08:29:44.602042
6	2	reportes	t	\N	2026-07-11 08:29:44.603151
7	2	zonas	t	\N	2026-07-11 08:29:44.604181
8	2	auditoria	t	\N	2026-07-11 08:29:44.605178
9	2	marketing	t	\N	2026-07-11 08:29:44.60622
10	2	pos	t	\N	2026-07-11 08:29:44.607231
11	2	whatsapp	t	\N	2026-07-11 08:29:44.608201
12	2	usuarios	t	\N	2026-07-11 08:29:44.609179
\.


--
-- Data for Name: affiliate_codes; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.affiliate_codes (id, codigo, descripcion, tipo, user_id, descuento_tipo, descuento_valor, comision_tipo, comision_valor, activo, usos_maximos, usos_actuales, fecha_inicio, fecha_fin, creado_en, creado_por) FROM stdin;
\.


--
-- Data for Name: affiliate_uses; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.affiliate_uses (id, codigo_id, pedido_id, cliente_id, descuento_aplicado, comision_generada, comision_pagada, staff_payment_id, creado_en) FROM stdin;
\.


--
-- Data for Name: ai_assistant_config; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.ai_assistant_config (id, activo, modelo, api_key, system_prompt) FROM stdin;
\.


--
-- Data for Name: ai_conversations; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.ai_conversations (id, telefono, resumen, creado_en) FROM stdin;
\.


--
-- Data for Name: ai_usage_log; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.ai_usage_log (id, conversation_id, tokens_in, tokens_out, creado_en) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.audit_log (id, user_id, accion, recurso, recurso_id, detalle, ip, creado_en) FROM stdin;
1	2	toggle_vertical	site_config	\N	TIPO_TIENDA=comida→producto	172.18.0.8	2026-07-11 08:44:21.561489
2	2	toggle_vertical	site_config	\N	TIPO_TIENDA=producto→comida	172.18.0.8	2026-07-11 08:44:43.683935
3	2	toggle_modulo	site_config	\N	FEATURE_DELIVERY=0	172.18.0.8	2026-07-11 08:44:48.824909
4	2	toggle_modulo	site_config	\N	FEATURE_DELIVERY=1	172.18.0.8	2026-07-11 08:44:52.380738
5	2	toggle_modulo	site_config	\N	FEATURE_RECOGIDA=0	172.18.0.8	2026-07-11 08:44:55.910694
6	2	toggle_modulo	site_config	\N	FEATURE_PEDIDOS_PROGRAMADOS=0	172.18.0.8	2026-07-11 08:44:59.006607
7	2	toggle_modulo	site_config	\N	FEATURE_PUNTOS=0	172.18.0.8	2026-07-11 08:45:09.461011
8	2	toggle_vertical	site_config	\N	TIPO_TIENDA=comida→producto	172.18.0.8	2026-07-11 11:20:25.223228
9	2	toggle_modo_tienda	site_config	\N	MODO_TIENDA propia→bar_servicio	172.18.0.8	2026-07-11 11:20:34.022449
10	2	toggle_modo_tienda	site_config	\N	MODO_TIENDA bar_servicio→propia	172.18.0.8	2026-07-11 11:20:35.790823
11	2	toggle_vertical	site_config	\N	TIPO_TIENDA=producto→comida	172.18.0.8	2026-07-11 11:20:38.753965
12	2	toggle_modulo	site_config	\N	FEATURE_PUNTOS=1	172.18.0.8	2026-07-11 11:20:48.058094
13	2	editar_admin	user	2	\N	172.18.0.8	2026-07-11 11:21:06.698331
14	2	editar_admin	user	2	\N	172.18.0.8	2026-07-11 11:47:18.950398
15	2	crear_usuario	user	3	stevenconejito29@gmail.com [cocina]	172.18.0.8	2026-07-11 12:27:44.34647
16	2	crear_categoria	categoria	1	Test	172.18.0.8	2026-07-12 11:02:54.130789
17	2	toggle_vertical	site_config	\N	TIPO_TIENDA=comida→producto	172.18.0.8	2026-07-12 11:05:24.292974
18	2	toggle_vertical	site_config	\N	TIPO_TIENDA=producto→comida	172.18.0.8	2026-07-12 11:06:15.708989
19	2	agregar_stock	product	1	+100 uds — lote sin lote	172.18.0.8	2026-07-12 11:06:33.929899
20	2	config_section_update	site_config	\N	VALIDAR_RADIO_ENTREGA, BLOQUEAR_DIRECCION_NO_VERIFICADA, RADIO_ENTREGA_KM, PEDIDO_MINIMO_EUR	172.18.0.8	2026-07-12 11:09:42.752556
21	2	crear_zona	zona_entrega	\N	Carmona	172.18.0.8	2026-07-12 11:10:48.55038
22	2	crear_usuario	user	5	stevenconejito@gmail.com [cocina]	172.18.0.8	2026-07-12 11:23:09.73387
23	2	editar_usuario	user	5	\N	172.18.0.8	2026-07-12 11:24:49.795
24	5	pedido_entregado	order	1	#1001 total=103.00 repartidor=5 puntos=103	172.18.0.8	2026-07-12 11:26:23.700417
25	2	config_section_update	site_config	\N	COLOR_PRIMARIO, COLOR_SECUNDARIO, COLOR_ACENTO	172.18.0.8	2026-07-12 11:58:08.993224
26	2	editar_cliente	user	\N	cliente_id=7 nombre='Carlos Ruiz Mendoza' tel=***333	127.0.0.1	2026-07-13 15:11:17.026462
27	2	config_section_update	site_config	\N	HORARIO_APERTURA	172.18.0.8	2026-07-13 23:04:20.451658
28	2	reasignar_pedido	order	5	preparador_id: sin asignar -> 3	172.18.0.8	2026-07-13 23:08:44.801003
29	2	editar_usuario	user	3	\N	172.18.0.8	2026-07-13 23:10:33.981203
30	3	pedido_entregado	order	5	#1005 total=103.00 repartidor=3 puntos=103	172.18.0.8	2026-07-13 23:12:33.332346
31	2	agregar_stock	product	2	+50 uds — lote sin lote	172.18.0.8	2026-07-13 23:17:06.930787
32	2	agregar_stock	product	2	+50 uds — lote sin lote	172.18.0.8	2026-07-13 23:17:06.944752
33	2	editar_usuario	user	5	\N	172.18.0.8	2026-07-13 23:22:34.248494
34	2	editar_usuario	user	3	\N	172.18.0.8	2026-07-13 23:24:21.664942
35	2	config_section_update	site_config	\N	PUNTOS_CANJE_RATIO	172.18.0.8	2026-07-13 23:42:21.450926
36	2	merge_customer_identity	user	4	Referencias consolidadas: {'orders.cliente_id': 4, 'points_log.cliente_id': 1, 'reviews.cliente_id': 0, 'affiliate_uses.cliente_id': 0, 'push_subscriptions.user_id': 1, 'notification_outbox.user_id': 13}	maintenance	2026-07-14 00:46:58.866477
37	\N	purge_terminal_delivery_code	order	5	Código eliminado tras estado terminal	maintenance	2026-07-14 00:55:50.53315
38	\N	purge_terminal_delivery_code	order	1	Código eliminado tras estado terminal	maintenance	2026-07-14 00:55:50.533156
39	2	avanzar_pedido	order	7	en_ruta	172.18.0.8	2026-07-14 05:35:08.391249
40	2	config_section_update	site_config	\N	COLOR_PRIMARIO, COLOR_SECUNDARIO, COLOR_ACENTO	172.18.0.8	2026-07-14 07:19:46.326158
41	2	config_section_update	site_config	\N	COLOR_PRIMARIO, COLOR_SECUNDARIO, COLOR_ACENTO	172.18.0.8	2026-07-14 09:19:34.169091
42	2	config_section_update	site_config	\N	COLOR_PRIMARIO, COLOR_SECUNDARIO, COLOR_ACENTO	172.18.0.8	2026-07-14 10:36:27.271506
43	2	config_section_update	site_config	\N	COLOR_PRIMARIO, COLOR_ACENTO	172.18.0.8	2026-07-14 10:39:26.629985
44	2	config_section_update	site_config	\N	COLOR_SECUNDARIO	172.18.0.8	2026-07-14 10:39:36.500058
45	2	config_section_update	site_config	\N	COLOR_ACENTO	172.18.0.8	2026-07-14 10:39:47.87267
46	2	config_section_update	site_config	\N	COLOR_PRIMARIO, COLOR_SECUNDARIO, COLOR_ACENTO	172.18.0.8	2026-07-14 15:40:53.521317
\.


--
-- Data for Name: bot_ai_messages; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.bot_ai_messages (id, telefono_hash, rol, contenido, creado_en) FROM stdin;
\.


--
-- Data for Name: bot_ai_usage; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.bot_ai_usage (id, telefono_hash, tokens_in, tokens_out, creado_en) FROM stdin;
\.


--
-- Data for Name: caja; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.caja (id, tipo, categoria, monto, concepto, pedido_id, staff_payment_id, registrado_por, fecha) FROM stdin;
1	ingreso	venta_online	103.00	Pedido #1001	1	\N	5	2026-07-12 11:26:23.663177
2	ingreso	venta_online	103.00	Pedido #1005	5	\N	3	2026-07-13 23:12:33.31153
\.


--
-- Data for Name: campanas_marketing; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.campanas_marketing (id, titulo, mensaje, filtro_audiencia, zona_id, enviados, estado, error_detalle, creado_por, creado_en, enviado_en) FROM stdin;
\.


--
-- Data for Name: categorias; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.categorias (id, nombre, descripcion, imagen_url, activo, orden) FROM stdin;
1	Test	Productos para gays	categorias/cat_1.jpg	t	0
\.


--
-- Data for Name: combo_groups; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.combo_groups (id, combo_id, nombre, tipo, min_selecciones, max_selecciones, orden, requerido, descripcion, creado_en) FROM stdin;
\.


--
-- Data for Name: combo_items; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.combo_items (id, combo_id, combo_group_id, producto_id, cantidad, orden, precio_extra, es_predeterminado, activo, notas_preparacion, es_seleccionable, grupo_seleccion, max_selecciones, variant_id) FROM stdin;
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.coupons (id, codigo, descripcion, tipo, valor, minimo_pedido, usos_maximos, usos_actuales, activo, fecha_inicio, fecha_fin) FROM stdin;
\.


--
-- Data for Name: extra_catalog_items; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.extra_catalog_items (id, nombre, descripcion, precio, max_cantidad, activo, creado_en, actualizado_en) FROM stdin;
\.


--
-- Data for Name: hub_commissions; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.hub_commissions (id, pedido_id, monto, pct, creado_en) FROM stdin;
\.


--
-- Data for Name: idempotency_keys; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.idempotency_keys (id, scope, key, request_hash, response_status, response_body, order_id, user_id, creado_en, expira_en) FROM stdin;
5	checkout_web	auto:df71f3b4dda984d52d632dd18d67d5b8	e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855	302	{"order_id": 5, "numero": "#1005", "token": "0be42079e21c4a1ca45379358c99c9d0"}	5	\N	2026-07-13 23:07:21.130033	2026-07-14 23:07:21.129383
6	checkout_web	auto:21560b453af84a1a2149b71f55c1f258	e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855	302	{"order_id": 6, "numero": "#1006", "token": "b2dca0afc2ff4722b649c1af85dc4867"}	6	\N	2026-07-13 23:20:03.246319	2026-07-14 23:20:03.245724
7	checkout_web	auto:72207ba12f3ca63540ad54973e510cc3	e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855	302	{"order_id": 7, "numero": "#1007", "token": "74572114e6b6493fb9a7a355bb696da0"}	7	\N	2026-07-13 23:21:38.662311	2026-07-14 23:21:38.661491
8	checkout_web	auto:af569dd8e252959001ffc3de07b1b0a1	e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855	302	{"order_id": 8, "numero": "#1008", "token": "d9fd6c5863db4f14b75e61a6fb196e83"}	8	\N	2026-07-14 10:38:25.340894	2026-07-15 10:38:25.340275
\.


--
-- Data for Name: menu_config; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.menu_config (id, tipo, titulo, contenido, imagen_url, enlace_url, orden, activo, pagina, categoria_id, producto_id, creado_por, actualizado_en) FROM stdin;
1	texto_promo	Hhhh	Hhjjjkkkk	\N	\N	0	f	checkout	\N	\N	2	2026-07-14 08:13:35.879343
\.


--
-- Data for Name: notification_outbox; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.notification_outbox (id, canal, evento, destinatario, payload_json, estado, intentos, max_intentos, siguiente_intento_en, ultimo_error, pedido_id, user_id, creado_en, enviado_en) FROM stdin;
2	whatsapp	order_state	+622663874	{"telefono": "+622663874", "mensaje": "🔥 *¡Manos a la obra!*\\nTu pedido *#1001* está en preparación en este momento.\\nEn breve te avisamos cuando esté listo. ✨", "numero_pedido": "#1001", "estado": "armando"}	sent	1	3	\N	\N	1	2	2026-07-12 11:17:24.244103	2026-07-12 11:17:26.039847
28	whatsapp	points_otp	+34622663874	{"telefono": "+34622663874", "mensaje": "🔐 *Código de verificación — Mi Negocio*\\n\\nTu código para canjear puntos por *723 puntos* es:\\n\\n*036430*\\n\\n⏰ Válido 10 minutos. No lo compartas."}	sent	1	3	\N	\N	\N	2	2026-07-14 00:53:58.24536	2026-07-14 00:53:59.355456
29	whatsapp	order_state	+34622663874	{"telefono": "+34622663874", "mensaje": "😔 *Pedido cancelado*\\nTu pedido *#1004* fue cancelado. Sentimos los inconvenientes.\\nSi tienes dudas o quieres más información, escríbenos y lo resolvemos juntos. 💬", "numero_pedido": "#1004", "estado": "cancelado"}	sent	1	3	\N	\N	4	2	2026-07-14 00:56:41.559137	2026-07-14 00:56:42.345916
30	whatsapp	order_state	+34622663874	{"telefono": "+34622663874", "mensaje": "😔 *Pedido cancelado*\\nTu pedido *#1002* fue cancelado. Sentimos los inconvenientes.\\nSi tienes dudas o quieres más información, escríbenos y lo resolvemos juntos. 💬", "numero_pedido": "#1002", "estado": "cancelado"}	sent	1	3	\N	\N	2	2	2026-07-14 00:57:43.736307	2026-07-14 00:57:45.265033
31	whatsapp	order_state	+34622663874	{"telefono": "+34622663874", "mensaje": "😔 *Pedido cancelado*\\nTu pedido *#1003* fue cancelado. Sentimos los inconvenientes.\\nSi tienes dudas o quieres más información, escríbenos y lo resolvemos juntos. 💬", "numero_pedido": "#1003", "estado": "cancelado"}	sent	1	3	\N	\N	3	2	2026-07-14 05:34:50.660968	2026-07-14 05:34:51.706776
32	whatsapp	order_state	+34667478856	{"telefono": "+34667478856", "mensaje": "🚀 *¡En camino!*\\nTu pedido *#1007* ya va hacia ti.\\n\\nCuando el repartidor llegue te enviará el código de entrega. No compartas ningún código antes de recibir tu pedido. 🛵", "numero_pedido": "#1007", "estado": "en_ruta"}	sent	1	3	\N	\N	7	30	2026-07-14 05:35:08.406526	2026-07-14 05:35:10.446337
33	whatsapp	points_otp	+34622663874	{"telefono": "+34622663874", "mensaje": "🔐 *Código de verificación — El Parcerito*\\n\\nTu código para canjear puntos por *723 puntos* es:\\n\\n*796408*\\n\\n⏰ Válido 10 minutos. No lo compartas."}	sent	1	3	\N	\N	\N	2	2026-07-14 10:37:42.88727	2026-07-14 10:37:43.870644
12	whatsapp	points_balance	+34622663874	{"telefono": "+34622663874", "mensaje": "⭐ *Tus puntos en Mi Negocio*\\n\\nTienes *620 puntos* disponibles.\\nEquivalen hasta a *€6.20* de descuento.\\n\\nPara canjearlos, arma tu pedido en la web y verifica este mismo WhatsApp durante la confirmación."}	sent	1	3	\N	\N	\N	2	2026-07-13 19:58:46.317112	2026-07-13 19:58:48.287215
13	whatsapp	order_state	+34667478856	{"telefono": "+34667478856", "mensaje": "🎉 *¡Pedido recibido!*\\nTu pedido *#1005* ya está registrado. Total: *€103.00*.\\n\\n⏳ Todavía no ha comenzado la preparación. Te avisaremos cuando el equipo empiece.\\n\\nDesde aquí mismo puedes:\\n• Escribir *ESTADO* para ver cómo va.\\n• Escribir *CANCELAR* (solo antes de empezar a prepararlo).\\n• Escribir *AGENTE* si necesitas hablar con una persona.\\n\\nPuedes seguir consultando el estado por este mismo chat.\\n\\n🔐 *Un paso más para preparar tu pedido:*\\nResponde *SI* para confirmarlo y empezar a prepararlo, o *NO* para anularlo.", "numero_pedido": "#1005", "estado": "pendiente"}	sent	1	3	\N	\N	5	30	2026-07-13 23:07:21.13132	2026-07-13 23:07:22.202972
14	whatsapp	order_state	+34667478856	{"telefono": "+34667478856", "mensaje": "🔥 *¡Manos a la obra!*\\nTu pedido *#1005* está en preparación en este momento.\\nEn breve te avisamos cuando esté listo. ✨", "numero_pedido": "#1005", "estado": "armando"}	sent	1	3	\N	\N	5	30	2026-07-13 23:09:09.33676	2026-07-13 23:09:11.626935
15	whatsapp	order_state	+34667478856	{"telefono": "+34667478856", "mensaje": "✅ *¡Tu pedido está listo!*\\nEl pedido *#1005* está perfectamente preparado y en breve sale hacia ti. 📦", "numero_pedido": "#1005", "estado": "listo"}	sent	1	3	\N	\N	5	30	2026-07-13 23:09:23.674017	2026-07-13 23:09:24.553998
16	whatsapp	order_state	+34667478856	{"telefono": "+34667478856", "mensaje": "🚀 *¡En camino!*\\nTu pedido *#1005* ya va hacia ti.\\n\\nCuando el repartidor llegue te enviará el código de entrega. No compartas ningún código antes de recibir tu pedido. 🛵", "numero_pedido": "#1005", "estado": "en_ruta"}	sent	1	3	\N	\N	5	30	2026-07-13 23:11:15.008131	2026-07-13 23:11:15.951686
38	whatsapp	order_state	+34622663874	{"telefono": "+34622663874", "mensaje": "😔 *Pedido cancelado*\\nTu pedido *#1008* fue cancelado. Sentimos los inconvenientes.\\nSi tienes dudas o quieres más información, escríbenos y lo resolvemos juntos. 💬", "numero_pedido": "#1008", "estado": "cancelado"}	sent	1	3	\N	\N	8	2	2026-07-14 10:41:24.260187	2026-07-14 10:41:26.401707
17	whatsapp	delivery_code	+34667478856	{"telefono": "+34667478856", "mensaje": "🔐 *Código de entrega para tu pedido #1005: 781326*\\n\\nCompártelo únicamente con el repartidor cuando estés recibiendo tu pedido. Si elegiste Bizum, confirma primero el pago del importe exacto.", "numero_pedido": "#1005", "estado": "en_ruta"}	sent	1	3	\N	\N	5	30	2026-07-13 23:12:15.884696	2026-07-13 23:12:17.138202
35	push	web_push	1	{"subscription_id": 1, "payload": {"title": "🔔 Nuevo pedido Web", "body": "##1008 · €103.00 · Efectivo", "url": "/admin/pedidos", "icon": "/static/pwa-icon-192.png", "badge": "/static/favicon-32.png", "timestamp": 1784025505351}}	failed	3	3	2026-07-14 10:52:29.384018	Could not deserialize key data. The data may be in an incorrect format, it may be encrypted with an unsupported algorithm, or it may be an unsupported key type (e.g. EC curves with explicit parameters). Details: ASN.1 parsing error: invalid length	\N	2	2026-07-14 10:38:25.352222	\N
19	whatsapp	review_request	+34667478856	{"telefono": "+34667478856", "mensaje": "⭐ *¿Cómo estuvo tu pedido #1005?*\\n\\nResponde con una calificación del 1 al 5 y, si quieres, un comentario.\\nTu opinión nos ayuda a mejorar."}	sent	1	3	\N	\N	5	30	2026-07-13 23:12:33.336272	2026-07-13 23:14:05.637829
18	whatsapp	order_state	+34667478856	{"telefono": "+34667478856", "mensaje": "🎊 *¡Pedido entregado!*\\n¡Esperamos que te haya encantado! 😍\\nGanaste *103 puntos* 🌟 — van sumando para tu próximo descuento.\\n¡Gracias por elegirnos! 💛", "numero_pedido": "#1005", "estado": "entregado"}	sent	1	3	\N	\N	5	30	2026-07-13 23:12:33.336266	2026-07-13 23:12:36.129273
20	whatsapp	order_state	+632907709	{"telefono": "+632907709", "mensaje": "🎉 *¡Pedido recibido!*\\nTu pedido *#1006* ya está registrado. Total: *€103.00*.\\n\\n⏳ Todavía no ha comenzado la preparación. Te avisaremos cuando el equipo empiece.\\n\\nDesde aquí mismo puedes:\\n• Escribir *ESTADO* para ver cómo va.\\n• Escribir *CANCELAR* (solo antes de empezar a prepararlo).\\n• Escribir *AGENTE* si necesitas hablar con una persona.\\n\\nPuedes seguir consultando el estado por este mismo chat.\\n\\n🔐 *Un paso más para preparar tu pedido:*\\nResponde *SI* para confirmarlo y empezar a prepararlo, o *NO* para anularlo.", "numero_pedido": "#1006", "estado": "pendiente"}	sent	1	3	\N	\N	6	31	2026-07-13 23:20:03.247003	2026-07-13 23:20:04.364042
27	whatsapp	points_balance	+34622663874	{"telefono": "+34622663874", "mensaje": "⭐ *Tus puntos en Mi Negocio*\\n\\nTienes *620 puntos* disponibles.\\nEquivalen hasta a *€0.62* de descuento.\\n\\nPara canjearlos, arma tu pedido en la web y verifica este mismo WhatsApp durante la confirmación."}	sent	1	3	\N	\N	\N	2	2026-07-14 00:27:28.595703	2026-07-14 00:27:31.217241
1	whatsapp	order_state	+622663874	{"telefono": "+622663874", "mensaje": "🎉 *¡Pedido recibido!*\\nTu pedido *#1001* ya está registrado. Total: *€103.00*.\\n\\nDesde aquí mismo puedes:\\n• Escribir *ESTADO* para ver cómo va.\\n• Escribir *CANCELAR* (solo antes de empezar a prepararlo).\\n• Escribir *AGENTE* si necesitas hablar con una persona.\\n\\n¡Estamos en ello ahora mismo! 🔥", "numero_pedido": "#1001", "estado": "pendiente"}	sent	1	3	\N	\N	1	2	2026-07-12 11:12:12.675521	2026-07-12 11:12:13.804277
21	whatsapp	points_otp	+34667478856	{"telefono": "+34667478856", "mensaje": "🔐 *Código de verificación — Mi Negocio*\\n\\nTu código para canjear puntos por *303 puntos* es:\\n\\n*952866*\\n\\n⏰ Válido 10 minutos. No lo compartas."}	sent	1	3	\N	\N	\N	30	2026-07-13 23:21:22.936549	2026-07-13 23:21:25.615321
3	whatsapp	order_state	+622663874	{"telefono": "+622663874", "mensaje": "✅ *¡Tu pedido está listo!*\\nEl pedido *#1001* está perfectamente preparado y en breve sale hacia ti. 📦", "numero_pedido": "#1001", "estado": "listo"}	sent	1	3	\N	\N	1	2	2026-07-12 11:18:07.840687	2026-07-12 11:18:08.802924
4	whatsapp	order_state	+622663874	{"telefono": "+622663874", "mensaje": "🚀 *¡En camino!*\\nTu pedido *#1001* ya va hacia ti.\\n\\nCuando el repartidor llegue te enviará el código de entrega. No compartas ningún código antes de recibir tu pedido. 🛵", "numero_pedido": "#1001", "estado": "en_ruta"}	sent	1	3	\N	\N	1	2	2026-07-12 11:25:39.869831	2026-07-12 11:25:41.792364
22	whatsapp	order_state	+34667478856	{"telefono": "+34667478856", "mensaje": "🎉 *¡Pedido recibido!*\\nTu pedido *#1007* ya está registrado. Total: *€203.00*.\\n\\n⏳ Todavía no ha comenzado la preparación. Te avisaremos cuando el equipo empiece.\\n\\nDesde aquí mismo puedes:\\n• Escribir *ESTADO* para ver cómo va.\\n• Escribir *CANCELAR* (solo antes de empezar a prepararlo).\\n• Escribir *AGENTE* si necesitas hablar con una persona.\\n\\nPuedes seguir consultando el estado por este mismo chat.\\n\\n🔐 *Un paso más para preparar tu pedido:*\\nResponde *SI* para confirmarlo y empezar a prepararlo, o *NO* para anularlo.", "numero_pedido": "#1007", "estado": "pendiente"}	sent	1	3	\N	\N	7	30	2026-07-13 23:21:38.663062	2026-07-13 23:21:40.507658
5	whatsapp	delivery_code	+622663874	{"telefono": "+622663874", "mensaje": "🔐 *Código de entrega para tu pedido #1001: 182209*\\n\\nCompártelo únicamente con el repartidor cuando estés recibiendo tu pedido. Si elegiste Bizum, confirma primero el pago del importe exacto.", "numero_pedido": "#1001", "estado": "en_ruta"}	sent	1	3	\N	\N	1	2	2026-07-12 11:26:03.778213	2026-07-12 11:26:04.44718
6	whatsapp	order_state	+622663874	{"telefono": "+622663874", "mensaje": "🎊 *¡Pedido entregado!*\\n¡Esperamos que te haya encantado! 😍\\nGanaste *103 puntos* 🌟 — van sumando para tu próximo descuento.\\n¡Gracias por elegirnos! 💛", "numero_pedido": "#1001", "estado": "entregado"}	sent	1	3	\N	\N	1	2	2026-07-12 11:26:23.708293	2026-07-12 11:26:25.134251
23	whatsapp	order_state	+34667478856	{"telefono": "+34667478856", "mensaje": "🔥 *¡Manos a la obra!*\\nTu pedido *#1007* está en preparación en este momento.\\nEn breve te avisamos cuando esté listo. ✨", "numero_pedido": "#1007", "estado": "armando"}	sent	1	3	\N	\N	7	30	2026-07-13 23:24:44.978825	2026-07-13 23:24:46.317704
7	whatsapp	review_request	+622663874	{"telefono": "+622663874", "mensaje": "⭐ *¿Cómo estuvo tu pedido #1001?*\\n\\nResponde con una calificación del 1 al 5 y, si quieres, un comentario.\\nTu opinión nos ayuda a mejorar."}	sent	1	3	\N	\N	1	2	2026-07-12 11:26:23.708304	2026-07-12 11:27:56.182071
26	push	web_push	1	{"subscription_id": 1, "payload": {"title": "🍳 Preparando tu pedido", "body": "##1003 está siendo preparado.", "url": "/", "icon": "/static/pwa-icon-192.png", "badge": "/static/favicon-32.png", "timestamp": 1783985262112}}	failed	3	3	2026-07-13 23:41:47.082983	Could not deserialize key data. The data may be in an incorrect format, it may be encrypted with an unsupported algorithm, or it may be an unsupported key type (e.g. EC curves with explicit parameters). Details: ASN.1 parsing error: invalid length	\N	2	2026-07-13 23:27:42.113167	\N
24	whatsapp	order_state	+34667478856	{"telefono": "+34667478856", "mensaje": "✅ *¡Tu pedido está listo!*\\nEl pedido *#1007* está perfectamente preparado y en breve sale hacia ti. 📦", "numero_pedido": "#1007", "estado": "listo"}	sent	1	3	\N	\N	7	30	2026-07-13 23:25:05.438788	2026-07-13 23:25:07.307739
25	whatsapp	order_state	+622663874	{"telefono": "+622663874", "mensaje": "🔥 *¡Manos a la obra!*\\nTu pedido *#1003* está en preparación en este momento.\\nEn breve te avisamos cuando esté listo. ✨", "numero_pedido": "#1003", "estado": "armando"}	sent	1	3	\N	\N	3	2	2026-07-13 23:27:42.089852	2026-07-13 23:27:42.921609
8	whatsapp	order_state	+622663874	{"telefono": "+622663874", "mensaje": "🎉 *¡Pedido recibido!*\\nTu pedido *#1002* ya está registrado. Total: *€103.00*.\\n\\nDesde aquí mismo puedes:\\n• Escribir *ESTADO* para ver cómo va.\\n• Escribir *CANCELAR* (solo antes de empezar a prepararlo).\\n• Escribir *AGENTE* si necesitas hablar con una persona.\\n\\n¡Estamos en ello ahora mismo! 🔥\\n\\n🔐 *Un paso más para preparar tu pedido:*\\nResponde *SI* para confirmarlo y empezar a prepararlo, o *NO* para anularlo.", "numero_pedido": "#1002", "estado": "pendiente"}	sent	1	3	\N	\N	2	2	2026-07-13 07:04:05.78447	2026-07-13 07:04:08.303043
9	whatsapp	points_otp	+622663874	{"telefono": "+622663874", "mensaje": "🔐 *Código de verificación — Mi Negocio*\\n\\nTu código para canjear puntos por *103 puntos* es:\\n\\n*060527*\\n\\n⏰ Válido 10 minutos. No lo compartas."}	sent	1	3	\N	\N	\N	2	2026-07-13 09:25:23.108033	2026-07-13 09:25:24.581449
10	whatsapp	order_state	+622663874	{"telefono": "+622663874", "mensaje": "🎉 *¡Pedido recibido!*\\nTu pedido *#1003* ya está registrado. Total: *€103.00*.\\n\\nDesde aquí mismo puedes:\\n• Escribir *ESTADO* para ver cómo va.\\n• Escribir *CANCELAR* (solo antes de empezar a prepararlo).\\n• Escribir *AGENTE* si necesitas hablar con una persona.\\n\\n¡Estamos en ello ahora mismo! 🔥", "numero_pedido": "#1003", "estado": "pendiente"}	sent	1	3	\N	\N	3	2	2026-07-13 09:26:11.015579	2026-07-13 09:26:13.4744
11	whatsapp	order_state	+622663874	{"telefono": "+622663874", "mensaje": "🎉 *¡Pedido recibido!*\\nTu pedido *#1004* ya está registrado. Total: *€103.00*.\\n\\nDesde aquí mismo puedes:\\n• Escribir *ESTADO* para ver cómo va.\\n• Escribir *CANCELAR* (solo antes de empezar a prepararlo).\\n• Escribir *AGENTE* si necesitas hablar con una persona.\\n\\n¡Estamos en ello ahora mismo! 🔥", "numero_pedido": "#1004", "estado": "pendiente"}	sent	1	3	\N	\N	4	2	2026-07-13 10:52:51.239486	2026-07-13 10:52:53.74516
34	whatsapp	order_state	+34622663874	{"telefono": "+34622663874", "mensaje": "🎉 *¡Pedido recibido!*\\nTu pedido *#1008* ya está registrado. Total: *€103.00*.\\n\\n⏳ Todavía no ha comenzado la preparación. Te avisaremos cuando el equipo empiece.\\n\\nDesde aquí mismo puedes:\\n• Escribir *ESTADO* para ver cómo va.\\n• Escribir *CANCELAR* (solo antes de empezar a prepararlo).\\n• Escribir *AGENTE* si necesitas hablar con una persona.\\n\\nPuedes seguir consultando el estado por este mismo chat.", "numero_pedido": "#1008", "estado": "pendiente"}	sent	1	3	\N	\N	8	2	2026-07-14 10:38:25.341586	2026-07-14 10:38:26.760214
36	push	web_push	4	{"subscription_id": 4, "payload": {"title": "🔔 Nuevo pedido Web", "body": "##1008 · €103.00 · Efectivo", "url": "/admin/pedidos", "icon": "/static/pwa-icon-192.png", "badge": "/static/favicon-32.png", "timestamp": 1784025505351}}	failed	3	3	2026-07-14 10:52:29.387155	Could not deserialize key data. The data may be in an incorrect format, it may be encrypted with an unsupported algorithm, or it may be an unsupported key type (e.g. EC curves with explicit parameters). Details: ASN.1 parsing error: invalid length	\N	2	2026-07-14 10:38:25.352227	\N
37	push	web_push	3	{"subscription_id": 3, "payload": {"title": "🔔 Nuevo pedido Web", "body": "##1008 · €103.00 · Efectivo", "url": "/admin/pedidos", "icon": "/static/pwa-icon-192.png", "badge": "/static/favicon-32.png", "timestamp": 1784025505351}}	failed	3	3	2026-07-14 10:52:29.390119	Could not deserialize key data. The data may be in an incorrect format, it may be encrypted with an unsupported algorithm, or it may be an unsupported key type (e.g. EC curves with explicit parameters). Details: ASN.1 parsing error: invalid length	\N	2	2026-07-14 10:38:25.352229	\N
\.


--
-- Data for Name: order_events; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.order_events (id, pedido_id, tipo, estado_anterior, estado_nuevo, actor_id, canal, detalle, metadata_json, creado_en) FROM stdin;
1	1	pedido_creado	\N	pendiente	4	web	checkout web	{"zona_id": 1, "tipo_entrega_cliente": "delivery"}	2026-07-12 11:12:12.647468
2	1	estado_cambiado	pendiente	armando	3	preparador	\N	\N	2026-07-12 11:17:24.238123
3	1	estado_cambiado	armando	listo	3	preparador	\N	\N	2026-07-12 11:18:07.834243
4	1	estado_cambiado	listo	en_ruta	5	repartidor	\N	\N	2026-07-12 11:25:39.856534
5	1	codigo_entrega_enviado	en_ruta	en_ruta	5	repartidor	Código de entrega enviado al cliente	\N	2026-07-12 11:26:03.783713
6	1	estado_cambiado	en_ruta	entregado	5	repartidor	\N	\N	2026-07-12 11:26:23.648061
7	1	pago_confirmado	entregado	entregado	5	repartidor	efectivo	{"metodo_pago": "efectivo", "total": 103.0, "pago_confirmado_en": "2026-07-12 11:26:23.636391"}	2026-07-12 11:26:23.648094
8	2	pedido_creado	\N	pendiente	4	web	checkout web	{"zona_id": 1, "tipo_entrega_cliente": "delivery"}	2026-07-13 07:04:05.759824
10	3	pedido_creado	\N	pendiente	4	web	checkout web	{"zona_id": 1, "tipo_entrega_cliente": "delivery"}	2026-07-13 09:26:10.989153
11	4	pedido_creado	\N	pendiente	4	web	checkout web	{"zona_id": 1, "tipo_entrega_cliente": "delivery"}	2026-07-13 10:52:51.218513
12	5	pedido_creado	\N	pendiente	30	web	checkout web	{"zona_id": 1, "tipo_entrega_cliente": "delivery"}	2026-07-13 23:07:21.112525
13	5	responsable_reasignado	pendiente	pendiente	2	admin_pedidos	preparador_id: sin asignar -> 3	{"campo": "preparador_id", "responsable_anterior_id": null, "responsable_nuevo_id": 3}	2026-07-13 23:08:44.804207
14	5	estado_cambiado	pendiente	armando	3	preparador	\N	\N	2026-07-13 23:09:09.334379
15	5	estado_cambiado	armando	listo	3	preparador	\N	\N	2026-07-13 23:09:23.66796
16	5	estado_cambiado	listo	en_ruta	3	repartidor	\N	\N	2026-07-13 23:11:15.005749
17	5	codigo_entrega_enviado	en_ruta	en_ruta	3	repartidor	Código de entrega enviado al cliente	\N	2026-07-13 23:12:15.885186
18	5	estado_cambiado	en_ruta	entregado	3	repartidor	\N	\N	2026-07-13 23:12:33.297219
19	5	pago_confirmado	entregado	entregado	3	repartidor	efectivo	{"metodo_pago": "efectivo", "total": 103.0, "pago_confirmado_en": "2026-07-13 23:12:33.288734"}	2026-07-13 23:12:33.297237
20	6	pedido_creado	\N	pendiente	31	web	checkout web	{"zona_id": 1, "tipo_entrega_cliente": "delivery"}	2026-07-13 23:20:03.229231
21	7	pedido_creado	\N	pendiente	30	web	checkout web	{"zona_id": 1, "tipo_entrega_cliente": "delivery"}	2026-07-13 23:21:38.642601
22	7	estado_cambiado	pendiente	armando	3	preparador	\N	\N	2026-07-13 23:24:44.976922
23	7	estado_cambiado	armando	listo	3	preparador	\N	\N	2026-07-13 23:25:05.417412
24	3	estado_cambiado	pendiente	armando	3	preparador	\N	\N	2026-07-13 23:27:42.082125
25	4	pedido_cancelado	pendiente	cancelado	\N	chatbot	cancelación solicitada por el cliente en WhatsApp	\N	2026-07-14 00:56:41.560711
26	2	pedido_cancelado	pendiente	cancelado	\N	chatbot	cancelación solicitada por el cliente en WhatsApp	\N	2026-07-14 00:57:43.737763
27	6	pedido_cancelado	pendiente	cancelado	\N	antifraude	auto-cancelado por verificación pasiva expirada (HIGH, TTL 120min sin respuesta)	\N	2026-07-14 01:25:21.259411
28	3	pedido_cancelado	armando	cancelado	2	admin	cancelacion admin	\N	2026-07-14 05:34:50.655793
29	7	estado_cambiado	listo	en_ruta	2	admin	\N	\N	2026-07-14 05:35:08.398869
30	8	pedido_creado	\N	pendiente	2	web	checkout web	{"zona_id": 1, "tipo_entrega_cliente": "delivery"}	2026-07-14 10:38:25.320938
31	8	pedido_cancelado	pendiente	cancelado	\N	chatbot	cancelación solicitada por el cliente en WhatsApp	\N	2026-07-14 10:41:24.262111
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.order_items (id, pedido_id, producto_id, cantidad, precio_unit, subtotal, notas, metadata_json) FROM stdin;
1	1	1	1	100.00	100.00	\N	{"producto": {"id": 1, "nombre": "Santiago a la naranja", "descripcion": "El plato más homosexual", "precio": 100.0, "precio_final": 100.0, "precio_costo": null, "categoria_id": 1, "categoria_nombre": "Test", "imagen_url": "productos/prod_1be9cdcb37ef.jpg", "origen_pais": "Carolingia", "es_combo": false, "combo_precio_modo": null, "combo_descuento_pct": 0, "combo_precio_base": 0, "tipo_producto": "simple", "tipo_entrega": "inmediato", "modalidad_entrega": "delivery", "grupo_pedido": null, "fecha_llegada": null, "dias_anticipacion_encargo": 1, "canal_preparacion": "cocina", "origen_operativo_key": "propio", "origen_operativo": "propio", "proveedor_id": null, "proveedor_despachador_id": null, "proveedor_despachador_nombre": null, "proveedor_despachador_direccion": null, "proveedor_despachador_telefono": null, "proveedor_despachador_modelo": null, "proveedor_despachador_comision": null, "proveedor_snapshot": null, "proveedor_despachador": null, "proveedor_modelo_acuerdo": null, "proveedor_comision_pct": null, "iva_pct": 10.0, "stock_mostrar_en_web": true, "canjeable_con_puntos": false, "puntos_para_canje": 0, "es_hipoalergenico": true, "alergenos_json": null, "atributos": {}}}
2	2	1	1	100.00	100.00	\N	{"producto": {"id": 1, "nombre": "Santiago a la naranja", "descripcion": "El plato más homosexual", "precio": 100.0, "precio_final": 100.0, "precio_costo": null, "categoria_id": 1, "categoria_nombre": "Test", "imagen_url": "productos/prod_1be9cdcb37ef.jpg", "origen_pais": "Carolingia", "es_combo": false, "combo_precio_modo": null, "combo_descuento_pct": 0, "combo_precio_base": 0, "tipo_producto": "simple", "tipo_entrega": "inmediato", "modalidad_entrega": "delivery", "grupo_pedido": null, "fecha_llegada": null, "dias_anticipacion_encargo": 1, "canal_preparacion": "cocina", "origen_operativo_key": "propio", "origen_operativo": "propio", "proveedor_id": null, "proveedor_despachador_id": null, "proveedor_despachador_nombre": null, "proveedor_despachador_direccion": null, "proveedor_despachador_telefono": null, "proveedor_despachador_modelo": null, "proveedor_despachador_comision": null, "proveedor_snapshot": null, "proveedor_despachador": null, "proveedor_modelo_acuerdo": null, "proveedor_comision_pct": null, "iva_pct": 10.0, "stock_mostrar_en_web": true, "canjeable_con_puntos": false, "puntos_para_canje": 0, "es_hipoalergenico": true, "alergenos_json": null, "atributos": {}}}
3	3	1	1	100.00	100.00	\N	{"producto": {"id": 1, "nombre": "Santiago a la naranja", "descripcion": "El plato más homosexual", "precio": 100.0, "precio_final": 100.0, "precio_costo": null, "categoria_id": 1, "categoria_nombre": "Test", "imagen_url": "productos/prod_1be9cdcb37ef.jpg", "origen_pais": "Carolingia", "es_combo": false, "combo_precio_modo": null, "combo_descuento_pct": 0, "combo_precio_base": 0, "tipo_producto": "simple", "tipo_entrega": "inmediato", "modalidad_entrega": "delivery", "grupo_pedido": null, "fecha_llegada": null, "dias_anticipacion_encargo": 1, "canal_preparacion": "cocina", "origen_operativo_key": "propio", "origen_operativo": "propio", "proveedor_id": null, "proveedor_despachador_id": null, "proveedor_despachador_nombre": null, "proveedor_despachador_direccion": null, "proveedor_despachador_telefono": null, "proveedor_despachador_modelo": null, "proveedor_despachador_comision": null, "proveedor_snapshot": null, "proveedor_despachador": null, "proveedor_modelo_acuerdo": null, "proveedor_comision_pct": null, "iva_pct": 10.0, "stock_mostrar_en_web": true, "canjeable_con_puntos": false, "puntos_para_canje": 0, "es_hipoalergenico": true, "alergenos_json": null, "atributos": {}}}
4	4	1	1	100.00	100.00	\N	{"producto": {"id": 1, "nombre": "Santiago a la naranja", "descripcion": "El plato más homosexual", "precio": 100.0, "precio_final": 100.0, "precio_costo": null, "categoria_id": 1, "categoria_nombre": "Test", "imagen_url": "productos/prod_1be9cdcb37ef.jpg", "origen_pais": "Carolingia", "es_combo": false, "combo_precio_modo": null, "combo_descuento_pct": 0, "combo_precio_base": 0, "tipo_producto": "simple", "tipo_entrega": "inmediato", "modalidad_entrega": "delivery", "grupo_pedido": null, "fecha_llegada": null, "dias_anticipacion_encargo": 1, "canal_preparacion": "cocina", "origen_operativo_key": "propio", "origen_operativo": "propio", "proveedor_id": null, "proveedor_despachador_id": null, "proveedor_despachador_nombre": null, "proveedor_despachador_direccion": null, "proveedor_despachador_telefono": null, "proveedor_despachador_modelo": null, "proveedor_despachador_comision": null, "proveedor_snapshot": null, "proveedor_despachador": null, "proveedor_modelo_acuerdo": null, "proveedor_comision_pct": null, "iva_pct": 10.0, "stock_mostrar_en_web": true, "canjeable_con_puntos": false, "puntos_para_canje": 0, "es_hipoalergenico": true, "alergenos_json": null, "atributos": {}}}
5	5	1	1	100.00	100.00	\N	{"producto": {"id": 1, "nombre": "Santiago a la naranja", "descripcion": "El plato más homosexual", "precio": 100.0, "precio_final": 100.0, "precio_costo": null, "categoria_id": 1, "categoria_nombre": "Test", "imagen_url": "productos/prod_1be9cdcb37ef.jpg", "origen_pais": "Carolingia", "es_combo": false, "combo_precio_modo": null, "combo_descuento_pct": 0, "combo_precio_base": 0, "tipo_producto": "simple", "tipo_entrega": "inmediato", "modalidad_entrega": "delivery", "grupo_pedido": null, "fecha_llegada": null, "dias_anticipacion_encargo": 1, "canal_preparacion": "cocina", "origen_operativo_key": "propio", "origen_operativo": "propio", "proveedor_id": null, "proveedor_despachador_id": null, "proveedor_despachador_nombre": null, "proveedor_despachador_direccion": null, "proveedor_despachador_telefono": null, "proveedor_despachador_modelo": null, "proveedor_despachador_comision": null, "proveedor_snapshot": null, "proveedor_despachador": null, "proveedor_modelo_acuerdo": null, "proveedor_comision_pct": null, "iva_pct": 10.0, "stock_mostrar_en_web": true, "canjeable_con_puntos": false, "puntos_para_canje": 0, "es_hipoalergenico": true, "alergenos_json": null, "atributos": {}}}
6	6	1	1	100.00	100.00	\N	{"producto": {"id": 1, "nombre": "Santiago a la naranja", "descripcion": "El plato más homosexual", "precio": 100.0, "precio_final": 100.0, "precio_costo": null, "categoria_id": 1, "categoria_nombre": "Test", "imagen_url": "productos/prod_1be9cdcb37ef.jpg", "origen_pais": "Carolingia", "es_combo": false, "combo_precio_modo": null, "combo_descuento_pct": 0, "combo_precio_base": 0, "tipo_producto": "simple", "tipo_entrega": "inmediato", "modalidad_entrega": "delivery", "grupo_pedido": null, "fecha_llegada": null, "dias_anticipacion_encargo": 1, "canal_preparacion": "cocina", "origen_operativo_key": "propio", "origen_operativo": "propio", "proveedor_id": null, "proveedor_despachador_id": null, "proveedor_despachador_nombre": null, "proveedor_despachador_direccion": null, "proveedor_despachador_telefono": null, "proveedor_despachador_modelo": null, "proveedor_despachador_comision": null, "proveedor_snapshot": null, "proveedor_despachador": null, "proveedor_modelo_acuerdo": null, "proveedor_comision_pct": null, "iva_pct": 10.0, "stock_mostrar_en_web": true, "canjeable_con_puntos": false, "puntos_para_canje": 0, "es_hipoalergenico": true, "alergenos_json": null, "atributos": {}}}
7	7	1	2	100.00	200.00	\N	{"producto": {"id": 1, "nombre": "Santiago a la naranja", "descripcion": "El plato más homosexual", "precio": 100.0, "precio_final": 100.0, "precio_costo": null, "categoria_id": 1, "categoria_nombre": "Test", "imagen_url": "productos/prod_1be9cdcb37ef.jpg", "origen_pais": "Carolingia", "es_combo": false, "combo_precio_modo": null, "combo_descuento_pct": 0, "combo_precio_base": 0, "tipo_producto": "simple", "tipo_entrega": "inmediato", "modalidad_entrega": "delivery", "grupo_pedido": null, "fecha_llegada": null, "dias_anticipacion_encargo": 1, "canal_preparacion": "cocina", "origen_operativo_key": "propio", "origen_operativo": "propio", "proveedor_id": null, "proveedor_despachador_id": null, "proveedor_despachador_nombre": null, "proveedor_despachador_direccion": null, "proveedor_despachador_telefono": null, "proveedor_despachador_modelo": null, "proveedor_despachador_comision": null, "proveedor_snapshot": null, "proveedor_despachador": null, "proveedor_modelo_acuerdo": null, "proveedor_comision_pct": null, "iva_pct": 10.0, "stock_mostrar_en_web": true, "canjeable_con_puntos": false, "puntos_para_canje": 0, "es_hipoalergenico": true, "alergenos_json": null, "atributos": {}}}
8	8	1	1	100.00	100.00	\N	{"producto": {"id": 1, "nombre": "Santiago a la naranja", "descripcion": "El plato más homosexual", "precio": 100.0, "precio_final": 100.0, "precio_costo": null, "categoria_id": 1, "categoria_nombre": "Test", "imagen_url": "productos/prod_1be9cdcb37ef.jpg", "origen_pais": "Carolingia", "es_combo": false, "combo_precio_modo": null, "combo_descuento_pct": 0, "combo_precio_base": 0, "tipo_producto": "simple", "tipo_entrega": "inmediato", "modalidad_entrega": "delivery", "grupo_pedido": null, "fecha_llegada": null, "dias_anticipacion_encargo": 1, "canal_preparacion": "cocina", "origen_operativo_key": "propio", "origen_operativo": "propio", "proveedor_id": null, "proveedor_despachador_id": null, "proveedor_despachador_nombre": null, "proveedor_despachador_direccion": null, "proveedor_despachador_telefono": null, "proveedor_despachador_modelo": null, "proveedor_despachador_comision": null, "proveedor_snapshot": null, "proveedor_despachador": null, "proveedor_modelo_acuerdo": null, "proveedor_comision_pct": null, "iva_pct": 10.0, "stock_mostrar_en_web": true, "canjeable_con_puntos": false, "puntos_para_canje": 0, "es_hipoalergenico": true, "alergenos_json": null, "atributos": {}}}
\.


--
-- Data for Name: order_provider_status; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.order_provider_status (id, pedido_id, preparado, preparado_en, actualizado_por, proveedor_id) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.orders (id, numero_pedido, cliente_id, estado, origen, subtotal, descuento, total, cupon_id, puntos_usados, puntos_ganados, metodo_pago, direccion_entrega, notas, preparador_id, repartidor_id, cajero_id, creado_en, entregado_en, zona_id, afiliado_codigo_id, es_entrega_epicentro, codigo_confirmacion, codigo_confirmado_en, intentos_codigo, pago_confirmado, pago_confirmado_por, pago_confirmado_en, whatsapp_enviado_confirmacion, resena_calificacion, resena_comentario, resena_enviada, tipo_entrega_cliente, service_commission_pct, service_commission_amount, merchant_net_amount, proveedor_preparado, proveedor_preparado_en, en_punto_encuentro, en_punto_encuentro_en, codigo_confirmacion_expira_en, iva_total, confirmacion_estado, confirmacion_en, confirmacion_nivel) FROM stdin;
6	#1006	31	cancelado	online	100.00	0.00	103.00	\N	0	103	efectivo	Calle torre del oro 32		3	\N	\N	2026-07-13 23:20:03.223484	\N	1	\N	t	\N	\N	0	f	\N	\N	f	\N	\N	f	delivery	0.00	0.00	103.00	f	\N	f	\N	\N	9.09	pending	\N	HIGH
3	#1003	2	cancelado	online	100.00	0.00	103.00	\N	0	103	efectivo	Calle Andalucia 20		\N	\N	\N	2026-07-13 09:26:10.980291	\N	1	\N	t	\N	\N	0	f	\N	\N	f	\N	\N	f	delivery	0.00	0.00	103.00	f	\N	f	\N	\N	9.09	\N	\N	\N
7	#1007	30	en_ruta	online	200.00	0.00	203.00	\N	0	203	efectivo	Calle Andalucía 20		3	\N	\N	2026-07-13 23:21:38.635669	\N	1	\N	t	386318	\N	0	f	\N	\N	f	\N	\N	f	delivery	0.00	0.00	203.00	f	\N	f	\N	2026-07-15 05:35:08.37606	18.18	confirmed	2026-07-13 23:22:00.507975	MEDIUM
8	#1008	2	cancelado	online	100.00	0.00	103.00	\N	0	103	efectivo	Calle Andalucía 20		\N	\N	\N	2026-07-14 10:38:25.309116	\N	1	\N	t	\N	\N	0	f	\N	\N	f	\N	\N	f	delivery	0.00	0.00	103.00	f	\N	f	\N	\N	9.09	\N	\N	\N
1	#1001	2	entregado	online	100.00	0.00	103.00	\N	0	103	efectivo	Calle Andalucia 20		3	5	\N	2026-07-12 11:12:12.644508	2026-07-12 11:26:23.636057	1	\N	t	\N	2026-07-12 11:26:23.635958	0	t	5	2026-07-12 11:26:23.636391	f	\N	\N	t	delivery	0.00	0.00	103.00	f	\N	f	\N	\N	9.09	\N	\N	\N
5	#1005	30	entregado	online	100.00	0.00	103.00	\N	0	103	efectivo	Calle Andalucía 20		3	3	\N	2026-07-13 23:07:21.106403	2026-07-13 23:12:33.288358	1	\N	t	\N	2026-07-13 23:12:33.288253	0	t	3	2026-07-13 23:12:33.288734	f	\N	\N	t	delivery	0.00	0.00	103.00	f	\N	f	\N	\N	9.09	confirmed	2026-07-13 23:07:53.232998	HIGH
4	#1004	2	cancelado	online	100.00	0.00	103.00	\N	0	103	efectivo	Calle Andalucía 20		\N	\N	\N	2026-07-13 10:52:51.213213	\N	1	\N	t	\N	\N	0	f	\N	\N	f	\N	\N	f	delivery	0.00	0.00	103.00	f	\N	f	\N	\N	9.09	\N	\N	\N
2	#1002	2	cancelado	online	100.00	0.00	103.00	\N	0	103	efectivo	andalucia 20		\N	\N	\N	2026-07-13 07:04:05.752265	\N	1	\N	t	\N	\N	0	f	\N	\N	f	\N	\N	f	delivery	0.00	0.00	103.00	f	\N	f	\N	\N	9.09	pending	\N	MEDIUM
\.


--
-- Data for Name: points_log; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.points_log (id, cliente_id, pedido_id, tipo, cantidad, descripcion, creado_en) FROM stdin;
2	30	5	ganado	103	Pedido #1005 entregado	2026-07-13 23:12:33.338133
3	30	\N	ajuste	200	Ajuste por WhatsApp admin 34622663874	2026-07-13 23:20:13.925733
1	2	1	ganado	103	Pedido #1001 entregado	2026-07-12 11:26:23.71227
\.


--
-- Data for Name: price_history; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.price_history (id, producto_id, precio_anterior, precio_nuevo, cambiado_por, cambiado_en, motivo) FROM stdin;
\.


--
-- Data for Name: product_extra_groups; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.product_extra_groups (id, producto_id, nombre, descripcion, min_selecciones, max_selecciones, orden, activo) FROM stdin;
\.


--
-- Data for Name: product_extra_options; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.product_extra_options (id, grupo_id, nombre, precio, max_cantidad, orden, activo, catalog_item_id) FROM stdin;
\.


--
-- Data for Name: product_extras; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.product_extras (id, producto_id, nombre, precio, activo, orden, creado_en) FROM stdin;
\.


--
-- Data for Name: product_presentations; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.product_presentations (id, producto_id, "tamaño", precio_extra, activo, orden) FROM stdin;
\.


--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.product_variants (id, product_id, sku, talla, color, color_hex, precio_override, stock, activo, orden, imagen_url) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.products (id, nombre, descripcion, precio, precio_costo, categoria_id, imagen_url, origen_pais, es_combo, combo_precio_modo, combo_descuento_pct, combo_precio_base, tipo_producto, atributos_json, activo, creado_en, canal_preparacion, tipo_entrega, fecha_llegada, dias_anticipacion_encargo, hora_inicio_visibilidad, hora_fin_visibilidad, dias_semana_json, stock_mostrar_en_web, canjeable_con_puntos, puntos_para_canje, es_hipoalergenico, alergenos_info, alergenos_json, modalidad_entrega, proveedor_id, proveedor_despachador_id, metodo_entrega_permitido, grupo_pedido, solo_canje, vertical, iva_pct, marca, material, dimensiones, peso_gramos, garantia_meses) FROM stdin;
1	Santiago a la naranja	El plato más homosexual	100.00	\N	1	productos/prod_1be9cdcb37ef.jpg	Carolingia	f	fijo	0.00	0.00	simple	\N	t	2026-07-12 11:04:51.045918	cocina	inmediato	\N	1	\N	\N	[0, 1, 2, 3, 4, 5, 6]	t	f	\N	t	\N	\N	delivery	\N	\N	ambas	\N	f	comida	\N	\N	\N	\N	\N	\N
2	Fff		0.00	\N	\N	\N		f	fijo	0.00	0.00	simple	\N	t	2026-07-13 23:16:07.051283	cocina	inmediato	\N	1	\N	\N	\N	f	t	200	f	\N	\N	delivery	\N	\N	ambas	\N	t	comida	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: proveedor_productos; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.proveedor_productos (id, proveedor_id, producto_id, stock, precio_costo, activo, actualizado_en) FROM stdin;
\.


--
-- Data for Name: proveedores; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.proveedores (id, nombre, razon_social, direccion, telefono, email, horario, hora_apertura, hora_cierre, modelo_acuerdo, comision_pct, iban, notas, activo, branding_logo_url, branding_color_primario, branding_color_secundario, branding_color_acento, branding_slogan, tienda_abierta_override, tienda_mensaje_cierre, creado_en) FROM stdin;
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.push_subscriptions (id, user_id, endpoint, p256dh, auth, rol, user_agent, creado_en, ultimo_uso, activo) FROM stdin;
2	31	https://web.push.apple.com/QAgRiN7h5xo15ZBciz8gZv-f2BX6balyNz8M3BvffJXOEnsZlI7L7Wl927NwgDsbXuRj3bbqpGbxeGgSaJXf9Rw6AIP2KqGaWnC7b_vgYoNQVUVwrPHCGemlCJ_aB5kZI9trBQYH37K_IuuQZa50WIc21ow8ygsKVxbF9tEVexk	BIGu3SF8Tk1iRZZf-f0Cj20Du2TI4MdUXnVEWQpazQkkK5HvAqVmnFLRJEyr95RtEmpffPG55ZTov88BGTJtySg	GKQrjemDdMLQWGCemwjqtA	cliente	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5.2 Mobile/15E148 Safari/604.1	2026-07-13 23:20:14.399104	2026-07-13 23:20:14.399108	t
1	2	https://fcm.googleapis.com/fcm/send/dvr4hQ9AJ1w:APA91bEAM9e4JQFaoudvmILYp_8Cex0cb44DB94Chsw_ajB4VJVK1dc1lXoMH4-Oa-7D9LYSZW7hL8rjrSuCNYGhc4UO_HuXb7fSu3x564Bt0cbFovvPrkoKiPec678C-UOUyMJIhYQ0	BGryoq6skYlVv4WksfOdS0R4kh6H92W5jITB3buPUvNgwqqm9GBFPRU2QNM8MZCMkWIzr3TZhm17mTpTayWdRUM	Le77xNhdSokZAUX6PSs69Q	cliente	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36	2026-07-13 10:53:07.263657	2026-07-13 10:53:07.263664	t
4	2	https://web.push.apple.com/QCrB6bOfFovELa4_K5TUU1xGrqOTIMow4-WfzgnTLXT4DNuwDnW4rVQzh-Mx43Jum4rtR6BCrpKv9qyddRdPh3Udtztx5fVfMrFir-dWzZca2r64eqgDzuPQOp_5sw2i-IbeBcA7Sl11LHPn6ZwZO6ajga6Tw97009zZJkFBiSA	BEMNd2TRJ13V3TsbblWRnhN_MiZT3bB1g5VcCZ0kXD25KlG2hS6SXs0V5_tRuanOa1kg4CCQNGX_Ei8a_ROpz2Q	zpnmJKGPNNdT0LhDinZL8Q	super_admin	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5.2 Mobile/15E148 Safari/604.1	2026-07-14 08:14:10.18423	2026-07-14 08:14:11.305798	t
3	2	https://web.push.apple.com/QAQYw4J2b6JWEcUm0Ry0vwXhlCXXmS1C-NO_dW-WoHJHdSQ--0WKOlrZa6QCCyHjNll5yL_VbQCghcLE5UtyQaFAM1U9Gb3fx_J9FiHBXu-w6egV6UMrJhKoT05zwQ1vWZX76pECO_Ukt4fVY2aLKIcOToPblIecl19UlG1de3M	BFOyxd5F7EyQ2xLcZhKFL-swsxLM1OW3JaX0QOL9D9IWEIXgtsIGmgZcVGruun2QFmmFvFOa7SesRtgzf4pSxOw	L2airEH89jPWf9OHKU1iaQ	super_admin	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5.2 Mobile/15E148 Safari/604.1	2026-07-14 01:10:28.905445	2026-07-14 07:19:54.69268	t
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.reviews (id, producto_id, cliente_id, pedido_id, calificacion, comentario, aprobada, creado_en) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.schema_migrations (id, description, applied_at) FROM stdin;
20260526_01_order_events_notification_outbox	Crear order_events y notification_outbox	2026-06-24 21:40:39.797117
20260526_02_site_config_valor_text	Ampliar site_config.valor a TEXT para claves e integraciones largas	2026-06-24 21:40:39.825715
20260602_01_products_combo_pricing	Agregar modo de precio y descuento porcentual para combos	2026-06-24 21:40:39.970127
20260605_01_combo_groups_structure	Crear secciones formales de combo y enlazarlas a componentes	2026-06-24 21:40:40.008614
20260605_02_combo_groups_backfill	Poblar secciones formales para combos existentes sin grupos	2026-06-24 21:40:40.031623
20260605_03_empty_combo_base_group	Crear seccion inicial para combos sin componentes	2026-06-24 21:40:40.05712
20260605_04_combo_item_option_fields	Agregar suplementos, default, activo y notas operativas a opciones de combo	2026-06-24 21:40:40.080565
20260608_01_remove_legacy_promotions	Retirar tabla y columnas del motor de promociones obsoleto	2026-06-24 21:40:40.12293
20260609_01_unique_customer_phone	Normalizar y hacer único el teléfono usado como identidad del cliente	2026-06-24 21:40:40.215166
20260612_01_provider_kitchen_flow	Agregar canal, proveedor y preparación independiente por proveedor	2026-06-24 21:40:40.251391
20260613_02_financial_uniqueness	Impedir comisiones, ingresos, pagos staff y puntos duplicados	2026-06-24 21:40:40.315227
20260615_01_affiliate_payment_integrity	Separar comisiones, enlazar usos de afiliado e impedir devoluciones duplicadas	2026-06-24 21:40:40.474358
20260616_01_proveedor_entity	Convertir 'proveedor' en entidad restaurante: tablas proveedores y proveedor_productos, FKs en users/products/order_provider_status	2026-06-24 21:40:40.564459
20260616_02_proveedor_modelo_acuerdo	Añadir proveedores.modelo_acuerdo (stock_proveedor | stock_propio_bar) para distinguir cómo se liquida a cada bar	2026-06-24 21:40:40.5975
20260617_01_user_mfa	Añadir columnas MFA (mfa_secret, mfa_enabled, mfa_session_version) a users	2026-06-24 21:40:40.629851
20260617_02_idempotency_keys	Crear tabla idempotency_keys para deduplicar creación de pedidos (checkout, POS, bot)	2026-06-24 21:40:40.656003
20260617_03_zonas_geo	Añadir centro_lat/centro_lng/radio_km a zonas_entrega para matching geográfico	2026-06-24 21:40:40.709199
20260618_01_proveedor_horario	Añadir hora_apertura/hora_cierre a proveedores para filtrar catálogo fuera de horario	2026-06-24 21:40:40.740056
20260624_07_role_proveedor_to_admin	Unificar rol 'proveedor' dentro de 'admin' (User.proveedor_id distingue operadores de bar)	2026-06-24 21:40:40.9395
20260627_01_hotpath_compound_indexes	Índices compuestos para consultas calientes	2026-06-29 13:31:05.21023
20260628_01_product_extras	Crear product_extras (ingredientes opcionales por producto/combo)	2026-06-29 13:31:05.261351
20260629_01_mfa_recovery_optout	Añadir mfa_recovery_codes_hash + whatsapp_opt_out a users	2026-06-29 13:34:16.221283
20260619_01_provider_operator_phones	Migrar el teléfono legacy del bar a su único operador inequívoco	2026-06-30 15:41:39.369053
20260620_01_master_catalog_location_inventory	Consolidar productos simples por catalog_key, mover stock por ubicación y proteger cantidades y comisiones con CHECK constraints	2026-06-30 15:42:14.542956
20260626_01_fulfillment_mode_and_staff_cleanup	Añadir tipo_entrega_cliente a pedidos y migrar rol staff legacy a preparacion	2026-06-30 15:43:36.549696
20260629_01_service_commission_snapshots	Congelar comisión white-label y neto del restaurante por pedido	2026-06-30 15:43:36.637493
20260630_01_product_extras	Crear grupos y opciones de extras configurables por producto	2026-06-30 15:43:36.678384
20260630_02_product_fulfillment_mode	Añadir modalidad delivery, recogida o ambas por producto	2026-06-30 15:43:36.721755
20260701_01_product_order_group	Añadir grupo configurable de compatibilidad por producto	2026-07-01 06:06:45.60459
20260701_02_reusable_extra_catalog	Crear biblioteca reutilizable de extras y vincularla a productos	2026-07-01 12:10:58.715668
20260702_01_product_solo_canje	Añadir Product.solo_canje (productos exclusivos de canje con puntos)	2026-07-02 08:22:01.056806
20260702_02_combo_item_activo_not_null	combo_items.activo → NOT NULL con default TRUE (NULLs se evaluaban como agotado)	2026-07-02 23:07:44.519023
20260702_03_order_en_punto_encuentro	Order.en_punto_encuentro + timestamp (subestado del reparto para el bot)	2026-07-02 23:07:44.556643
20260624_01_proveedor_branding_override	Añadir branding override y control de tienda por proveedor (modo cliente)	2026-07-04 00:54:23.612563
20260624_02_tenant_config	Crear tabla tenant_config (singleton) para modo propia/cliente, comision y delivery	2026-07-04 00:54:23.635655
20260624_03_tenant_config_seed	Insertar fila singleton de tenant_config con defaults seguros	2026-07-04 00:56:09.486958
20260624_04_hub_commissions	Crear hub_commissions (registro de comision por pedido en modo cliente)	2026-07-04 00:56:09.515265
20260624_05_product_metodo_entrega	Añadir Product.metodo_entrega_permitido (delivery|recogida|ambas)	2026-07-04 00:56:09.544806
20260624_06_tenant_suspension	Añadir suspension + ciclo_dias a tenant_config (control de impagos)	2026-07-04 00:56:09.580603
20260624_08_tenant_pickup_toggle	Añadir tenant_config.pickup_habilitado (módulo 'para llevar/recoger')	2026-07-04 00:56:09.607697
20260624_09_ai_assistant	Crear ai_assistant_config, ai_conversations, ai_usage_log (asistente IA del bot)	2026-07-04 00:56:09.639714
20260706_01_product_vertical	Product.vertical: separa catálogo por nicho (comida|producto|ambos)	2026-07-06 14:43:36.153786
20260707_01_product_extra_groups_current_schema	Alinear product_extra_groups legacy con columnas actuales de selección	2026-07-07 22:33:42.682792
20260710_01_order_codigo_confirmacion_expira	orders.codigo_confirmacion_expira_en (TTL configurable del código de entrega)	2026-07-10 14:54:23.284064
20260710_02_user_zona_repartidor	users.zona_repartidor_id (FK zonas_entrega) para restringir pedidos por zona asignada	2026-07-10 14:54:23.358266
20260710_03_product_iva_pct	Product.iva_pct (tasa IVA por producto — España, fallback por vertical)	2026-07-10 14:54:23.399475
20260710_04_order_iva_total	Order.iva_total (IVA congelado por pedido para exportación fiscal)	2026-07-10 14:54:23.444166
20260710_05_user_nif	User.nif (NIF/DNI/NIE/CIF opcional para facturas a empresa)	2026-07-10 14:54:23.491971
20260710_10_product_variants	product_variants: variantes retail (talla/color/precio_override/stock) por producto con vertical producto|ambos	2026-07-10 14:54:23.601518
20260710_21_combo_item_variant	combo_items.variant_id (FK product_variants ON DELETE SET NULL) para bundles retail que congelan talla/color por componente	2026-07-10 15:39:09.623497
20260710_30_product_retail_fields	Product: marca, material, dimensiones, peso_gramos, garantia_meses (nullable). Solo aplican si vertical='producto'.	2026-07-10 17:36:09.297057
20260710_31_backfill_vertical_ambos	Convierte Product.vertical='ambos' (legacy) al nicho activo actual para eliminar la contaminación cruzada entre comida y retail.	2026-07-10 17:36:09.412708
20260712_40_order_confirmacion_estado	Añade orders.confirmacion_estado y confirmacion_en para verificación pasiva anti-pedido-fantasma vía WhatsApp. NULL por defecto — no toca pedidos legacy ni cambia la máquina de estados operativa.	2026-07-12 22:45:57.006739
20260713_41_order_confirmacion_nivel	Añade orders.confirmacion_nivel (VARCHAR(10) nullable) para persistir MEDIUM/HIGH del scoring de riesgo antifraude. Permite desagregar métricas y aplicar políticas distintas por nivel.	2026-07-13 06:45:49.683277
\.


--
-- Data for Name: site_config; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.site_config (id, clave, valor, descripcion, actualizado_en, actualizado_por) FROM stdin;
11	HORARIO_CIERRE	22:00	\N	2026-07-11 08:14:08.82887	\N
12	PEDIDO_MINIMO	0.00	\N	2026-07-11 08:14:08.828876	\N
13	PUNTOS_POR_EURO	1	\N	2026-07-11 08:14:08.828881	\N
14	PUNTOS_RATIO	20	\N	2026-07-11 08:14:08.828887	\N
15	SERVICE_COMMISSION_PCT	0.00	\N	2026-07-11 08:14:08.828893	\N
16	PAGO_EFECTIVO_HABILITADO	1	\N	2026-07-11 08:14:08.828898	\N
17	PAGO_BIZUM_HABILITADO	1	\N	2026-07-11 08:14:08.828904	\N
18	AUTO_DESTACADOS_ENABLED	1	\N	2026-07-11 08:14:08.828909	\N
19	IA_ADMIN_LIMITE_HORA	30	\N	2026-07-11 08:14:08.828915	\N
21	CART_MAX_QTY	99	Cantidad máxima por producto en carrito	2026-07-11 08:29:44.362749	\N
22	COMBO_MIN_COMPONENTS	1	Mínimo de componentes requeridos para crear un combo	2026-07-11 08:29:44.364114	\N
23	COMBO_MAX_COMPONENTS	30	Máximo de componentes permitidos por combo	2026-07-11 08:29:44.365557	\N
24	COMBO_MAX_QTY_COMPONENT	50	Cantidad máxima por componente dentro de un combo	2026-07-11 08:29:44.366909	\N
25	COMBO_MAX_SELECTIONS_GROUP	10	Máximo de selecciones permitidas por grupo elegible	2026-07-11 08:29:44.368253	\N
26	COMBO_MAX_DISCOUNT_PCT	50	Descuento porcentual máximo permitido para combos	2026-07-11 08:29:44.369528	\N
27	ALERTA_CADUCIDAD_DIAS	7	Dias antes de caducidad para alerta	2026-07-11 08:29:44.370749	\N
28	SLOGAN_NEGOCIO		Eslogan del negocio	2026-07-11 08:29:44.372504	\N
29	DESCRIPCION_NEGOCIO		Descripción pública del negocio	2026-07-11 08:29:44.373953	\N
33	BOT_ALLOW_ORDER_CREATE	0	Permitir crear pedidos desde chatbot (1/0). Por defecto el bot solo consulta.	2026-07-11 08:29:44.38089	\N
39	BOT_EMAIL_DOMAIN	wa.internal	Dominio para emails auto-generados de clientes WhatsApp	2026-07-11 08:29:44.388862	\N
40	LOGO_URL		URL del logo del negocio	2026-07-11 08:29:44.390364	\N
41	APP_ICON_URL		Icono instalable de la PWA	2026-07-11 08:29:44.391673	\N
42	HERO_IMAGE_URL		Imagen principal del menú público	2026-07-11 08:29:44.39292	\N
49	PROVINCIA_NEGOCIO		Provincia del negocio (para geocodificación estructurada)	2026-07-11 08:29:44.402727	\N
50	PAIS_NEGOCIO		País del negocio	2026-07-11 08:29:44.403965	\N
51	PAIS_CODIGO_ISO		Código ISO del país	2026-07-11 08:29:44.405223	\N
52	EMAIL_CONTACTO		Correo público de contacto	2026-07-11 08:29:44.406485	\N
54	BIZUM_TELEFONO		Número que recibe Bizum	2026-07-11 08:29:44.408944	\N
55	BIZUM_HABILITADO	1	Permitir Bizum	2026-07-11 08:29:44.410206	\N
56	EFECTIVO_HABILITADO	1	Permitir efectivo	2026-07-11 08:29:44.411426	\N
62	COLOR_FONDO_APP	#F7F3EA	Token visual configurable de la tienda	2026-07-11 08:29:44.422666	\N
63	COLOR_SUPERFICIE	#FFFDF8	Token visual configurable de la tienda	2026-07-11 08:29:44.423894	\N
64	COLOR_SUPERFICIE_ALT	#F1EBDD	Token visual configurable de la tienda	2026-07-11 08:29:44.425149	\N
65	COLOR_TEXTO	#1B1A16	Token visual configurable de la tienda	2026-07-11 08:29:44.426385	\N
66	COLOR_TEXTO_SUAVE	#68635B	Token visual configurable de la tienda	2026-07-11 08:29:44.427716	\N
67	COLOR_CABECERA_FONDO	#171714	Token visual configurable de la tienda	2026-07-11 08:29:44.429015	\N
68	COLOR_CABECERA_TEXTO	#FFFFFF	Token visual configurable de la tienda	2026-07-11 08:29:44.430262	\N
69	COLOR_EXITO	#087A48	Token visual configurable de la tienda	2026-07-11 08:29:44.431515	\N
70	COLOR_ALERTA	#B42318	Token visual configurable de la tienda	2026-07-11 08:29:44.432771	\N
71	UI_CLOSE	Cerrar	Texto público configurable de la tienda	2026-07-11 08:29:44.433966	\N
72	UI_HEADER_MODE_BOTH	Delivery · Recogida	Texto público configurable de la tienda	2026-07-11 08:29:44.435256	\N
73	UI_HEADER_MODE_DELIVERY	Delivery	Texto público configurable de la tienda	2026-07-11 08:29:44.436441	\N
74	UI_HEADER_MODE_PICKUP	Recogida	Texto público configurable de la tienda	2026-07-11 08:29:44.437705	\N
75	UI_HEADER_OPEN	Abierto	Texto público configurable de la tienda	2026-07-11 08:29:44.43906	\N
76	UI_HEADER_CLOSED	Cerrado	Texto público configurable de la tienda	2026-07-11 08:29:44.440423	\N
77	UI_HEADER_INSTALL	Añadir app	Texto público configurable de la tienda	2026-07-11 08:29:44.441744	\N
78	UI_HEADER_CART_LABEL	Tu pedido	Texto público configurable de la tienda	2026-07-11 08:29:44.443044	\N
79	UI_HEADER_CART_ACTION	Ver carrito	Texto público configurable de la tienda	2026-07-11 08:29:44.444404	\N
80	UI_HEADER_STAFF	Empleados	Texto público configurable de la tienda	2026-07-11 08:29:44.445833	\N
81	UI_CART_EYEBROW	Revisa tu pedido	Texto público configurable de la tienda	2026-07-11 08:29:44.447189	\N
82	UI_CART_TITLE	Tu carrito	Texto público configurable de la tienda	2026-07-11 08:29:44.448443	\N
83	UI_CART_ITEM_ONE	producto	Texto público configurable de la tienda	2026-07-11 08:29:44.449697	\N
8	FEATURE_PEDIDOS_PROGRAMADOS	0	\N	2026-07-11 08:44:59.005482	2
4	MODO_TIENDA	propia	\N	2026-07-11 11:20:35.789688	2
5	TIPO_TIENDA	comida	\N	2026-07-12 11:06:15.707768	2
6	FEATURE_DELIVERY	1	\N	2026-07-11 08:44:52.379467	2
7	FEATURE_RECOGIDA	0	\N	2026-07-11 08:44:55.910396	2
47	TIENDA_FORZAR_CERRADA	0	Forzar tienda cerrada (1/0)	2026-07-14 08:19:42.168201	\N
20	PUNTOS_CANJE_RATIO	1000	100 puntos = 1 euro de descuento	2026-07-13 23:42:21.450625	2
9	FEATURE_PUNTOS	1	\N	2026-07-11 11:20:48.057666	2
1	NOMBRE_NEGOCIO	El Parcerito	\N	2026-07-14 07:28:25.940755	\N
43	TIENDA_URL	https://elparcerito.com	URL de la tienda web para pedidos (mostrado en WhatsApp)	2026-07-14 07:28:25.944235	\N
57	CENTRO_LAT	37.4736	Latitud del centro de reparto	2026-07-13 15:41:28.09754	\N
58	CENTRO_LON	-5.6438	Longitud del centro de reparto	2026-07-13 15:41:28.09754	\N
48	CIUDAD_NEGOCIO	Carmona	Ciudad del negocio (para geocodificación de direcciones)	2026-07-13 15:41:28.09754	\N
60	VALIDAR_RADIO_ENTREGA	1	Activar validación de radio de entrega (1/0)	2026-07-13 15:42:08.075954	2
61	BLOQUEAR_DIRECCION_NO_VERIFICADA	1	Bloquear pedido si no se puede geocodificar la dirección (1/0)	2026-07-13 15:42:08.075954	2
59	RADIO_ENTREGA_KM	3	Radio máximo de entrega en km desde el centro	2026-07-13 15:42:08.075954	2
10	HORARIO_APERTURA	00:00	\N	2026-07-13 23:04:20.446676	2
53	WHATSAPP_COUNTRY_CODE	34	Prefijo telefónico internacional	2026-07-13 23:56:42.86256	\N
44	COLOR_PRIMARIO	#FDC700	Color principal de marca	2026-07-14 15:40:53.511107	2
45	COLOR_SECUNDARIO	#DA5100	Color secundario de marca	2026-07-14 15:40:53.516181	2
46	COLOR_ACENTO	#E63B7A	Color de acento para estado y CTA	2026-07-14 15:40:53.520215	2
84	UI_CART_ITEM_MANY	productos	Texto público configurable de la tienda	2026-07-11 08:29:44.451019	\N
85	UI_CART_BACK	Volver	Texto público configurable de la tienda	2026-07-11 08:29:44.452558	\N
86	UI_CART_PROCESS	Proceso de compra	Texto público configurable de la tienda	2026-07-11 08:29:44.454017	\N
87	UI_CART_STEP_CART	Carrito	Texto público configurable de la tienda	2026-07-11 08:29:44.455247	\N
88	UI_CART_STEP_FULFILLMENT	Entrega	Texto público configurable de la tienda	2026-07-11 08:29:44.456497	\N
89	UI_CART_STEP_PAYMENT	Pago	Texto público configurable de la tienda	2026-07-11 08:29:44.457754	\N
90	UI_CART_UPDATE	Actualizar carrito	Texto público configurable de la tienda	2026-07-11 08:29:44.458999	\N
91	UI_CART_COMBO_BADGE	Combo	Texto público configurable de la tienda	2026-07-11 08:29:44.4603	\N
92	UI_CART_COMBO_VIEW	Ver combo	Texto público configurable de la tienda	2026-07-11 08:29:44.461549	\N
93	UI_CART_COMBO_ITEMS	ítems	Texto público configurable de la tienda	2026-07-11 08:29:44.462782	\N
94	UI_CART_COMBO_BASE	Base incluida	Texto público configurable de la tienda	2026-07-11 08:29:44.46401	\N
95	UI_CART_COMBO_INCLUDED	Incluido	Texto público configurable de la tienda	2026-07-11 08:29:44.465296	\N
96	UI_CART_COMBO_SELECTION	Tu elección	Texto público configurable de la tienda	2026-07-11 08:29:44.466703	\N
97	UI_CART_COMBO_KITCHEN	Contenido definido en cocina	Texto público configurable de la tienda	2026-07-11 08:29:44.46796	\N
98	UI_CART_EXTRAS_LABEL	Extras	Texto público configurable de la tienda	2026-07-11 08:29:44.46927	\N
99	UI_CART_ORDER_LABEL	Pedido	Texto público configurable de la tienda	2026-07-11 08:29:44.470549	\N
100	UI_CART_NO_ALLERGENS	Sin alérgenos	Texto público configurable de la tienda	2026-07-11 08:29:44.471838	\N
101	UI_CART_QUANTITY	Cantidad	Texto público configurable de la tienda	2026-07-11 08:29:44.473161	\N
102	UI_CART_LESS	Menos	Texto público configurable de la tienda	2026-07-11 08:29:44.474391	\N
103	UI_CART_MORE	Más	Texto público configurable de la tienda	2026-07-11 08:29:44.475714	\N
104	UI_CART_REMOVE	Eliminar	Texto público configurable de la tienda	2026-07-11 08:29:44.476951	\N
105	UI_CART_POINTS_TITLE	Puntos y recompensas	Texto público configurable de la tienda	2026-07-11 08:29:44.478226	\N
106	UI_CART_POINTS_PREFIX	Este pedido suma aprox.	Texto público configurable de la tienda	2026-07-11 08:29:44.47951	\N
107	UI_CART_POINTS_UNIT	puntos	Texto público configurable de la tienda	2026-07-11 08:29:44.480834	\N
108	UI_CART_POINTS_REMOVE_DISCOUNT	Quitar canje	Texto público configurable de la tienda	2026-07-11 08:29:44.482061	\N
109	UI_CART_POINTS_AVAILABLE	puntos disponibles	Texto público configurable de la tienda	2026-07-11 08:29:44.483286	\N
110	UI_CART_POINTS_READY	Tus puntos están listos. El canje se aplica al confirmar.	Texto público configurable de la tienda	2026-07-11 08:29:44.484541	\N
111	UI_CART_POINTS_CLEAR	Quitar puntos de la sesión	Texto público configurable de la tienda	2026-07-11 08:29:44.485784	\N
112	UI_CART_POINTS_VERIFY_HELP	¿Tienes puntos acumulados? Consulta y canjea con tu WhatsApp.	Texto público configurable de la tienda	2026-07-11 08:29:44.487001	\N
113	UI_CART_POINTS_SEND_CODE	Enviar código	Texto público configurable de la tienda	2026-07-11 08:29:44.488256	\N
114	UI_CART_POINTS_CODE_HELP	Introduce el código recibido por WhatsApp:	Texto público configurable de la tienda	2026-07-11 08:29:44.489504	\N
115	UI_CART_POINTS_VERIFY	Verificar	Texto público configurable de la tienda	2026-07-11 08:29:44.490789	\N
116	UI_CART_POINTS_CHANGE_PHONE	Cambiar número	Texto público configurable de la tienda	2026-07-11 08:29:44.492016	\N
117	UI_CART_PHONE_PLACEHOLDER	+34 600 000 000	Texto público configurable de la tienda	2026-07-11 08:29:44.493306	\N
118	UI_CART_CODE_PLACEHOLDER	000000	Texto público configurable de la tienda	2026-07-11 08:29:44.494659	\N
119	UI_CART_PHONE_REQUIRED	Introduce tu número	Texto público configurable de la tienda	2026-07-11 08:29:44.495947	\N
120	UI_CART_CODE_REQUIRED	Introduce el código	Texto público configurable de la tienda	2026-07-11 08:29:44.497183	\N
121	UI_CART_SENDING	Enviando...	Texto público configurable de la tienda	2026-07-11 08:29:44.498368	\N
122	UI_CART_VERIFYING	Verificando...	Texto público configurable de la tienda	2026-07-11 08:29:44.49967	\N
123	UI_CART_GENERIC_ERROR	Error	Texto público configurable de la tienda	2026-07-11 08:29:44.500923	\N
124	UI_CART_NETWORK_ERROR	Error de red	Texto público configurable de la tienda	2026-07-11 08:29:44.502262	\N
125	UI_CART_INVALID_CODE	Código incorrecto	Texto público configurable de la tienda	2026-07-11 08:29:44.503566	\N
126	UI_CART_REDEEMABLE_TITLE	Productos canjeables con tus puntos	Texto público configurable de la tienda	2026-07-11 08:29:44.504888	\N
127	UI_CART_SELECTED	Seleccionado	Texto público configurable de la tienda	2026-07-11 08:29:44.506155	\N
128	UI_CART_AVAILABLE	Disponible	Texto público configurable de la tienda	2026-07-11 08:29:44.5074	\N
129	UI_CART_MISSING_PREFIX	Faltan	Texto público configurable de la tienda	2026-07-11 08:29:44.508654	\N
130	UI_CART_ALLERGEN_NOTICE	Revisa los alérgenos. Si tienes intolerancias o alergias indícalo en las notas al confirmar el pedido.	Texto público configurable de la tienda	2026-07-11 08:29:44.50986	\N
131	UI_CART_SUMMARY	Resumen	Texto público configurable de la tienda	2026-07-11 08:29:44.511094	\N
132	UI_CART_SUBTOTAL	Subtotal	Texto público configurable de la tienda	2026-07-11 08:29:44.512488	\N
133	UI_CART_SHIPPING	Envío	Texto público configurable de la tienda	2026-07-11 08:29:44.513776	\N
134	UI_CART_POINTS_DISCOUNT	Canje con puntos	Texto público configurable de la tienda	2026-07-11 08:29:44.514999	\N
135	UI_CART_INCOMPATIBLE	Revisa los productos incompatibles	Texto público configurable de la tienda	2026-07-11 08:29:44.516189	\N
136	UI_CART_TOTAL	Total estimado	Texto público configurable de la tienda	2026-07-11 08:29:44.517383	\N
137	UI_CART_CHECKOUT_BOTH	Elegir entrega o recogida	Texto público configurable de la tienda	2026-07-11 08:29:44.518564	\N
138	UI_CART_CHECKOUT_DELIVERY	Continuar con entrega	Texto público configurable de la tienda	2026-07-11 08:29:44.519747	\N
139	UI_CART_CHECKOUT_PICKUP	Continuar para recoger	Texto público configurable de la tienda	2026-07-11 08:29:44.52092	\N
140	UI_CART_CONTINUE	Seguir comprando	Texto público configurable de la tienda	2026-07-11 08:29:44.522373	\N
141	UI_CART_EMPTY_TITLE	Tu carrito está vacío	Texto público configurable de la tienda	2026-07-11 08:29:44.523558	\N
142	UI_CART_EMPTY_TEXT	Explora el menú y encuentra tu favorito	Texto público configurable de la tienda	2026-07-11 08:29:44.525295	\N
143	UI_CART_VIEW_MENU	Ver menú completo	Texto público configurable de la tienda	2026-07-11 08:29:44.527229	\N
144	UI_PWA_DESCRIPTION	Añade la tienda a tu pantalla de inicio para acceder sin abrir el navegador.	Texto público configurable de la tienda	2026-07-11 08:29:44.529182	\N
145	UI_PWA_IOS_INSTRUCTION	En Safari, toca Compartir y luego Añadir a pantalla de inicio.	Texto público configurable de la tienda	2026-07-11 08:29:44.530969	\N
146	UI_PWA_INSTALL	Instalar	Texto público configurable de la tienda	2026-07-11 08:29:44.532895	\N
147	UI_PWA_IOS_ACTION	Ver cómo	Texto público configurable de la tienda	2026-07-11 08:29:44.534521	\N
148	UI_PWA_INAPP_INSTRUCTION	Abre este sitio en Safari o Chrome para instalar la aplicación y activar todas sus funciones.	Texto público configurable de la tienda	2026-07-11 08:29:44.536068	\N
149	UI_PWA_INAPP_ACTION	Cómo instalar	Texto público configurable de la tienda	2026-07-11 08:29:44.537842	\N
150	UI_PWA_OFFLINE	Preparar offline	Texto público configurable de la tienda	2026-07-11 08:29:44.539459	\N
151	UI_PWA_NOTIFICATIONS	Notificaciones	Texto público configurable de la tienda	2026-07-11 08:29:44.541144	\N
152	UI_PWA_NOTIFICATIONS_ACTIVE	Activas	Texto público configurable de la tienda	2026-07-11 08:29:44.542887	\N
153	UI_PWA_PUSH_TITLE	Seguimiento en tiempo real	Texto público configurable de la tienda	2026-07-11 08:29:44.54445	\N
154	UI_PWA_PUSH_TEXT	Activa avisos sobre el estado de tus pedidos.	Texto público configurable de la tienda	2026-07-11 08:29:44.546216	\N
155	UI_PWA_PUSH_ACTION	Activar	Texto público configurable de la tienda	2026-07-11 08:29:44.548198	\N
156	UI_PWA_APP_SECTION	Experiencia de aplicación	Texto público configurable de la tienda	2026-07-11 08:29:44.550165	\N
157	UI_PWA_APP_SECTION_TEXT	Instala la tienda y conserva recursos esenciales para abrirla más rápido.	Texto público configurable de la tienda	2026-07-11 08:29:44.551918	\N
158	UI_PWA_STORAGE_PERSISTED	Almacenamiento persistente activado.	Texto público configurable de la tienda	2026-07-11 08:29:44.553441	\N
159	UI_PWA_STORAGE_AVAILABLE	La aplicación puede funcionar sin conexión; el navegador gestionará el espacio.	Texto público configurable de la tienda	2026-07-11 08:29:44.554888	\N
160	UI_PWA_STORAGE_MANAGED	El navegador gestionará el almacenamiento automáticamente.	Texto público configurable de la tienda	2026-07-11 08:29:44.556158	\N
161	UI_INFO_HELP	Info y ayuda	Texto público configurable de la tienda	2026-07-11 08:29:44.557408	\N
162	UI_NAV_HOME	Inicio	Texto público configurable de la tienda	2026-07-11 08:29:44.558899	\N
163	UI_NAV_SEARCH	Buscar	Texto público configurable de la tienda	2026-07-11 08:29:44.560357	\N
164	UI_NAV_INFO	Info	Texto público configurable de la tienda	2026-07-11 08:29:44.561729	\N
165	UI_NAV_CART	Carrito	Texto público configurable de la tienda	2026-07-11 08:29:44.563686	\N
166	IVA_DEFAULT_COMIDA	10.00	IVA por defecto para productos vertical=comida (España: 10%).	2026-07-11 08:29:44.565097	\N
167	IVA_DEFAULT_RETAIL	21.00	IVA por defecto para productos retail/servicios (España: 21%).	2026-07-11 08:29:44.566349	\N
168	NOMBRE_FISCAL		Razón social o nombre fiscal para facturas. Cae a NOMBRE_NEGOCIO si vacío.	2026-07-11 08:29:44.567601	\N
169	NIF_NEGOCIO		NIF/CIF del negocio. Requerido en facturas fiscales españolas.	2026-07-11 08:29:44.568857	\N
170	DIRECCION_FISCAL		Domicilio fiscal completo (para exportación al gestor).	2026-07-11 08:29:44.57011	\N
171	DELIVERY_CODE_MAX_INTENTOS	3	Intentos permitidos al validar el código de entrega (repartidor).	2026-07-11 08:29:44.571377	\N
172	COD_PUNTOS_MAX_INTENTOS	5	Intentos permitidos al canjear puntos con OTP WhatsApp.	2026-07-11 08:29:44.572654	\N
173	COD_PUNTOS_TTL_MINUTOS	10	Vigencia (minutos) del OTP para canje de puntos.	2026-07-11 08:29:44.573914	\N
174	NOTIFICATION_OUTBOX_RETENTION_DAYS	30	Días que se conservan las notificaciones ya enviadas o fallidas en notification_outbox. Solo purga estado in (sent, failed). Cap defensivo interno 7-365.	2026-07-11 08:29:44.575204	\N
175	IDEMPOTENCY_PURGE_ENABLED	1	Habilita la purga automática de idempotency_keys expiradas junto con la de notification_outbox. Poner a 0 solo para diagnóstico.	2026-07-11 08:29:44.576604	\N
176	OTP_MIN_RESEND_SECONDS	60	Ventana mínima (segundos) entre 2 solicitudes de OTP de puntos del mismo cliente. Anti-flood — consumida por loyalty_service.	2026-07-11 08:29:44.578025	\N
177	ADMIN_CLIENTES_PAGE_SIZE	40	Tamaño de página del listado /admin/clientes (cap 10-200).	2026-07-11 08:29:44.579459	\N
178	VAPID_PUBLIC_KEY	BPLg69UWj_0XScPac9OULqZwOn3MplihEstnB-1h9_8RL9a4xCZAglqhRoQ_npT6flwjyvOP7m4lbgeKOEtzHXQ	Clave pública VAPID para Web Push	2026-07-11 08:29:44.656492	\N
179	VAPID_PRIVATE_KEY	-----BEGIN PRIVATE KEY-----\nMIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgEp5UCcSrEs1poqs/\nedFifHWfi5RWLEzR+oZswzT+gnqhRANCAATy4OvVFo/9F0nD2nPTlC6mcDp9zKZY\noRLLZwftYff/ES/WuMQmQIJaoUaEP56U+n5cI8rzj+5uJW4HijhLcx10\n-----END PRIVATE KEY-----\n	Clave privada VAPID para Web Push (NO compartir)	2026-07-11 08:29:44.657479	\N
2	TELEFONO_NEGOCIO	+34633096706	\N	2026-07-11 08:29:44.673114	\N
3	DIRECCION_NEGOCIO	Carmona, Sevilla	\N	2026-07-11 08:29:44.674642	\N
184	CONFIRMACION_MONTO_UMBRAL_EUR	50	Umbral en euros a partir del cual el sistema marca el pedido como MEDIUM/HIGH y solicita verificación pasiva vía WhatsApp. Ajusta según ticket medio de tu negocio. Cap defensivo 1-9999.	2026-07-12 22:45:58.549919	\N
185	CONFIRMACION_HABILITADA	1	Interruptor global de la verificación anti-fantasma. 0 desactiva completamente el marcado — usa solo durante debug o si el negocio prefiere revisión 100% manual.	2026-07-12 22:45:58.551734	\N
31	BOT_API_URL	http://127.0.0.1:3000	URL interna del bot WhatsApp	2026-07-14 07:46:49.603036	\N
30	BOT_API_KEY	6qpTMSELwLVo-w9M8Yh0IXzLDJ4	API key compartida entre Oxidian y el bot	2026-07-14 07:46:49.611999	\N
182	PEDIDO_MINIMO_EUR		Monto mínimo de pedido en euros (0 = sin mínimo)	2026-07-12 11:09:42.755339	2
183	STOCK_ALERTA_DIAS_DEFAULT	7	Días de anticipación por defecto para alertar próximo vencimiento de lotes de Stock. Cada lote puede sobrescribirlo en su ficha.	2026-07-12 15:09:55.158856	\N
32	BOT_PANEL_KEY	p1E8VlMCXeSsSJfFfilWrOeCmN0	Clave para administrar el bot desde Super Admin	2026-07-14 07:46:49.613049	\N
180	MAX_PEDIDOS_POR_PREPARADOR	8	Máximo pedidos activos (pendiente+armando) por preparador antes de repartir a otros. Cap defensivo 1-100. Ajusta según capacidad real de tu cocina.	2026-07-11 15:11:56.657152	\N
181	MAX_PEDIDOS_POR_REPARTIDOR	5	Máximo pedidos activos (listo+en_ruta) por repartidor antes de repartir a otros. Cap defensivo 1-50. En moto/coche subir; en bici bajar.	2026-07-11 15:11:56.66701	\N
34	OXIDIAN_PUBLIC_URL	https://elparcerito.com	URL de Oxidian que usará el bot	2026-07-14 07:46:49.613975	\N
35	EVOLUTION_API_URL	http://evolution-api:8080	URL interna de Evolution API	2026-07-14 07:46:49.616792	\N
36	EVOLUTION_API_KEY	eLmX3fqUuFA4MRep6IcV-NcIc6CioJlSVicRqJVaNqw	Clave API de Evolution	2026-07-14 07:46:49.617776	\N
37	EVOLUTION_INSTANCE	parcerito	Instancia WhatsApp de Evolution	2026-07-14 07:46:49.618676	\N
186	CONFIRMACION_TTL_HIGH_MINUTES	120	Minutos que un HIGH puede estar pending sin respuesta antes de auto-cancelar. Solo HIGH — MEDIUM queda para revisión manual. Cap 15-1440. 0 desactiva.	2026-07-13 07:40:49.190894	\N
187	COMBO_MAX_PRICE_EUR	1000	Precio máximo permitido para un combo, en euros. Cap defensivo interno 1-100000. Antes hardcoded a 1000€.	2026-07-13 15:51:59.328389	\N
38	WEBHOOK_SECRET	57bb87d09a4ebc4fa47bddc0ce67735b91dc6fe7a81c89fd5d5705449068b074	Secreto webhook Evolution -> Oxidian	2026-07-14 07:46:49.619515	\N
190	TIENDA_MENSAJE_CIERRE		Mensaje de cierre temporal	2026-07-14 08:19:42.169771	\N
188	BOT_MAX_PRICE_EUR	9999	Precio máximo permitido en cambios de producto/SKU desde el bot WhatsApp (`!precio ID EUROS`). Cap defensivo interno 1-100000. Sirve tanto para productos propios como para SKUs del bar en modo bar_se…	2026-07-13 16:19:48.551556	\N
189	BOT_MAX_POINTS_ADJUST	10000	Cantidad máxima de puntos ajustables en una sola operación desde el bot (`!puntos +/-N` o menú admin). Evita typos que agreguen 100000 en vez de 100. Cap 1-1000000.	2026-07-13 16:19:48.559949	\N
\.


--
-- Data for Name: staff_payments; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.staff_payments (id, user_id, tipo, monto, concepto, periodo_inicio, periodo_fin, pedido_id, origen, pagado, fecha_pago, registrado_por, creado_en) FROM stdin;
1	5	comision	3.00	Reparto cobrado en #1001	\N	\N	1	delivery	f	\N	\N	2026-07-12 11:26:23.677535
2	3	comision	3.00	Reparto cobrado en #1005	\N	\N	5	delivery	f	\N	\N	2026-07-13 23:12:33.322569
\.


--
-- Data for Name: stock; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.stock (id, producto_id, cantidad, unidad, lote, fecha_entrada, fecha_caducidad, alerta_dias, ubicacion) FROM stdin;
2	2	50	unidad	\N	2026-07-14	\N	7	\N
3	2	50	unidad	\N	2026-07-14	\N	7	\N
1	1	96	unidad	\N	2026-07-12	\N	7	\N
\.


--
-- Data for Name: tenant_config; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.tenant_config (id, modo, comision_pct, delivery_habilitado, pickup_habilitado, suspendido, ciclo_dias, suspendida, suspendida_motivo, suspendida_en, ciclo_inicio) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.users (id, nombre, email, password_hash, rol, telefono, telefono_normalizado, direccion, puntos, activo, creado_en, last_seen, en_linea, cod_puntos, cod_puntos_expira, cod_puntos_intentos, mfa_secret, mfa_enabled, mfa_session_version, puesto_trabajo, salario_base, tarifa_entrega, proveedor_id, mfa_recovery_codes_hash, whatsapp_opt_out, whatsapp_opt_out_en, zona_repartidor_id, nif) FROM stdin;
6	María González	maria.gonzalez@example.com	scrypt:32768:8:1$jEZTIPt6sM1cMPTx$d73054c8c9f225633d89d4ffcf8492b3fce20e24cca567a86951a44f94185e0f7d3b50bc569bd06b344ac3075c3a4412b16434c01767ee4459ffc8037bb7f9af	cliente	+34600111222	+34600111222	\N	250	t	2026-07-13 10:03:14.40375	\N	f	\N	\N	0	\N	f	0	\N	0.00	0.00	\N	\N	f	\N	\N	\N
2	Panzeta	carmocream15@gmail.com	scrypt:32768:8:1$XpKMFclNj6xWPDTl$1cd2a8961ce686e869029804140145133cc3708b021e389d2ee80f5329bf71bfb5aaf94d0a3246c56d5ea24c889b9e4b4f1028f3eafa6ac0dc00d52d9bf15fb4	super_admin	+34622663874	+34622663874	Calle Andalucía 20	723	t	2026-07-11 08:14:08.790906	2026-07-14 15:40:53.48657	f	\N	\N	0	CZOKPINKR2LSE3QHYXGH4ADULPWCUU3S	t	0	\N	0.00	0.00	\N	\N	f	\N	\N	\N
7	Carlos Ruiz Mendoza	carlos.ruiz@example.com	scrypt:32768:8:1$ASCvOrtBa4XzuZOK$9ab9b8d1ac81ded8a4c627bdcbdbede0d6b73314a2ddfdc8db581dad0beee18885a59028852f81b6c96494b0b8e987020f2478cebe5af69936cc0a7e08a4f179	cliente	+34611222333	+34611222333	\N	40	t	2026-07-13 10:03:14.485226	\N	f	\N	\N	0	\N	f	0	\N	0.00	0.00	\N	\N	f	\N	\N	\N
4	Steven	cliente.622663874@customers.oxidian.internal	scrypt:32768:8:1$dSkY2T9YoeCQKfAA$79f23beedadd0c5ed0d76eb5eadbcb757121815870af73fb3d7ab9dc96c179f5bd73f5e73a35e9bc0e25cd8f408add6ff849872b952ab11bbde43c458ee0164b	cliente	\N	\N	Calle Andalucía 20	0	f	2026-07-12 11:12:12.636067	\N	f	\N	\N	0	\N	f	0	\N	0.00	0.00	\N	\N	f	\N	\N	\N
3	Steven gonzalez	stevenconejito29@gmail.com	scrypt:32768:8:1$6I07IfNkKYRgPmwJ$dd2901a8a1f8eea3cf6346b014c7d9ab60c9f8047f1132ca62781be4f4348e25fc32ef0353d7a493b67bb8013105304e3b4443287bd8e433d2abaae56d4ba374	cocina	+34622663877	+34622663877	\N	0	t	2026-07-11 12:27:44.34413	2026-07-14 08:11:55.57465	f	\N	\N	0	\N	f	0	\N	0.00	0.00	\N	\N	f	\N	\N	\N
30	Sebas	cliente.34667478856@customers.oxidian.internal	scrypt:32768:8:1$oGPpkFprxhuVYI0P$c70df458ff6015590e7be978915267624a74fc5ba781a4e7913a2cde163c5e5b96bc15a3596bd6bd750741cf2957e742e25e2d67512653152ac8272af507faa5	cliente	+34667478856	+34667478856	Calle Andalucía 20	303	t	2026-07-13 23:07:21.09938	\N	f	\N	\N	3	\N	f	0	\N	0.00	0.00	\N	\N	f	\N	\N	\N
5	Steven gonzalez	stevenconejito@gmail.com	scrypt:32768:8:1$bXZhYwTTrJggQUvR$4db7ae0ca7fedadcea3eed7f9d3f99933df154c8d70c383e2ab50a339f67b1647d59f03b57cfe4ebdab411f852401e2c58428947af304f72770bdb052f4bfacf	cocina	+346236352	+346236352	\N	0	t	2026-07-12 11:23:09.732533	2026-07-12 21:50:09.441448	t	\N	\N	0	\N	f	0	\N	0.00	0.00	\N	\N	f	\N	\N	\N
31	Danna	cliente.632907709@customers.oxidian.internal	scrypt:32768:8:1$WyWXGmPbRvgRNapR$234b69b7b9f72c811b4053b94912ea60508f3469ad0b5d4180ec021a92ba8da7101b0545af6787a063cd80994f4f656e786c3e779bfad5a7f95766103b2d81f1	cliente	+34632907709	+34632907709	Calle torre del oro 32	0	t	2026-07-13 23:20:03.215154	\N	f	\N	\N	0	\N	f	0	\N	0.00	0.00	\N	\N	f	\N	\N	\N
\.


--
-- Data for Name: zonas_entrega; Type: TABLE DATA; Schema: public; Owner: oxidian
--

COPY public.zonas_entrega (id, nombre, descripcion, es_epicentro, activo, precio_envio, tiempo_estimado_min, gratis_desde, orden, centro_lat, centro_lng, radio_km) FROM stdin;
1	Carmona	Sevilla Carmona centro	t	t	3.00	25	\N	0	\N	\N	\N
\.


--
-- Name: admin_features_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.admin_features_id_seq', 12, true);


--
-- Name: affiliate_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.affiliate_codes_id_seq', 1, false);


--
-- Name: affiliate_uses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.affiliate_uses_id_seq', 1, false);


--
-- Name: ai_assistant_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.ai_assistant_config_id_seq', 1, false);


--
-- Name: ai_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.ai_conversations_id_seq', 1, false);


--
-- Name: ai_usage_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.ai_usage_log_id_seq', 1, false);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 46, true);


--
-- Name: bot_ai_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.bot_ai_messages_id_seq', 1, false);


--
-- Name: bot_ai_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.bot_ai_usage_id_seq', 1, false);


--
-- Name: caja_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.caja_id_seq', 2, true);


--
-- Name: campanas_marketing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.campanas_marketing_id_seq', 1, false);


--
-- Name: categorias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.categorias_id_seq', 1, true);


--
-- Name: combo_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.combo_groups_id_seq', 1, false);


--
-- Name: combo_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.combo_items_id_seq', 1, false);


--
-- Name: coupons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.coupons_id_seq', 1, false);


--
-- Name: extra_catalog_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.extra_catalog_items_id_seq', 1, false);


--
-- Name: hub_commissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.hub_commissions_id_seq', 1, false);


--
-- Name: idempotency_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.idempotency_keys_id_seq', 8, true);


--
-- Name: menu_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.menu_config_id_seq', 1, true);


--
-- Name: notification_outbox_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.notification_outbox_id_seq', 38, true);


--
-- Name: order_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.order_events_id_seq', 31, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.order_items_id_seq', 8, true);


--
-- Name: order_provider_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.order_provider_status_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.orders_id_seq', 8, true);


--
-- Name: points_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.points_log_id_seq', 3, true);


--
-- Name: price_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.price_history_id_seq', 1, false);


--
-- Name: product_extra_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.product_extra_groups_id_seq', 1, false);


--
-- Name: product_extra_options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.product_extra_options_id_seq', 1, false);


--
-- Name: product_extras_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.product_extras_id_seq', 1, false);


--
-- Name: product_presentations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.product_presentations_id_seq', 1, false);


--
-- Name: product_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.product_variants_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.products_id_seq', 2, true);


--
-- Name: proveedor_productos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.proveedor_productos_id_seq', 1, false);


--
-- Name: proveedores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.proveedores_id_seq', 1, false);


--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.push_subscriptions_id_seq', 4, true);


--
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.reviews_id_seq', 1, false);


--
-- Name: site_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.site_config_id_seq', 191, true);


--
-- Name: staff_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.staff_payments_id_seq', 2, true);


--
-- Name: stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.stock_id_seq', 3, true);


--
-- Name: tenant_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.tenant_config_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.users_id_seq', 31, true);


--
-- Name: zonas_entrega_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oxidian
--

SELECT pg_catalog.setval('public.zonas_entrega_id_seq', 1, true);


--
-- Name: admin_features admin_features_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.admin_features
    ADD CONSTRAINT admin_features_pkey PRIMARY KEY (id);


--
-- Name: affiliate_codes affiliate_codes_codigo_key; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.affiliate_codes
    ADD CONSTRAINT affiliate_codes_codigo_key UNIQUE (codigo);


--
-- Name: affiliate_codes affiliate_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.affiliate_codes
    ADD CONSTRAINT affiliate_codes_pkey PRIMARY KEY (id);


--
-- Name: affiliate_uses affiliate_uses_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.affiliate_uses
    ADD CONSTRAINT affiliate_uses_pkey PRIMARY KEY (id);


--
-- Name: ai_assistant_config ai_assistant_config_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.ai_assistant_config
    ADD CONSTRAINT ai_assistant_config_pkey PRIMARY KEY (id);


--
-- Name: ai_conversations ai_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.ai_conversations
    ADD CONSTRAINT ai_conversations_pkey PRIMARY KEY (id);


--
-- Name: ai_usage_log ai_usage_log_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.ai_usage_log
    ADD CONSTRAINT ai_usage_log_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: bot_ai_messages bot_ai_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.bot_ai_messages
    ADD CONSTRAINT bot_ai_messages_pkey PRIMARY KEY (id);


--
-- Name: bot_ai_usage bot_ai_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.bot_ai_usage
    ADD CONSTRAINT bot_ai_usage_pkey PRIMARY KEY (id);


--
-- Name: caja caja_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.caja
    ADD CONSTRAINT caja_pkey PRIMARY KEY (id);


--
-- Name: campanas_marketing campanas_marketing_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.campanas_marketing
    ADD CONSTRAINT campanas_marketing_pkey PRIMARY KEY (id);


--
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (id);


--
-- Name: combo_groups combo_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.combo_groups
    ADD CONSTRAINT combo_groups_pkey PRIMARY KEY (id);


--
-- Name: combo_items combo_items_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.combo_items
    ADD CONSTRAINT combo_items_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_codigo_key; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_codigo_key UNIQUE (codigo);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: extra_catalog_items extra_catalog_items_nombre_key; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.extra_catalog_items
    ADD CONSTRAINT extra_catalog_items_nombre_key UNIQUE (nombre);


--
-- Name: extra_catalog_items extra_catalog_items_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.extra_catalog_items
    ADD CONSTRAINT extra_catalog_items_pkey PRIMARY KEY (id);


--
-- Name: hub_commissions hub_commissions_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.hub_commissions
    ADD CONSTRAINT hub_commissions_pkey PRIMARY KEY (id);


--
-- Name: idempotency_keys idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_pkey PRIMARY KEY (id);


--
-- Name: menu_config menu_config_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.menu_config
    ADD CONSTRAINT menu_config_pkey PRIMARY KEY (id);


--
-- Name: notification_outbox notification_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.notification_outbox
    ADD CONSTRAINT notification_outbox_pkey PRIMARY KEY (id);


--
-- Name: order_events order_events_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.order_events
    ADD CONSTRAINT order_events_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: order_provider_status order_provider_status_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.order_provider_status
    ADD CONSTRAINT order_provider_status_pkey PRIMARY KEY (id);


--
-- Name: orders orders_numero_pedido_key; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_numero_pedido_key UNIQUE (numero_pedido);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: points_log points_log_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.points_log
    ADD CONSTRAINT points_log_pkey PRIMARY KEY (id);


--
-- Name: price_history price_history_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_pkey PRIMARY KEY (id);


--
-- Name: product_extra_groups product_extra_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_extra_groups
    ADD CONSTRAINT product_extra_groups_pkey PRIMARY KEY (id);


--
-- Name: product_extra_options product_extra_options_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_extra_options
    ADD CONSTRAINT product_extra_options_pkey PRIMARY KEY (id);


--
-- Name: product_extras product_extras_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_extras
    ADD CONSTRAINT product_extras_pkey PRIMARY KEY (id);


--
-- Name: product_presentations product_presentations_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_presentations
    ADD CONSTRAINT product_presentations_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_sku_key; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_sku_key UNIQUE (sku);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: proveedor_productos proveedor_productos_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.proveedor_productos
    ADD CONSTRAINT proveedor_productos_pkey PRIMARY KEY (id);


--
-- Name: proveedores proveedores_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.proveedores
    ADD CONSTRAINT proveedores_pkey PRIMARY KEY (id);


--
-- Name: push_subscriptions push_subscriptions_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_endpoint_key UNIQUE (endpoint);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: site_config site_config_clave_key; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.site_config
    ADD CONSTRAINT site_config_clave_key UNIQUE (clave);


--
-- Name: site_config site_config_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.site_config
    ADD CONSTRAINT site_config_pkey PRIMARY KEY (id);


--
-- Name: staff_payments staff_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.staff_payments
    ADD CONSTRAINT staff_payments_pkey PRIMARY KEY (id);


--
-- Name: stock stock_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_pkey PRIMARY KEY (id);


--
-- Name: tenant_config tenant_config_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.tenant_config
    ADD CONSTRAINT tenant_config_pkey PRIMARY KEY (id);


--
-- Name: admin_features uq_admin_feature; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.admin_features
    ADD CONSTRAINT uq_admin_feature UNIQUE (user_id, feature);


--
-- Name: affiliate_uses uq_affiliate_use_order; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.affiliate_uses
    ADD CONSTRAINT uq_affiliate_use_order UNIQUE (codigo_id, pedido_id);


--
-- Name: idempotency_keys uq_idempotency_scope_key; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT uq_idempotency_scope_key UNIQUE (scope, key);


--
-- Name: product_presentations uq_product_presentation; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_presentations
    ADD CONSTRAINT uq_product_presentation UNIQUE (producto_id, "tamaño");


--
-- Name: proveedor_productos uq_proveedor_producto; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.proveedor_productos
    ADD CONSTRAINT uq_proveedor_producto UNIQUE (proveedor_id, producto_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: zonas_entrega zonas_entrega_pkey; Type: CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.zonas_entrega
    ADD CONSTRAINT zonas_entrega_pkey PRIMARY KEY (id);


--
-- Name: ix_ai_conversations_telefono; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_ai_conversations_telefono ON public.ai_conversations USING btree (telefono);


--
-- Name: ix_audit_log_accion_creado; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_audit_log_accion_creado ON public.audit_log USING btree (accion, creado_en);


--
-- Name: ix_audit_log_creado_en; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_audit_log_creado_en ON public.audit_log USING btree (creado_en);


--
-- Name: ix_audit_log_user_id; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_audit_log_user_id ON public.audit_log USING btree (user_id);


--
-- Name: ix_bot_ai_messages_creado_en; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_bot_ai_messages_creado_en ON public.bot_ai_messages USING btree (creado_en);


--
-- Name: ix_bot_ai_messages_telefono_hash; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_bot_ai_messages_telefono_hash ON public.bot_ai_messages USING btree (telefono_hash);


--
-- Name: ix_bot_ai_usage_creado_en; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_bot_ai_usage_creado_en ON public.bot_ai_usage USING btree (creado_en);


--
-- Name: ix_bot_ai_usage_telefono_hash; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_bot_ai_usage_telefono_hash ON public.bot_ai_usage USING btree (telefono_hash);


--
-- Name: ix_caja_fecha; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_caja_fecha ON public.caja USING btree (fecha);


--
-- Name: ix_caja_tipo; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_caja_tipo ON public.caja USING btree (tipo);


--
-- Name: ix_combo_groups_combo_id; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_combo_groups_combo_id ON public.combo_groups USING btree (combo_id);


--
-- Name: ix_combo_groups_combo_orden; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_combo_groups_combo_orden ON public.combo_groups USING btree (combo_id, orden);


--
-- Name: ix_combo_items_combo_id; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_combo_items_combo_id ON public.combo_items USING btree (combo_id);


--
-- Name: ix_combo_items_group_id; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_combo_items_group_id ON public.combo_items USING btree (combo_group_id);


--
-- Name: ix_combo_items_producto_id; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_combo_items_producto_id ON public.combo_items USING btree (producto_id);


--
-- Name: ix_combo_items_variant_id; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_combo_items_variant_id ON public.combo_items USING btree (variant_id);


--
-- Name: ix_idempotency_expira; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_idempotency_expira ON public.idempotency_keys USING btree (expira_en);


--
-- Name: ix_notification_outbox_estado; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_notification_outbox_estado ON public.notification_outbox USING btree (estado);


--
-- Name: ix_notification_outbox_pedido_id; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_notification_outbox_pedido_id ON public.notification_outbox USING btree (pedido_id);


--
-- Name: ix_notification_outbox_siguiente; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_notification_outbox_siguiente ON public.notification_outbox USING btree (siguiente_intento_en);


--
-- Name: ix_order_events_creado_en; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_order_events_creado_en ON public.order_events USING btree (creado_en);


--
-- Name: ix_order_events_pedido_id; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_order_events_pedido_id ON public.order_events USING btree (pedido_id);


--
-- Name: ix_order_events_tipo; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_order_events_tipo ON public.order_events USING btree (tipo);


--
-- Name: ix_order_provider_status_pedido; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_order_provider_status_pedido ON public.order_provider_status USING btree (pedido_id);


--
-- Name: ix_orders_cliente_estado; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_orders_cliente_estado ON public.orders USING btree (cliente_id, estado);


--
-- Name: ix_orders_cliente_id; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_orders_cliente_id ON public.orders USING btree (cliente_id);


--
-- Name: ix_orders_creado_en; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_orders_creado_en ON public.orders USING btree (creado_en);


--
-- Name: ix_orders_entregado_en; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_orders_entregado_en ON public.orders USING btree (entregado_en);


--
-- Name: ix_orders_estado; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_orders_estado ON public.orders USING btree (estado);


--
-- Name: ix_orders_estado_creado; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_orders_estado_creado ON public.orders USING btree (estado, creado_en);


--
-- Name: ix_orders_preparador; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_orders_preparador ON public.orders USING btree (preparador_id);


--
-- Name: ix_orders_preparador_estado; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_orders_preparador_estado ON public.orders USING btree (preparador_id, estado);


--
-- Name: ix_orders_repartidor; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_orders_repartidor ON public.orders USING btree (repartidor_id);


--
-- Name: ix_orders_repartidor_estado; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_orders_repartidor_estado ON public.orders USING btree (repartidor_id, estado);


--
-- Name: ix_points_log_cliente_id; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_points_log_cliente_id ON public.points_log USING btree (cliente_id);


--
-- Name: ix_points_log_creado_en; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_points_log_creado_en ON public.points_log USING btree (creado_en);


--
-- Name: ix_product_extra_groups_product; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_product_extra_groups_product ON public.product_extra_groups USING btree (producto_id, orden);


--
-- Name: ix_product_extra_options_group; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_product_extra_options_group ON public.product_extra_options USING btree (grupo_id, orden);


--
-- Name: ix_product_extras_producto; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_product_extras_producto ON public.product_extras USING btree (producto_id);


--
-- Name: ix_product_extras_producto_activo; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_product_extras_producto_activo ON public.product_extras USING btree (producto_id, activo);


--
-- Name: ix_product_presentations_producto; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_product_presentations_producto ON public.product_presentations USING btree (producto_id, activo);


--
-- Name: ix_product_variants_product_id; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_product_variants_product_id ON public.product_variants USING btree (product_id);


--
-- Name: ix_product_variants_producto_orden; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_product_variants_producto_orden ON public.product_variants USING btree (product_id, orden);


--
-- Name: ix_products_vertical; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_products_vertical ON public.products USING btree (vertical);


--
-- Name: ix_proveedor_productos_producto; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_proveedor_productos_producto ON public.proveedor_productos USING btree (producto_id);


--
-- Name: ix_proveedor_productos_proveedor; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_proveedor_productos_proveedor ON public.proveedor_productos USING btree (proveedor_id);


--
-- Name: ix_proveedores_activo; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_proveedores_activo ON public.proveedores USING btree (activo);


--
-- Name: ix_push_sub_rol; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_push_sub_rol ON public.push_subscriptions USING btree (rol);


--
-- Name: ix_push_sub_rol_activo; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_push_sub_rol_activo ON public.push_subscriptions USING btree (rol, activo);


--
-- Name: ix_push_sub_user_activo; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_push_sub_user_activo ON public.push_subscriptions USING btree (user_id, activo);


--
-- Name: ix_push_sub_user_id; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_push_sub_user_id ON public.push_subscriptions USING btree (user_id);


--
-- Name: ix_stock_caducidad; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_stock_caducidad ON public.stock USING btree (fecha_caducidad);


--
-- Name: ix_stock_producto_id; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE INDEX ix_stock_producto_id ON public.stock USING btree (producto_id);


--
-- Name: ix_users_telefono_normalizado; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE UNIQUE INDEX ix_users_telefono_normalizado ON public.users USING btree (telefono_normalizado);


--
-- Name: uq_caja_order_income; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE UNIQUE INDEX uq_caja_order_income ON public.caja USING btree (pedido_id) WHERE (((tipo)::text = 'ingreso'::text) AND (pedido_id IS NOT NULL));


--
-- Name: uq_caja_order_refund; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE UNIQUE INDEX uq_caja_order_refund ON public.caja USING btree (pedido_id) WHERE (((tipo)::text = 'egreso'::text) AND ((categoria)::text = 'devolucion'::text) AND (pedido_id IS NOT NULL));


--
-- Name: uq_caja_staff_payment_expense; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE UNIQUE INDEX uq_caja_staff_payment_expense ON public.caja USING btree (staff_payment_id) WHERE (((tipo)::text = 'egreso'::text) AND (staff_payment_id IS NOT NULL));


--
-- Name: uq_points_log_order_earned; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE UNIQUE INDEX uq_points_log_order_earned ON public.points_log USING btree (cliente_id, pedido_id, tipo) WHERE (((tipo)::text = 'ganado'::text) AND (pedido_id IS NOT NULL));


--
-- Name: uq_product_variants_talla_color; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE UNIQUE INDEX uq_product_variants_talla_color ON public.product_variants USING btree (product_id, talla, color) WHERE ((talla IS NOT NULL) AND (color IS NOT NULL));


--
-- Name: uq_staff_payment_delivery_commission; Type: INDEX; Schema: public; Owner: oxidian
--

CREATE UNIQUE INDEX uq_staff_payment_delivery_commission ON public.staff_payments USING btree (user_id, origen, pedido_id) WHERE (((tipo)::text = 'comision'::text) AND (pedido_id IS NOT NULL));


--
-- Name: admin_features admin_features_actualizado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.admin_features
    ADD CONSTRAINT admin_features_actualizado_por_fkey FOREIGN KEY (actualizado_por) REFERENCES public.users(id);


--
-- Name: admin_features admin_features_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.admin_features
    ADD CONSTRAINT admin_features_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: affiliate_codes affiliate_codes_creado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.affiliate_codes
    ADD CONSTRAINT affiliate_codes_creado_por_fkey FOREIGN KEY (creado_por) REFERENCES public.users(id);


--
-- Name: affiliate_codes affiliate_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.affiliate_codes
    ADD CONSTRAINT affiliate_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: affiliate_uses affiliate_uses_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.affiliate_uses
    ADD CONSTRAINT affiliate_uses_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.users(id);


--
-- Name: affiliate_uses affiliate_uses_codigo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.affiliate_uses
    ADD CONSTRAINT affiliate_uses_codigo_id_fkey FOREIGN KEY (codigo_id) REFERENCES public.affiliate_codes(id);


--
-- Name: affiliate_uses affiliate_uses_pedido_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.affiliate_uses
    ADD CONSTRAINT affiliate_uses_pedido_id_fkey FOREIGN KEY (pedido_id) REFERENCES public.orders(id);


--
-- Name: affiliate_uses affiliate_uses_staff_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.affiliate_uses
    ADD CONSTRAINT affiliate_uses_staff_payment_id_fkey FOREIGN KEY (staff_payment_id) REFERENCES public.staff_payments(id);


--
-- Name: ai_usage_log ai_usage_log_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.ai_usage_log
    ADD CONSTRAINT ai_usage_log_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.ai_conversations(id);


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: caja caja_pedido_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.caja
    ADD CONSTRAINT caja_pedido_id_fkey FOREIGN KEY (pedido_id) REFERENCES public.orders(id);


--
-- Name: caja caja_registrado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.caja
    ADD CONSTRAINT caja_registrado_por_fkey FOREIGN KEY (registrado_por) REFERENCES public.users(id);


--
-- Name: caja caja_staff_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.caja
    ADD CONSTRAINT caja_staff_payment_id_fkey FOREIGN KEY (staff_payment_id) REFERENCES public.staff_payments(id);


--
-- Name: campanas_marketing campanas_marketing_creado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.campanas_marketing
    ADD CONSTRAINT campanas_marketing_creado_por_fkey FOREIGN KEY (creado_por) REFERENCES public.users(id);


--
-- Name: campanas_marketing campanas_marketing_zona_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.campanas_marketing
    ADD CONSTRAINT campanas_marketing_zona_id_fkey FOREIGN KEY (zona_id) REFERENCES public.zonas_entrega(id);


--
-- Name: combo_groups combo_groups_combo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.combo_groups
    ADD CONSTRAINT combo_groups_combo_id_fkey FOREIGN KEY (combo_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: combo_items combo_items_combo_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.combo_items
    ADD CONSTRAINT combo_items_combo_group_id_fkey FOREIGN KEY (combo_group_id) REFERENCES public.combo_groups(id) ON DELETE CASCADE;


--
-- Name: combo_items combo_items_combo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.combo_items
    ADD CONSTRAINT combo_items_combo_id_fkey FOREIGN KEY (combo_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: combo_items combo_items_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.combo_items
    ADD CONSTRAINT combo_items_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: combo_items combo_items_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.combo_items
    ADD CONSTRAINT combo_items_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE SET NULL;


--
-- Name: hub_commissions hub_commissions_pedido_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.hub_commissions
    ADD CONSTRAINT hub_commissions_pedido_id_fkey FOREIGN KEY (pedido_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: idempotency_keys idempotency_keys_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: idempotency_keys idempotency_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: menu_config menu_config_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.menu_config
    ADD CONSTRAINT menu_config_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.categorias(id);


--
-- Name: menu_config menu_config_creado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.menu_config
    ADD CONSTRAINT menu_config_creado_por_fkey FOREIGN KEY (creado_por) REFERENCES public.users(id);


--
-- Name: menu_config menu_config_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.menu_config
    ADD CONSTRAINT menu_config_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.products(id);


--
-- Name: notification_outbox notification_outbox_pedido_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.notification_outbox
    ADD CONSTRAINT notification_outbox_pedido_id_fkey FOREIGN KEY (pedido_id) REFERENCES public.orders(id);


--
-- Name: notification_outbox notification_outbox_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.notification_outbox
    ADD CONSTRAINT notification_outbox_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: order_events order_events_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.order_events
    ADD CONSTRAINT order_events_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: order_events order_events_pedido_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.order_events
    ADD CONSTRAINT order_events_pedido_id_fkey FOREIGN KEY (pedido_id) REFERENCES public.orders(id);


--
-- Name: order_items order_items_pedido_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pedido_id_fkey FOREIGN KEY (pedido_id) REFERENCES public.orders(id);


--
-- Name: order_items order_items_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.products(id);


--
-- Name: order_provider_status order_provider_status_actualizado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.order_provider_status
    ADD CONSTRAINT order_provider_status_actualizado_por_fkey FOREIGN KEY (actualizado_por) REFERENCES public.users(id);


--
-- Name: order_provider_status order_provider_status_pedido_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.order_provider_status
    ADD CONSTRAINT order_provider_status_pedido_id_fkey FOREIGN KEY (pedido_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_provider_status order_provider_status_proveedor_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.order_provider_status
    ADD CONSTRAINT order_provider_status_proveedor_entity_id_fkey FOREIGN KEY (proveedor_id) REFERENCES public.proveedores(id);


--
-- Name: order_provider_status order_provider_status_proveedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.order_provider_status
    ADD CONSTRAINT order_provider_status_proveedor_id_fkey FOREIGN KEY (proveedor_id) REFERENCES public.proveedores(id);


--
-- Name: orders orders_afiliado_codigo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_afiliado_codigo_id_fkey FOREIGN KEY (afiliado_codigo_id) REFERENCES public.affiliate_codes(id);


--
-- Name: orders orders_cajero_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_cajero_id_fkey FOREIGN KEY (cajero_id) REFERENCES public.users(id);


--
-- Name: orders orders_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.users(id);


--
-- Name: orders orders_cupon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_cupon_id_fkey FOREIGN KEY (cupon_id) REFERENCES public.coupons(id);


--
-- Name: orders orders_pago_confirmado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pago_confirmado_por_fkey FOREIGN KEY (pago_confirmado_por) REFERENCES public.users(id);


--
-- Name: orders orders_preparador_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_preparador_id_fkey FOREIGN KEY (preparador_id) REFERENCES public.users(id);


--
-- Name: orders orders_repartidor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_repartidor_id_fkey FOREIGN KEY (repartidor_id) REFERENCES public.users(id);


--
-- Name: orders orders_zona_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_zona_id_fkey FOREIGN KEY (zona_id) REFERENCES public.zonas_entrega(id);


--
-- Name: points_log points_log_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.points_log
    ADD CONSTRAINT points_log_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.users(id);


--
-- Name: points_log points_log_pedido_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.points_log
    ADD CONSTRAINT points_log_pedido_id_fkey FOREIGN KEY (pedido_id) REFERENCES public.orders(id);


--
-- Name: price_history price_history_cambiado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_cambiado_por_fkey FOREIGN KEY (cambiado_por) REFERENCES public.users(id);


--
-- Name: price_history price_history_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.products(id);


--
-- Name: product_extra_groups product_extra_groups_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_extra_groups
    ADD CONSTRAINT product_extra_groups_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_extra_options product_extra_options_catalog_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_extra_options
    ADD CONSTRAINT product_extra_options_catalog_item_id_fkey FOREIGN KEY (catalog_item_id) REFERENCES public.extra_catalog_items(id) ON DELETE SET NULL;


--
-- Name: product_extra_options product_extra_options_grupo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_extra_options
    ADD CONSTRAINT product_extra_options_grupo_id_fkey FOREIGN KEY (grupo_id) REFERENCES public.product_extra_groups(id) ON DELETE CASCADE;


--
-- Name: product_extras product_extras_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_extras
    ADD CONSTRAINT product_extras_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_presentations product_presentations_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_presentations
    ADD CONSTRAINT product_presentations_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_variants product_variants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: products products_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.categorias(id);


--
-- Name: products products_proveedor_despachador_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_proveedor_despachador_id_fkey FOREIGN KEY (proveedor_despachador_id) REFERENCES public.proveedores(id);


--
-- Name: products products_proveedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_proveedor_id_fkey FOREIGN KEY (proveedor_id) REFERENCES public.users(id);


--
-- Name: proveedor_productos proveedor_productos_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.proveedor_productos
    ADD CONSTRAINT proveedor_productos_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: proveedor_productos proveedor_productos_proveedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.proveedor_productos
    ADD CONSTRAINT proveedor_productos_proveedor_id_fkey FOREIGN KEY (proveedor_id) REFERENCES public.proveedores(id) ON DELETE CASCADE;


--
-- Name: push_subscriptions push_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: reviews reviews_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.users(id);


--
-- Name: reviews reviews_pedido_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pedido_id_fkey FOREIGN KEY (pedido_id) REFERENCES public.orders(id);


--
-- Name: reviews reviews_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.products(id);


--
-- Name: site_config site_config_actualizado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.site_config
    ADD CONSTRAINT site_config_actualizado_por_fkey FOREIGN KEY (actualizado_por) REFERENCES public.users(id);


--
-- Name: staff_payments staff_payments_pedido_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.staff_payments
    ADD CONSTRAINT staff_payments_pedido_id_fkey FOREIGN KEY (pedido_id) REFERENCES public.orders(id);


--
-- Name: staff_payments staff_payments_registrado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.staff_payments
    ADD CONSTRAINT staff_payments_registrado_por_fkey FOREIGN KEY (registrado_por) REFERENCES public.users(id);


--
-- Name: staff_payments staff_payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.staff_payments
    ADD CONSTRAINT staff_payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: stock stock_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.products(id);


--
-- Name: users users_proveedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_proveedor_id_fkey FOREIGN KEY (proveedor_id) REFERENCES public.proveedores(id);


--
-- Name: users users_zona_repartidor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: oxidian
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_zona_repartidor_id_fkey FOREIGN KEY (zona_repartidor_id) REFERENCES public.zonas_entrega(id) ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: oxidian
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict FUNvrdqnjBjoRo42sztOtvcb2RGRcQms4ID4MMlLPKK7fN5QcwKqA6pWFcra1gW

